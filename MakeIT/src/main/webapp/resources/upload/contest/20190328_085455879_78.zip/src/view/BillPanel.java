package view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class BillPanel {

	private JPanel contentPane;
	private String phoneNumber;
	private JLabel lblNewLabel_6;
	private JLabel howToPay;
	private JLabel billMemberNum;
	private JLabel billMovieTitle;
	private JLabel payMoney;
	private JLabel runningTime;
	private JLabel seatNum;
	private JLabel theater;
	private JLabel phoneNum;
	private JButton complete;
	private JFrame frame;
	
	public BillPanel() {
		setHowToPay(new JLabel("SSSS"));
		setSeatNum(new JLabel("값 있어?"));
		setBillMemberNum(new JLabel());
		setPhoneNum(new JLabel());
	}

	public void billPage() {
		setFrame(new JFrame());
		getFrame().setBounds(500, 250, 350, 640);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		contentPane.setLayout(null);

		JLabel preTicketLabel = new JLabel("******************** << 예 매 정 보 >> ********************");
		preTicketLabel.setBounds(14, 258, 411, 18);
		contentPane.add(preTicketLabel);

		JLabel movieTitleLabel = new JLabel("영화 제목 : ");
		movieTitleLabel.setBounds(35, 342, 83, 18);
		contentPane.add(movieTitleLabel);

		JLabel theaterLabel = new JLabel("상영관 : ");
		theaterLabel.setBounds(49, 460, 57, 18);
		contentPane.add(theaterLabel);

		JLabel payInfolabel = new JLabel("******************** << 결 제 정 보 >> ********************");
		payInfolabel.setBounds(14, 12, 411, 18);
		contentPane.add(payInfolabel);

		JLabel payMoneyLabel = new JLabel("결제 금액 :");
		payMoneyLabel.setBounds(35, 145, 83, 18);
		contentPane.add(payMoneyLabel);

		setBillMovieTitle(new JLabel());
		getBillMovieTitle() .setBounds(229, 342, 150, 18);
		contentPane.add(getBillMovieTitle());

		JLabel peopleNumLabel  = new JLabel("인원 수 :");
		peopleNumLabel .setBounds(49, 71, 62, 18);
		contentPane.add(peopleNumLabel );

		JLabel howToPayLabel = new JLabel("결제 수단 :");
		howToPayLabel.setBounds(35, 109, 83, 18);
		contentPane.add(howToPayLabel);

		JLabel runningTimeLabel = new JLabel("상영 시간 :");
		runningTimeLabel.setBounds(35, 380, 83, 18);
		contentPane.add(runningTimeLabel);

		JLabel enjoyLabel = new JLabel("***************** 즐거운 관람 되십시오! *****************");
		enjoyLabel.setBounds(14, 550, 411, 18);
		contentPane.add(enjoyLabel);

		JLabel seatNumLabel = new JLabel("좌석 번호 : ");
		seatNumLabel.setBounds(35, 420, 83, 18);
		contentPane.add(seatNumLabel);

		getBillMemberNum().setBounds(229, 71, 62, 18);
		contentPane.add(getBillMemberNum());

		
		getHowToPay().setBounds(229, 109, 76, 18);
		contentPane.add(getHowToPay());

		setPayMoney(new JLabel());
		getPayMoney().setBounds(229, 145, 62, 18);
		contentPane.add(getPayMoney());

		setRunningTime(new JLabel());
		getRunningTime().setBounds(229, 380, 62, 18);
		contentPane.add(getRunningTime());

		
		getSeatNum().setBounds(220, 420, 100, 20);
		contentPane.add(getSeatNum());
		
		setTheater(new JLabel(phoneNumber, SwingConstants.RIGHT));
		getTheater().setBounds(130, 460, 180, 18);
		contentPane.add(getTheater());

		//phoneNumber = payDB.getPhoneComboReturn() + payDB.getSecondPhone() + payDB.getThirdPhone();

		
		getPhoneNum().setBounds(50, 209, 120, 18);
		contentPane.add(getPhoneNum());

		JLabel moonjaTongBo = new JLabel("로 예매권을 전송하였습니다.");
		moonjaTongBo.setBounds(130, 209, 180, 20);
		contentPane.add(moonjaTongBo);
		
		setComplete(new JButton("완료"));
		getComplete().setBounds(125,580,100,25);
		contentPane.add(getComplete());
		
		
		getFrame().setContentPane(contentPane);
		getFrame().setLocationRelativeTo(null);//창을 가운데 띄움
		getFrame().setResizable(false); //고정
		getFrame().setVisible(true);
	}
	
	public void close() {
		getFrame().dispose();
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public JLabel getLblNewLabel_6() {
		return lblNewLabel_6;
	}

	public void setLblNewLabel_6(JLabel lblNewLabel_6) {
		this.lblNewLabel_6 = lblNewLabel_6;
	}

	public JLabel getHowToPay() {
		return howToPay;
	}

	public void setHowToPay(JLabel howToPay) {
		this.howToPay = howToPay;
	}

	public JLabel getBillMemberNum() {
		return billMemberNum;
	}

	public void setBillMemberNum(JLabel billMemberNum) {
		this.billMemberNum = billMemberNum;
	}

	public JLabel getBillMovieTitle() {
		return billMovieTitle;
	}

	public void setBillMovieTitle(JLabel billMovieTitle) {
		this.billMovieTitle = billMovieTitle;
	}

	public JLabel getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(JLabel payMoney) {
		this.payMoney = payMoney;
	}

	public JLabel getRunningTime() {
		return runningTime;
	}

	public void setRunningTime(JLabel runningTime) {
		this.runningTime = runningTime;
	}

	public JLabel getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(JLabel seatNum1) {
		this.seatNum = seatNum1;
	}


	public JLabel getTheater() {
		return theater;
	}

	public void setTheater(JLabel theater) {
		this.theater = theater;
	}

	public JLabel getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(JLabel phoneNum) {
		this.phoneNum = phoneNum;
	}

	public JButton getComplete() {
		return complete;
	}

	public void setComplete(JButton complete) {
		this.complete = complete;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}




}
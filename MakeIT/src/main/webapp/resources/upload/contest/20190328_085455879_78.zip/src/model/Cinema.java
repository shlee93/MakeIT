package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JLabel;

public class Cinema implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1681000727241742377L;
	// String name, String address, int startDate, int endDate, int cinemaCount
	private String name; // 영화관 브랜드 이름 ex) CGV, MEGABOX etc
	private String city; // 영화관 도
	private String borough; // 영화관 시
	private String area; // 영화관 지점
	private boolean[] seatList = new boolean[49]; // 49개 좌석
	private HashMap<String, ArrayList<String>> screenList; // 상영관수 ABC이렇게 변환할것
	// screenList["A관" -> ArrayList[time, 무리들]]
	private String price; // 티켓값
	//영화선택>시네마이름>시티>구>지점>날짜 (startDate 색칠 endDate 색칠) 이거 앞뒤로는 오류메세지 출력해서 선택X . 이사이값중에서 하나 선택하면 그게 Ticket Date다
	private String startDate;
	private String endDate;
	//private String ticketInfo;

	public Cinema() {

	}

	public Cinema(String name, String city, String borough, String area, HashMap<String, ArrayList<String>> screenList,
			String price, String startDate, String endDate) {

		this.name = name;
		this.city = city;
		this.borough = borough;
		this.area = area;
		this.screenList = screenList; //키에 대한 벨류
		this.price = price;
		this.startDate = startDate;
		this.endDate = endDate;
		//this.ticketInfo = name + " " + city + " " + borough + " " + area + " " + startDate + " " + endDate;//해쉬맵의 키
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBorough() {
		return borough;
	}

	public void setBorough(String borough) {
		this.borough = borough;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public HashMap<String, ArrayList<String>> getScreenList() {
		return screenList;
	}

	public void setScreenList(HashMap<String, ArrayList<String>> screenList) {
		this.screenList = screenList;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "브랜드 이름 = " + getName() + ", 주소 = " + getCity() + " " + getBorough() + " " + getArea() + " "
				+ ", 티켓 가격 = " + getPrice() + ", 상영관 + 시간 리스트 = " + getScreenList() + "\n";
	}

}

package view;

import java.awt.Color;

import java.awt.Font;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class AdminUserInfoPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;

	// 회원정보 눌렀을시
	private JTextArea AdminUserInfoArea;
	private JButton AdminUserInfoBackBtn;
	private JScrollPane AdminUserInfoScroll;

	public AdminUserInfoPanel(JFrame frame) {
		this.frame = frame;
	}

	public void adminUserInfoPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);

		setImagePanel(new ImagePanel(new ImageIcon("./images/adUserInfoPage/adUserInfoBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);	

		setAdminUserInfoArea(new JTextArea());
		getAdminUserInfoArea().setFont(new Font("맑은 고딕", Font.PLAIN, 15));
		
		setAdminUserInfoScroll(new JScrollPane(getAdminUserInfoArea(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		getAdminUserInfoScroll().setBounds(69, 106, 841, 366);
		
		getImagePanel().add(getAdminUserInfoScroll());
			
		setAdminUserInfoBackBtn(new JButton());
		getAdminUserInfoBackBtn().setIcon(new ImageIcon("./images/adUserInfoPage/adUserInfoBackBtn.jpg"));
		getAdminUserInfoBackBtn().setBounds(409, 499, 161, 51);
		getImagePanel().add(getAdminUserInfoBackBtn());

		getFrame().getContentPane().add(this);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public JTextArea getAdminUserInfoArea() {
		return AdminUserInfoArea;
	}

	public void setAdminUserInfoArea(JTextArea adminUserInfoArea) {
		AdminUserInfoArea = adminUserInfoArea;
	}

	public JButton getAdminUserInfoBackBtn() {
		return AdminUserInfoBackBtn;
	}

	public void setAdminUserInfoBackBtn(JButton adminUserInfoBackBtn) {
		AdminUserInfoBackBtn = adminUserInfoBackBtn;
	}

	public JScrollPane getAdminUserInfoScroll() {
		return AdminUserInfoScroll;
	}

	public void setAdminUserInfoScroll(JScrollPane adminUserInfoScroll) {
		AdminUserInfoScroll = adminUserInfoScroll;
	}
}

package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class MainPanel extends JPanel {

	private JFrame frame;
	private ImagePanel imagePanel;
	private JLabel poster;
	private HashMap<String, String[]> borough; // 지역 강남구, 수원, 용인
	private HashMap<String, String[]> area; // 동 강남, 압구정, 서현,판교
	private JButton userMainLogOutBtn;
	private JList mylist;
	private JList brandChoice;
	private JList cityChoice;
	private JList city2Choice;
	private JList city3Choice;

	// 영화확인
	private JPanel movieInfoPanel;
	
	private JLabel title;
	private JLabel cinemaName;
	private String calDate;
	private JLabel date;
	private JLabel time;
	private JLabel ciName;
	
	//버튼
	private JButton allBtn;
	private JButton cgvBtn;
	private JButton megaBtn;
	private JButton lotteBtn;
	
	//

	
	private JButton[] mainCinemaList;
	private JButton[] mainTimeList;

	
	// 캘린더
	private JTable dayViewTable;
	private JLabel label;
	private JPanel MainDate;// 캘린더들가는패널
	private JButton prevvbtn;
	private JButton nexttbtn;
	private JTable table;
	private boolean focus = false;
	private JButton userMainUserCartBtn;

	Calendar calendar = Calendar.getInstance();
	DefaultTableModel weekTable = new DefaultTableModel(0, 7);
	DefaultTableModel dayTable = new DefaultTableModel(6, 7);
	int todayD;

	// 극장및영화선택
	private JScrollPane scrollpane;
	private JScrollPane scrollpane2;
	private JScrollPane scrollpane3;
	private JLabel userNameLabel;
	private JButton userMainNextBtn;
	private JLabel ticketPrice;
	private JLabel mainStartDateL;
	private JLabel mainEndDateL;

	public MainPanel() {	

	}

	public MainPanel(JFrame frame) {

		this.frame = frame;

	}

	public void mainPage() {

		setBorough(new HashMap<String, String[]>());

		setArea(new HashMap<String, String[]>());

		String[] borough_0 = { "강남구", "강동/송파구", "영등포구" };
		String[] borough_1 = { "성남", "수원", "인천" };
		String[] borough_2 = { "부산", "울산", "창원" };
		String[] borough_3 = { "대구", "안동", "포항" };
		String[] borough_4 = { "대전", "천안", "강릉" };
		String[] borough_5 = { "광주", "여수", "제주" };

		// 서울
		String[] area_00 = { "강남점", "압구정점" };
		String[] area_01 = { "송파점", "천호점" };
		String[] area_02 = { "여의도점", "영등포점" };

		// 경기
		String[] area_10 = { "판교점", "서현점" };
		String[] area_11 = { "수원점", "동수원점" };
		String[] area_12 = { "인천점", "인천공항점" };

		// 부산
		String[] area_20 = { "서면점", "남포점" };
		String[] area_21 = { "울산삼산점" };
		String[] area_22 = { "마산점", "창원점" };

		// 대구
		String[] area_30 = { "대구점", "대구월성점" };
		String[] area_31 = { "안동점" };
		String[] area_32 = { "포항점", "북포항점" };

		// 대전
		String[] area_40 = { "대전점", "대전터미널점" };
		String[] area_41 = { "천안점", "천안펜타포트점" };
		String[] area_42 = { "강릉점" };

		// 광주
		String[] area_50 = { "광주상무점", "광주터미널점" };
		String[] area_51 = { "여수웅천점" };
		String[] area_52 = { "제주점", "제주노형점" };

		// City를 키로 지역을 붙임
		getBorough().put("서울", borough_0);
		getBorough().put("경기/인천", borough_1);
		getBorough().put("부산/울산/경남", borough_2);
		getBorough().put("대구/경북", borough_3);
		getBorough().put("대전/충청/강원", borough_4);
		getBorough().put("광주/전라/제주", borough_5);

		// borough를 키로 동을 붙임

		// 서울
		getArea().put("강남구", area_00);
		getArea().put("강동/송파구", area_01);
		getArea().put("영등포구", area_02);

		// 경기
		getArea().put("성남", area_10);
		getArea().put("수원", area_11);
		getArea().put("인천", area_12);

		// 부산
		getArea().put("부산", area_20);
		getArea().put("울산", area_21);
		getArea().put("창원", area_22);

		// 대구
		getArea().put("대구", area_30);
		getArea().put("안동", area_31);
		getArea().put("포항", area_32);

		// 대전
		getArea().put("대전", area_40);
		getArea().put("천안", area_41);
		getArea().put("강릉", area_42);

		// 광주
		getArea().put("광주", area_50);
		getArea().put("여수", area_51);
		getArea().put("제주", area_52);

		// 패널꾸미기
		setBounds(0, 0, 980, 640);
		setLayout(null);
		setImagePanel(new ImagePanel(new ImageIcon("./images/userMainPage/userMainBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		getImagePanel().setLayout(null);
		add(getImagePanel());
		
		setMainStartDateL(new JLabel());
		getMainStartDateL().setBounds(271, 220, 300, 265);
		getMainStartDateL().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMainStartDateL());
		
		// 영화선택 리스트
		String[] city = { "서울", "경기/인천", "부산/울산/경남", "대구/경북", "대전/충청/강원", "광주/전라/제주" };
		setMylist(new JList());
		getMylist().setBounds(32, 107, 150, 265);
		getMylist().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//getMylist().setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		getMylist().setVisibleRowCount(10);
		getMylist().setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		setScrollpane(new JScrollPane(getMylist()));
		getScrollpane().setBounds(32, 107, 150, 265);
		getImagePanel().add(getScrollpane());

		// 영화관 브랜드 선택 리스트
//		  String [] brand = {"CGV","메가박스","롯데시네마"};
//		  	setBrandChoice(new JList(brand));
//			getBrandChoice().setForeground(Color.DARK_GRAY);
//			getBrandChoice().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//			getBrandChoice().setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
//			getBrandChoice().setFont(new Font("맑은 고딕", Font.PLAIN, 12));
//			getBrandChoice().setBounds(210, 187, 70, 60);
//			getImagePanel().add(getBrandChoice());

		// 지역선택 리스트
		//String[] city = { "서울", "경기/인천", "부산/울산/경남", "대구/경북", "대전/충청/강원", "광주/전라/제주" };
		setCityChoice(new JList());
		getCityChoice().setForeground(Color.DARK_GRAY);
		getCityChoice().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//getCityChoice().setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		getCityChoice().setFont(new Font("맑은 고딕", Font.PLAIN, 11));
		getCityChoice().setBounds(189, 180, 85, 160);
		getCityChoice().setVisibleRowCount(5);
		setScrollpane(new JScrollPane(getCityChoice()));
		getScrollpane().setBounds(189, 180, 85, 160);
		getImagePanel().add(getScrollpane());

		// 도시선택 리스트
		String[] city2 = { "도시 선택" };
		setCity2Choice(new JList());
		getCity2Choice().setForeground(Color.DARK_GRAY);
		getCity2Choice().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//getCity2Choice().setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		getCity2Choice().setFont(new Font("맑은 고딕", Font.PLAIN, 11));
		getCity2Choice().setBounds(276, 180, 92, 160);
		getCity2Choice().setVisibleRowCount(5);
		setScrollpane2(new JScrollPane(getCity2Choice()));
		getScrollpane2().setBounds(276, 180, 92, 160);
		getImagePanel().add(getScrollpane2());

		// 지역선택 리스트
		String[] city3 = { "지역 선택" };
		setCity3Choice(new JList());
		getCity3Choice().setForeground(Color.DARK_GRAY);
		getCity3Choice().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//getCity3Choice().setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
		getCity3Choice().setFont(new Font("맑은 고딕", Font.PLAIN, 11));
		getCity3Choice().setBounds(370, 180, 136, 160);

		getCity3Choice().setVisibleRowCount(5);
		setScrollpane3(new JScrollPane(getCity3Choice()));
		getScrollpane3().setBounds(370, 180, 136, 160);
		getImagePanel().add(getScrollpane3());

		//전체 CGV 메가박스 롯데시네마 선택버튼
		setAllBtn(new JButton());
		getAllBtn().setBounds(196, 120, 67, 42);
		getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn1.jpg"));
		getImagePanel().add(getAllBtn());
		
		setCgvBtn(new JButton());
		getCgvBtn().setBounds(271, 120, 67, 42);
		getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
		getImagePanel().add(getCgvBtn());
		
		setMegaBtn(new JButton());
		getMegaBtn().setBounds(345, 120, 67, 42);
		getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
		getImagePanel().add(getMegaBtn());
		
		setLotteBtn(new JButton());
		getLotteBtn().setBounds(418, 120, 67, 42);
		getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));
		getImagePanel().add(getLotteBtn());
		
		// 상영관 + 상영 시간
		setMainCinemaList(new JButton[4]);

		getMainCinemaList()[0] = new JButton("A");
		getMainCinemaList()[0].setBounds(754, 136, 44, 34);
		getMainCinemaList()[0].setBackground(Color.WHITE);
		getMainCinemaList()[0].setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		getImagePanel().add(getMainCinemaList()[0]);
		
		getMainCinemaList()[1] = new JButton("B");
		getMainCinemaList()[1].setBounds(801, 136, 44, 34);
		getMainCinemaList()[1].setBackground(Color.WHITE);
		getMainCinemaList()[1].setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		getImagePanel().add(getMainCinemaList()[1]);
		
		getMainCinemaList()[2] =new JButton("C");
		getMainCinemaList()[2].setBounds(848, 136, 44, 34);
		getMainCinemaList()[2].setBackground(Color.WHITE);
		getMainCinemaList()[2].setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		getImagePanel().add(getMainCinemaList()[2]);
		
		getMainCinemaList()[3] =new JButton("D");
		getMainCinemaList()[3].setBounds(895, 136, 44, 34);
		getMainCinemaList()[3].setBackground(Color.WHITE);
		getMainCinemaList()[3].setFont(new Font("맑은 고딕", Font.PLAIN, 12));		
		getImagePanel().add(getMainCinemaList()[3]);
		
		setMainTimeList(new JButton[4]);
		
		getMainTimeList()[0] = new JButton("09:20");
		getMainTimeList()[0].setBounds(791, 190, 114, 34);
		getMainTimeList()[0].setBackground(Color.WHITE);
		getMainTimeList()[0].setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMainTimeList()[0]);
		
		getMainTimeList()[1] = new JButton("12:30");
		getMainTimeList()[1].setBounds(791, 234, 114, 34);
		getMainTimeList()[1].setBackground(Color.WHITE);
		getMainTimeList()[1].setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMainTimeList()[1]);
		
		getMainTimeList()[2] = new JButton("16:40");
		getMainTimeList()[2].setBounds(791, 278, 114, 34);
		getMainTimeList()[2].setBackground(Color.WHITE);
		getMainTimeList()[2].setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMainTimeList()[2]);
		
		getMainTimeList()[3] =new JButton("21:10");
		getMainTimeList()[3].setBounds(791, 322, 114, 34);
		getMainTimeList()[3].setBackground(Color.WHITE);
		getMainTimeList()[3].setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMainTimeList()[3]);
		
		
		// 선택한 예매 정보
		setMovieInfoPanel(new JPanel());
		getMovieInfoPanel().setBounds(55, 430, 120, 150);
		getMovieInfoPanel().setBackground(Color.WHITE);
		getMovieInfoPanel().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getMovieInfoPanel());
		getMovieInfoPanel().setLayout(null);

		setPoster(new JLabel());
		getPoster().setBounds(0, 0, 102, 145);	
		getMovieInfoPanel().add(getPoster());
		getPoster().setIcon(new ImageIcon("./images/moviePoster/default.jpg"));
		getPoster().setLayout(null);
		
		setTitle(new JLabel());
		getTitle().setBounds(262, 486, 200, 15);
		getTitle().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getTitle());

		setDate(new JLabel());
		getDate().setBounds(262, 511, 200, 15);
		getDate().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getDate());
		
		setCinemaName(new JLabel());
		getCinemaName().setBounds(262, 460, 200, 15);
		getCinemaName().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getCinemaName());
		
		setTime(new JLabel());
		getTime().setBounds(262, 538, 200, 15);
		getTime().setFont(new Font("맑은 고딕", Font.PLAIN, 14));
		getImagePanel().add(getTime());
		//요금정보
		setTicketPrice(new JLabel());
		getTicketPrice().setBounds(658, 532, 200, 20);
		getTicketPrice().setFont(new Font("맑은 고딕", Font.BOLD, 16));
		getImagePanel().add(getTicketPrice());
		// 캘린더
		Calendar calendar = Calendar.getInstance();
		// 요일 표시
		String[] weekColumns = { "일", "월", "화", "수", "목", "금", "토" };
		weekTable.addRow(weekColumns);
		// 가운데 정렬
		DefaultTableCellRenderer center = new DefaultTableCellRenderer();
		center.setHorizontalAlignment(JLabel.CENTER);
		DefaultTableCellRenderer top = new DefaultTableCellRenderer();
		top.setVerticalAlignment(SwingConstants.TOP);

		setMainDate(new JPanel());
		getMainDate().setBounds(517, 100, 230, 270);
		getMainDate().setBorder(new EmptyBorder(5, 5, 5, 5));
		getMainDate().setBackground(Color.WHITE);
		getMainDate().setLayout(null);
		// 이미지패널에 date넣는다
		getImagePanel().add(MainDate);
		// 이전버튼
		setPrevvbtn(new JButton("<"));
		// 이전버튼 이벤트처리 이동해야함
		getPrevvbtn().setBounds(6, 0, 46, 46);
		getPrevvbtn().setOpaque(false);
		getPrevvbtn().setFont(new Font("굴림", Font.PLAIN, 16));
		getPrevvbtn().setFocusable(false);
		getPrevvbtn().setContentAreaFilled(false);
		getPrevvbtn().setBorderPainted(false);

		// 버튼 투명하게
		getPrevvbtn().setOpaque(false);
		getPrevvbtn().setContentAreaFilled(false);
		getPrevvbtn().setBorderPainted(false);
		getPrevvbtn().setFocusable(false);
		getMainDate().add(getPrevvbtn());
		// YYMM라벨
		label = new JLabel("");
		label.setBounds(35, 6, 150, 27);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		getMainDate().add(label);

		// next버튼
		setNexttbtn(new JButton(">"));
		getNexttbtn().setBorderPainted(false);
		getNexttbtn().setFont(new Font("굴림", Font.PLAIN, 16));
		getNexttbtn().setBounds(175, 0, 46, 46);
		getNexttbtn().setOpaque(false);
		getNexttbtn().setContentAreaFilled(false);
		getNexttbtn().setBorderPainted(false);
		getNexttbtn().setFocusable(false);
		getMainDate().add(getNexttbtn());

		// 주 테이블(월-일)
		setTable(new JTable(weekTable) {
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				return false;
			}
		});
		getTable().setBounds(8, 43, 213, 23);
		getTable().setRowSelectionAllowed(false);
		getTable().setRowHeight(25);
		getTable().setFont(new Font("맑은 고딕", Font.BOLD, 12));
		getTable().setFillsViewportHeight(true);
		getTable().setEnabled(false);
		getTable().setBorder(new LineBorder(new Color(0, 0, 0)));
		getTable().setBackground(Color.LIGHT_GRAY);
		getTable().getColumnModel().getColumn(1).setCellRenderer(center);
		getTable().getColumnModel().getColumn(2).setCellRenderer(center);
		getTable().getColumnModel().getColumn(3).setCellRenderer(center);
		getTable().getColumnModel().getColumn(4).setCellRenderer(center);
		getTable().getColumnModel().getColumn(5).setCellRenderer(center);
		getTable().getColumnModel().getColumn(0).setCellRenderer(center);
		getTable().getColumnModel().getColumn(6).setCellRenderer(center);
		MainDate.add(getTable());

		// 1-31테이블
		setDayViewTable(new JTable(dayTable) {
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				return false;
			}
		});
		getDayViewTable().setBackground(Color.WHITE);
		getDayViewTable().setCellSelectionEnabled(true);
		getDayViewTable().setColumnSelectionAllowed(true);
		getDayViewTable().setRowHeight(34);
		getDayViewTable().setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		getDayViewTable().setFillsViewportHeight(true);
		getDayViewTable().setColumnSelectionAllowed(true);
		getDayViewTable().setCellSelectionEnabled(true);
		getDayViewTable().setBorder(new LineBorder(new Color(0, 0, 0)));
		getDayViewTable().setBounds(8, 65, 213, 212);
		getDayViewTable().getColumnModel().getColumn(0).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(1).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(2).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(3).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(4).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(5).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(6).setCellRenderer(center);
		getMainDate().add(getDayViewTable());

		setTodayD(calendar.get(Calendar.DATE));
		refresh();
		//todayFocus();


		// 회원정보버튼
		setUserMainUserCartBtn(new JButton());
		getUserMainUserCartBtn().setBounds(800, 475, 68, 29);
		getUserMainUserCartBtn().setIcon(new ImageIcon("./images/userMainPage/userMainFindBtn.jpg"));
		getImagePanel().add(getUserMainUserCartBtn());
		
		setUserNameLabel(new JLabel());
		getUserNameLabel().setBounds(866, 410, 68, 29);	
		getUserNameLabel().setFont(new Font("맑은 고딕", Font.BOLD, 14));
		getImagePanel().add(getUserNameLabel());
		// 로그아웃버튼
		setUserMainLogOutBtn(new JButton());
		getUserMainLogOutBtn().setBounds(876, 475, 68, 29);
		getUserMainLogOutBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLogoutBtn.jpg"));
		getImagePanel().add(getUserMainLogOutBtn());
		// 예매하기
		setUserMainNextBtn(new JButton());
		getUserMainNextBtn().setIcon(new ImageIcon("./images/userMainPage/userMainNextBtn.jpg"));
		getUserMainNextBtn().setBounds(788, 529, 161, 61);
		getImagePanel().add(getUserMainNextBtn());

		// 프레임에 add

		getFrame().getContentPane().add(this);

	}

	// 캘린더 받아오기
	public void refresh() {

		getLabel().setText((calendar.get(Calendar.YEAR) + ".") + (calendar.get(Calendar.MONTH) + 1));
		setCalDate(getLabel().getText());
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		int dayWeek = calendar.get(Calendar.DAY_OF_WEEK);
		int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				getDayViewTable().setValueAt("", i, j);
			}
		}
		for (int day = 1, row = 0, col = dayWeek - 1; day < endDay + 1; day++, col++) {
			if (col % 7 == 0) {
				col = 0;
				row += 1;
			}
			getDayViewTable().setValueAt(" " + day, row, col);
		}
	}
/*
	// 오늘날짜에 focus

	protected void todayFocus() {

		for (int i = 0; i < 6; i++) {

			for (int j = 0; j < 7; j++) {

				if (dayViewTable.getValueAt(i, j).equals(" " + todayD)) {

					dayViewTable.changeSelection(i, j, false, false);

					dayViewTable.requestFocus();

				}

			}

		}

	}*/

	public HashMap<String, String[]> getBorough() {

		return borough;

	}

	public void setBorough(HashMap<String, String[]> borough) {

		this.borough = borough;

	}

	public HashMap<String, String[]> getArea() {

		return area;

	}

	public void setArea(HashMap<String, String[]> area) {

		this.area = area;

	}

	public JFrame getFrame() {

		return frame;

	}

	public void setFrame(JFrame frame) {

		this.frame = frame;

	}

	public ImagePanel getImagePanel() {

		return imagePanel;

	}

	public void setImagePanel(ImagePanel imagePanel) {

		this.imagePanel = imagePanel;

	}

	public JButton getUserMainLogOutBtn() {

		return userMainLogOutBtn;

	}

	public void setUserMainLogOutBtn(JButton userMainLogOutBtn) {

		this.userMainLogOutBtn = userMainLogOutBtn;

	}

	public JButton getUserMainNextBtn() {

		return userMainNextBtn;

	}

	public void setUserMainNextBtn(JButton userMainNextBtn) {

		this.userMainNextBtn = userMainNextBtn;

	}

	public JList getMylist() {

		return mylist;

	}

	public void setMylist(JList mylist) {

		this.mylist = mylist;

	}

	public JScrollPane getScrollpane() {

		return scrollpane;

	}

	public void setScrollpane(JScrollPane scrollpane) {

		this.scrollpane = scrollpane;

	}

	public JList getBrandChoice() {

		return brandChoice;

	}

	public void setBrandChoice(JList brandChoice) {

		this.brandChoice = brandChoice;

	}

	public JList getCityChoice() {

		return cityChoice;

	}

	public void setCityChoice(JList cityChoice) {

		this.cityChoice = cityChoice;

	}

	public JList getCity2Choice() {

		return city2Choice;

	}

	public void setCity2Choice(JList city2Choice) {

		this.city2Choice = city2Choice;

	}

	public JScrollPane getScrollpane2() {

		return scrollpane2;

	}

	public void setScrollpane2(JScrollPane scrollpane2) {

		this.scrollpane2 = scrollpane2;

	}

	public JList getCity3Choice() {

		return city3Choice;

	}

	public void setCity3Choice(JList city3Choice) {

		this.city3Choice = city3Choice;

	}

	public JScrollPane getScrollpane3() {

		return scrollpane3;

	}

	public void setScrollpane3(JScrollPane scrollpane3) {

		this.scrollpane3 = scrollpane3;

	}

	public JLabel getPoster() {
		return poster;
	}

	public void setPoster(JLabel poster) {
		this.poster = poster;
	}

	public JLabel getTitle() {

		return title;

	}

	public void setTitle(JLabel title) {

		this.title = title;

	}


	public JLabel getCiName() {
		return ciName;
	}

	public void setCiName(JLabel ciName) {
		this.ciName = ciName;
	}

	public JLabel getDate() {

		return date;

	}

	public void setDate(JLabel date) {

		this.date = date;

	}

	public JLabel getTime() {

		return time;

	}

	public void setTime(JLabel time) {

		this.time = time;

	}

	public JPanel getMovieInfoPanel() {

		return movieInfoPanel;

	}

	public void setMovieInfoPanel(JPanel movieInfoPanel) {

		this.movieInfoPanel = movieInfoPanel;

	}

	public JTable getDayViewTable() {
		return dayViewTable;
	}

	public void setDayViewTable(JTable dayViewTable) {
		this.dayViewTable = dayViewTable;
	}

	public JLabel getLabel() {
		return label;
	}

	public void setLabel(JLabel label) {
		this.label = label;
	}

	public JPanel getMainDate() {
		return MainDate;
	}

	public void setMainDate(JPanel mainDate) {
		MainDate = mainDate;
	}

	public JButton getPrevvbtn() {
		return prevvbtn;
	}

	public void setPrevvbtn(JButton prevvbtn) {
		this.prevvbtn = prevvbtn;
	}

	public JButton getNexttbtn() {
		return nexttbtn;
	}

	public void setNexttbtn(JButton nexttbtn) {
		this.nexttbtn = nexttbtn;
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}

	public boolean isFocus() {
		return focus;
	}

	public void setFocus(boolean focus) {
		this.focus = focus;
	}

	public Calendar getCalendar() {
		return calendar;
	}

	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}

	public DefaultTableModel getWeekTable() {
		return weekTable;
	}

	public void setWeekTable(DefaultTableModel weekTable) {
		this.weekTable = weekTable;
	}

	public DefaultTableModel getDayTable() {
		return dayTable;
	}

	public void setDayTable(DefaultTableModel dayTable) {
		this.dayTable = dayTable;
	}

	public int getTodayD() {
		return todayD;
	}

	public void setTodayD(int todayD) {
		this.todayD = todayD;
	}

	public JButton getUserMainUserCartBtn() {
		return userMainUserCartBtn;
	}

	public JLabel getUserNameLabel() {
		return userNameLabel;
	}

	public void setUserNameLabel(JLabel userNameLabel) {
		this.userNameLabel = userNameLabel;
	}

	public void setUserMainUserCartBtn(JButton userMainUserCartBtn) {
		this.userMainUserCartBtn = userMainUserCartBtn;
	}

	public JLabel getCinemaName() {
		return cinemaName;
	}

	public void setCinemaName(JLabel cinemaName) {
		this.cinemaName = cinemaName;
	}

	public JButton getCgvBtn() {
		return cgvBtn;
	}

	public void setCgvBtn(JButton cgvBtn) {
		this.cgvBtn = cgvBtn;
	}

	public JButton getMegaBtn() {
		return megaBtn;
	}

	public void setMegaBtn(JButton megaBtn) {
		this.megaBtn = megaBtn;
	}

	public JButton getAllBtn() {
		return allBtn;
	}

	public void setAllBtn(JButton allBtn) {
		this.allBtn = allBtn;
	}

	public JButton getLotteBtn() {
		return lotteBtn;
	}

	public void setLotteBtn(JButton lotteBtn) {
		this.lotteBtn = lotteBtn;
	}

	public String getCalDate() {
		return calDate;
	}

	public void setCalDate(String calDate) {
		this.calDate = calDate;
	}

	public JButton[] getMainCinemaList() {
		return mainCinemaList;
	}

	public void setMainCinemaList(JButton[] mainCinemaList) {
		this.mainCinemaList = mainCinemaList;
	}

	public JButton[] getMainTimeList() {
		return mainTimeList;
	}

	public JLabel getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(JLabel ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public JLabel getMainStartDateL() {
		return mainStartDateL;
	}

	public void setMainStartDateL(JLabel mainStartDateL) {
		this.mainStartDateL = mainStartDateL;
	}

	public JLabel getMainEndDateL() {
		return mainEndDateL;
	}

	public void setMainEndDateL(JLabel mainEndDateL) {
		this.mainEndDateL = mainEndDateL;
	}

	public void setMainTimeList(JButton[] mainTimeList) {
		this.mainTimeList = mainTimeList;
	}

	// 이전버튼 이벤트
	public void do_prevvbtn_actionPerformed(ActionEvent e) {
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) - 1, calendar.get(Calendar.DATE));
		refresh();
	}

	// 다음버튼이벤트
	public void do_nexttbtn_actionPerformed(ActionEvent e) {
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DATE));
		refresh();
	}
}
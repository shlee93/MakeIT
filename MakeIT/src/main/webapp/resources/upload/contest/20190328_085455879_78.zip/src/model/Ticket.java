package model;

import java.io.Serializable;

public class Ticket implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7579181190621555097L;
	
	//영화이름 > 시네마 > 도 > 시 > 지점 > 관람날짜 > 상영관 > 시간 > /<<앞에정보들을 키로 갖는 좌석 배열/ > 좌석
	private String userId; //소유자id
	private static int ticketCount = 0;
	private int ticketNumber = 0;
	private String ticketMovieName; //영화이름
	private String ticketMovieGenre; //영화장르
	private String ticketCinemaName; //영화관이름
	private String ticketPrice; //티켓가격
	private boolean[] ticketSeatList; //좌석표들 관-시간 
	private String ticketCity; // 영화관 도
	private String ticketBorough; // 영화관 시
	private String ticketArea; // 영화관 지점
	private String ticketDate; //관람날짜
	private String ticketCinema; //상영관 ex) A관,B관....
	private String ticketTime; //관+상영시간
	//ticketAllInfo는 영화이름 + 시네마이름 +도+시+지점 + 관람날짜+ 상영관+상영시간까지를 전부 String으로 합친것 비교용
	private String ticketAllInfo = ticketMovieName + ticketCinemaName + ticketCity + ticketBorough + ticketArea + ticketDate + ticketCinema + ticketTime;
	//this.ticketAllInfo = ticketMovieName + ticketCinemaName + ticketCity + ticketBorough + ticketArea + ticketDate + ticketCinema + ticketTime;
	public Ticket() {
		
	}

	public Ticket(String ticketMovieName, String ticketCinemaName, String ticketPrice, 
			String ticketCity, String ticketBorough, String ticketArea, String ticketDate, String ticketCinema,
			String ticketTime) {
		
		this.ticketMovieName = ticketMovieName;
		this.ticketCinemaName = ticketCinemaName;
		this.ticketPrice = ticketPrice;
		this.ticketCity = ticketCity;
		this.ticketBorough = ticketBorough;
		this.ticketArea = ticketArea;
		this.ticketDate = ticketDate;
		this.ticketCinema = ticketCinema;
		this.ticketTime = ticketTime;
		this.ticketSeatList = new boolean[49];
		this.ticketAllInfo = ticketMovieName + ticketCinemaName + ticketCity + ticketBorough + ticketArea + ticketDate + ticketCinema + ticketTime;
		this.ticketNumber = Ticket.ticketCount;
		Ticket.ticketCount += 1;
	}

	public String getTicketMovieName() {
		return ticketMovieName;
	}

	public void setTicketMovieName(String ticketMovieName) {
		this.ticketMovieName = ticketMovieName;
	}

	public String getTicketCinemaName() {
		return ticketCinemaName;
	}

	public void setTicketCinemaName(String ticketCinemaName) {
		this.ticketCinemaName = ticketCinemaName;
	}

	public String getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(String ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public boolean[] getTicketSeatList() {
		return ticketSeatList;
	}

	public void setTicketSeatList(boolean[] ticketSeatList) {
		this.ticketSeatList = ticketSeatList;
	}

	public String getTicketCity() {
		return ticketCity;
	}

	public void setTicketCity(String ticketCity) {
		this.ticketCity = ticketCity;
	}

	public String getTicketBorough() {
		return ticketBorough;
	}

	public void setTicketBorough(String ticketBorough) {
		this.ticketBorough = ticketBorough;
	}

	public String getTicketArea() {
		return ticketArea;
	}

	public void setTicketArea(String ticketArea) {
		this.ticketArea = ticketArea;
	}

	public String getTicketDate() {
		return ticketDate;
	}

	public void setTicketDate(String ticketDate) {
		this.ticketDate = ticketDate;
	}

	public String getTicketCinema() {
		return ticketCinema;
	}

	public void setTicketCinema(String ticketCinema) {
		this.ticketCinema = ticketCinema;
	}

	public String getTicketTime() {
		return ticketTime;
	}

	public void setTicketTime(String ticketTime) {
		this.ticketTime = ticketTime;
	}

	public String getTicketAllInfo() {
		return ticketAllInfo;
	}

	public void setTicketAllInfo(String ticketAllInfo) {
		this.ticketAllInfo = ticketAllInfo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static int getTicketCount() {
		return ticketCount;
	}

	public static void setTicketCount(int ticketCount) {
		Ticket.ticketCount = ticketCount;
	}

	public int getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTicketMovieGenre() {
		return ticketMovieGenre;
	}

	public void setTicketMovieGenre(String ticketMovieGenre) {
		this.ticketMovieGenre = ticketMovieGenre;
	}

} 

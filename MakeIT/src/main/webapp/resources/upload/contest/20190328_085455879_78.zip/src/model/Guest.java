package model;

import java.io.Serializable;

public class Guest extends User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3378333485752211400L;
	private boolean isGuest = false;
	public Guest() {
		
	}
	public Guest(String id, String password, String name, String age, String gender, String phoneNumber, 
			boolean isSignUp, boolean isLogin, boolean isGuest) {
		super(id, password, name, age, gender, phoneNumber, 
			isSignUp, isLogin);
		this.isGuest = isGuest;
	}
	//Getter/setter
	public boolean isGuest() {
		return isGuest;
	}
	public void setGuest(boolean isGuest) {
		this.isGuest = isGuest;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return super.toString() +"isGuest=" + isGuest;
	}
	

	
}

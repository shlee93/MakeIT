package view;

import java.awt.Color;

import java.awt.Font;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class TicketInfoPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;

	// 회원정보 눌렀을시
	private JTextArea ticketInfoArea;
	private JButton ticketInfoBackBtn;
	private JScrollPane ticketInfoScroll;

	public TicketInfoPanel(JFrame frame) {
		this.frame = frame;
	}

	public void ticketInfoPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);

		setImagePanel(new ImagePanel(new ImageIcon("./images/ticketInfoPage/ticketInfoBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);	

		setTicketInfoArea(new JTextArea());
		getTicketInfoArea().setFont(new Font("맑은 고딕", Font.PLAIN, 15));
		
		setTicketInfoScroll(new JScrollPane(getTicketInfoArea(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		getTicketInfoScroll().setBounds(69, 106, 841, 366);
		
		getImagePanel().add(getTicketInfoScroll());
			
		setTicketInfoBackBtn(new JButton());
		getTicketInfoBackBtn().setIcon(new ImageIcon("./images/ticketInfoPage/ticketInfoBackBtn.jpg"));
		getTicketInfoBackBtn().setBounds(409, 499, 161, 51);
		getImagePanel().add(getTicketInfoBackBtn());

		getFrame().getContentPane().add(this);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public JTextArea getTicketInfoArea() {
		return ticketInfoArea;
	}

	public void setTicketInfoArea(JTextArea ticketInfoArea) {
		this.ticketInfoArea = ticketInfoArea;
	}

	public JButton getTicketInfoBackBtn() {
		return ticketInfoBackBtn;
	}

	public void setTicketInfoBackBtn(JButton ticketInfoBackBtn) {
		this.ticketInfoBackBtn = ticketInfoBackBtn;
	}

	public JScrollPane getTicketInfoScroll() {
		return ticketInfoScroll;
	}

	public void setTicketInfoScroll(JScrollPane ticketInfoScroll) {
		this.ticketInfoScroll = ticketInfoScroll;
	}


}

package model;

import java.io.Serializable;
import java.util.ArrayList;

public class Movie implements Serializable, Comparable<Movie> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8045177374411495529L;
	// 작품명, 관람등급, 제작사, 장르, 감독, 주연, 조연
	// private String poster; 영화포스터 필수<<이미지처리확인
	private String name; // 작품명
	private ArrayList<Cinema> cinemaList; // 영화를 상영하고 있는 상영관들 객체들을 저장
	private Cinema cinema; // 상영관정보
	private String grade; // 관람등급
	private String genre;// 장르
	private String producer; // 제작사
	private String director; // 영화감독
	private ArrayList<String> leadingActor; // 주연배우 모음
	private ArrayList<String> supportingActor; // 조연배우 모음
	private Ticket ticket;
	private int ticketPurchaseCount = 0; //티켓구매 카운트

	public Movie() {

	}

	public Movie(String name, String genre, String grade, String producer, String director,
			ArrayList<String> leadingActor, ArrayList<String> supportingActor) {
		this.name = name;
		this.genre = genre;
		this.grade = grade;
		this.producer = producer;
		this.director = director;
		this.leadingActor = leadingActor;	
		this.supportingActor = supportingActor;
	}
	
	public Movie(String name, String genre, String grade, String producer, String director,
			ArrayList<String> leadingActor, ArrayList<String> supportingActor, ArrayList<Cinema> cinemaList) {
		this.name = name;
		this.genre = genre;
		this.grade = grade;
		this.producer = producer;
		this.director = director;
		this.leadingActor = leadingActor;
		this.supportingActor = supportingActor;
		this.cinemaList = cinemaList;
	}
	@Override
	public int compareTo(Movie anotherMovie) {
		return Integer.compare(anotherMovie.getTicketPurchaseCount(),getTicketPurchaseCount());
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Cinema> getCinemaList() {
		return cinemaList;
	}

	public void setCinemaList(ArrayList<Cinema> cinemaList) {
		this.cinemaList = cinemaList;
	}

	public Cinema getCinema() {
		return cinema;
	}

	public void setCinema(Cinema cinema) {
		this.cinema = cinema;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getProducer() {
		return producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public ArrayList<String> getLeadingActor() {
		return leadingActor;
	}

	public void setLeadingActor(ArrayList<String> leadingActor) {
		this.leadingActor = leadingActor;
	}

	public ArrayList<String> getSupportingActor() {
		return supportingActor;
	}

	public void setSupportingActor(ArrayList<String> supportingActor) {
		this.supportingActor = supportingActor;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}


	public int getTicketPurchaseCount() {
		return ticketPurchaseCount;
	}

	public void setTicketPurchaseCount(int ticketPurchaseCount) {
		this.ticketPurchaseCount = ticketPurchaseCount;
	}

	// String name, String genre, int grade, String producer, String director,
	// ArrayList<String> leadingActor, ArrayList<String> supportingActor
	@Override
	public String toString() {
		return "Movie [ 작품명 = " + getName() + ", 장르 = " + getGenre() + ", 관람등급 = " + getGrade() + ", 제작사 = "
				+ getProducer() + ", 감독 = " + getDirector() + ", 주연배우 = [ " + getLeadingActor() + " ]" + ", 조연배우 = [ "
				+ getSupportingActor() + " ]" + ", 상영중 영화관 리스트 = [ " + getCinemaList() + " ]" + " ]";
	}
	
}

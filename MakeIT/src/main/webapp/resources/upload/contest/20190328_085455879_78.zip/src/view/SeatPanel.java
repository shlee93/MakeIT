package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SeatPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;
	private JPanel seatScreenPn;

	private JButton seatBackBtn;
	private JButton seatNextBtn;
	private JButton[] seatNum;
	private ArrayList<String> labelList;
	private int[] strList;
	private JLabel seatLabel;

	public SeatPanel() {

	}

	public int[] getStrList() {
		return strList;
	}

	public void setStrList(int[] strList) {
		this.strList = strList;
	}

	public ArrayList<String> getLabelList() {
		return labelList;
	}

	public SeatPanel(JFrame frame) {
		this.frame = frame;

	}

	public void seatPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);
		// 이미지를 넣을 패널
		setImagePanel(new ImagePanel(new ImageIcon("./images/seatSetPage/seatSetBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);

		setSeatScreenPn(new JPanel());
		getSeatScreenPn().setLayout(new GridLayout(7, 7));
		getSeatScreenPn().setBackground(Color.white);
		getSeatScreenPn().setBounds(49, 201, 613, 372);
		// String[] str = new String[49];
		setSeatNum(new JButton[49]);

		getImagePanel().add(getSeatScreenPn());
		// LIGHT_GRAY
		setSeatLabel(new JLabel());	
		getSeatLabel().setBounds(766, 37, 185, 200);
		getSeatLabel().setBackground(Color.white);
		getSeatLabel().setFont(new Font("맑은 고딕", Font.PLAIN, 19));
		getImagePanel().add(getSeatLabel());

		setSeatBackBtn(new JButton(""));
		getSeatBackBtn().setBounds(766, 430, 174, 64);
		getSeatBackBtn().setIcon(new ImageIcon("./images/seatSetPage/seatSetBackBtn.jpg"));
		getImagePanel().add(getSeatBackBtn());

		setSeatNextBtn(new JButton(""));
		getSeatNextBtn().setBounds(766, 509, 174, 64);
		getSeatNextBtn().setIcon(new ImageIcon("./images/seatSetPage/seatSetNextBtn.jpg"));
		getImagePanel().add(getSeatNextBtn());

		getFrame().getContentPane().add(this);

	}
	// gett/sett

	public JPanel getSeatScreenPn() {
		return seatScreenPn;
	}

	public void setSeatScreenPn(JPanel seatScreenPn) {
		this.seatScreenPn = seatScreenPn;
	}

	public JButton getSeatBackBtn() {
		return seatBackBtn;
	}

	public JLabel getSeatLabel() {
		return seatLabel;
	}

	public void setSeatLabel(JLabel seatLabel) {
		this.seatLabel = seatLabel;
	}

	public void setSeatBackBtn(JButton seatBackBtn) {
		this.seatBackBtn = seatBackBtn;
	}

	public JButton getSeatNextBtn() {
		return seatNextBtn;
	}

	public void setSeatNextBtn(JButton seatNextBtn) {
		this.seatNextBtn = seatNextBtn;
	}

	public JButton[] getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(JButton[] seatNum) {
		this.seatNum = seatNum;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public void setLabelList(ArrayList<String> labelList) {
		this.labelList = labelList;
	}

}
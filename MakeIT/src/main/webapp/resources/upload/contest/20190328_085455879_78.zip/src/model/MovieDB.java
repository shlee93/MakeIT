package model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MovieDB {
	private ArrayList<Movie> arrayList;
	private String dbName;

	public MovieDB() {
	}

	public MovieDB(ArrayList<Movie> arrayList, String dbName) {
		this.arrayList = arrayList;
		this.dbName = dbName;
	}

	public void createMovieDB() {
		try {
			File f = new File(getDbName());
			f.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void saveMovieDB(ArrayList<Movie> arrayList) {
		setArrayList(arrayList);
		OutputStream out = null;
		BufferedOutputStream bout = null;
		ObjectOutputStream oout = null;
		try {
			out = new FileOutputStream(getDbName());
			bout = new BufferedOutputStream(out);
			oout = new ObjectOutputStream(bout);
			oout.writeObject(getArrayList());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				oout.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<Movie> loadMovieDB() {
		createMovieDB();
		InputStream in = null;
		BufferedInputStream bin = null;
		ObjectInputStream oin = null;

		try {
			in = new FileInputStream(getDbName());
			bin = new BufferedInputStream(in);
			oin = new ObjectInputStream(bin);
			ArrayList<Movie> list = (ArrayList<Movie>) oin.readObject();
			setArrayList(list);
		} catch (Exception e) {
			System.out.println("MovieDB에 영화정보가 없습니다.");
			setArrayList(new ArrayList<Movie>());

		} finally {
			try {
				oin.close();
			} catch (NullPointerException e) {
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return getArrayList();
	}

	public ArrayList<Movie> getArrayList() {
		return arrayList;
	}

	public void setArrayList(ArrayList<Movie> arrayList) {
		this.arrayList = arrayList;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
}

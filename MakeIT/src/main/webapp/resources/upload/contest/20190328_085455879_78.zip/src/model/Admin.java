package model;

import java.io.Serializable;

public class Admin extends User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4027253435517096650L;
	private boolean isAdmin = true;	
	public Admin() {
		
	}
	public Admin(String id, String password, String name, String age, String gender, String phoneNumber, 
			boolean isSignUp, boolean isLogin, boolean isAdmin) {
		super(id, password, name, age, gender, phoneNumber, 
			isSignUp, isLogin);
		this.isAdmin = isAdmin;
	}
	//getter/setter
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}

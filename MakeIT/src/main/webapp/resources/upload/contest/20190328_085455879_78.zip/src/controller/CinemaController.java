﻿package controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Cinema;
import model.Guest;
import model.Movie;
import model.MovieDB;
import model.Ticket;
import model.TicketDB;
import model.User;
import view.AccountPanel;
import view.AdminMainPanel;
import view.AdminMovieInfoPanel;
import view.AdminUserInfoPanel;
import view.BillPanel;
import view.CinemaRegistrationPanel;
import view.CreditPanel;
import view.MainPanel;
import view.MovieRegistrationPanel;
import view.PayPanel;
import view.PhonePanel;
import view.SeatPanel;
import view.TicketInfoPanel;

public class CinemaController {
	private MovieDB movieDB;
	private TicketDB ticketDB;
	private ArrayList model;
	private ArrayList view;
	private UserController userController;
	private Ticket ticket;
	private Ticket oldTicket;
	private Movie movie;// 선택된영화
	private Cinema cinema;// 선택된 영화관 (지점이골라지면 세팅시켜서 사용 )
	// ex)CGV 강남점 = getCinema().getName() +" " + getCinema().getArea() CGV 강남점)

	// 패널들
	private MainPanel mainPanel; // 로그인을 했는데 게스트면 열로옴
	private AdminMainPanel adminMainPanel; // 유저컨트롤러의 유저가 admin인지 검사하고 로그인인지 검사해서 되면 도착
	private MovieRegistrationPanel movieRegistrationPanel; //
	private CinemaRegistrationPanel cinemaRegistrationPanel;
	private AdminUserInfoPanel adminUserInfoPanel;
	private AdminMovieInfoPanel adminMovieInfoPanel;
	private TicketInfoPanel ticketInfoPanel;
	private SeatPanel seatPanel;
	private BillPanel billPanel;
	private PayPanel payPanel;
	private CreditPanel creditPanel;
	private AccountPanel accountPanel;
	private PhonePanel phonePanel;//
	private String startDate = "";
	private String endDate = "";

	private ArrayList<String> timeList; // 상영 시간이
	private HashMap<String, ArrayList<String>> screenList; // 상영관수 ABC이렇게 변환할것
	private int index = 0;
	private boolean flag = false;
	private int seatCount = 0; // 선택된 좌석 숫자
	private int client = 4; // 좌석 인원고정
	private String value = "";
	private int timeCount = 0;
	private String screenTime;
	private String screenName;
	// 메인페이지용
	private ArrayList<Cinema> choiceCinemaList1;
	private ArrayList<Cinema> choiceCinemaList2;
	private ArrayList<Cinema> choiceCinemaList3;
	private ArrayList<Cinema> choiceCinemaList4;
	// 생성자

	public CinemaController() {

	}

	public CinemaController(ArrayList model, ArrayList view) {
		this.model = model;
		this.view = view;
		for (Object obj : model) {
			if (obj instanceof MovieDB) {
				this.movieDB = (MovieDB) obj;
			} else if (obj instanceof TicketDB) {
				this.ticketDB = (TicketDB) obj;
			}
		}
		for (Object obj : view) {
			if (obj instanceof MainPanel) {
				this.mainPanel = (MainPanel) obj;
			} else if (obj instanceof AdminMainPanel) {
				this.adminMainPanel = (AdminMainPanel) obj;
			} else if (obj instanceof MovieRegistrationPanel) {
				this.movieRegistrationPanel = (MovieRegistrationPanel) obj;
			} else if (obj instanceof CinemaRegistrationPanel) {
				this.cinemaRegistrationPanel = (CinemaRegistrationPanel) obj;
			} else if (obj instanceof AdminUserInfoPanel) {
				this.adminUserInfoPanel = (AdminUserInfoPanel) obj;
			} else if (obj instanceof AdminMovieInfoPanel) {
				this.adminMovieInfoPanel = (AdminMovieInfoPanel) obj;
			} else if (obj instanceof SeatPanel) {
				this.seatPanel = (SeatPanel) obj;
			} else if (obj instanceof PayPanel) {
				this.payPanel = (PayPanel) obj;
			} else if (obj instanceof BillPanel) {
				this.billPanel = (BillPanel) obj;
			} else if (obj instanceof CreditPanel) {
				this.creditPanel = (CreditPanel) obj;
			} else if (obj instanceof AccountPanel) {
				this.accountPanel = (AccountPanel) obj;
			} else if (obj instanceof PhonePanel) {
				this.phonePanel = (PhonePanel) obj;
			} else if (obj instanceof TicketInfoPanel) {
				this.ticketInfoPanel = (TicketInfoPanel) obj;
			}
		}
	}

	public void deleteTicketDB(ArrayList<Ticket> ticketList, int ticketNumber) {
		for (Ticket t : ticketList) {
			if (t != null) {
				if (t.getTicketNumber() == ticketNumber) {
					ticketList.remove(t);
					getTicketDB().setArrayList(ticketList);
				}
			}
		}

	}

	public void deleteMovieDB(ArrayList<Movie> movieList, String movieName) {
		System.err.println(movieList);
		for (Movie m : movieList) {
			System.out.println(m);
			if (m != null) {
				if (m.getName().equals(movieName)) {
					System.out.println(movieName);
					movieList.remove(m);
					getMovieDB().setArrayList(movieList);
					getMovieDB().saveMovieDB(getMovieDB().getArrayList());

				}
			}
		}
	}

	// DB최신화
	public void updateMovieDB() {
		ArrayList<Movie> temp = new ArrayList<Movie>();
		temp = getMovieDB().loadMovieDB();
		getMovieDB().setArrayList(temp);
	}

	public void updateTicketDB() {
		ArrayList<Ticket> temp = new ArrayList<Ticket>();
		temp = getTicketDB().loadTicketDB();
		getTicketDB().setArrayList(temp);
	}

	// 기능 + 패널
	public void ticketInfoPanel() {
		getTicketInfoPanel().ticketInfoPage();
		ticketInfo();
	}

	public void ticketInfo() {
		//
		int i = 1;
		updateTicketDB();

		int count = 0;
		for (Ticket ticket : getTicketDB().getArrayList()) {
			if (ticket != null) {
				if (getUserController().getUser().getId().equals(ticket.getUserId())) {
					count += 1;// 티켓 갯수
				}
			}
		}
		int[] tempCount = new int[count];
		String[] temp = new String[count];
		for (int k = 0; k < temp.length; k++) {
			temp[k] = "";
			tempCount[k] = 0;
		}
		ArrayList<Ticket> t = new ArrayList<Ticket>();
		for (int j = 0; j < getTicketDB().getArrayList().size(); j++) {
			if (getTicketDB().getArrayList().get(j) != null) {
				if (getUserController().getUser().getId().equals(getTicketDB().getArrayList().get(j).getUserId())) {
					t.add(getTicketDB().getArrayList().get(j));
				}
			}
		}
		for (int k = 0; k < t.size(); k++) {
			for (int s = 0; s < t.get(k).getTicketSeatList().length; s++) {
				if (t.get(k).getTicketSeatList()[s] == true) {
					temp[k] += "[" + (s + 1) + "] ";
					tempCount[k] += 1;
				}
			}
		}

		// 최신 TicketDB에서 예매되어있는 ticket들을 받아온다
		for (Ticket ticket : getTicketDB().getArrayList()) {
			if (ticket != null) {
				if (getUserController().getUser().getId().equals(ticket.getUserId())) {
					// 구매된 티켓중에 유저것이 있으면
					getTicketInfoPanel().getTicketInfoArea().append("티켓 " + "[ " + i + " ]" + "\n");
					getTicketInfoPanel().getTicketInfoArea()
							.append("작품명 : " + ticket.getTicketMovieName() + "\t장르 : " + ticket.getTicketMovieGenre()
									+ "\t주소 : " + ticket.getTicketCinemaName() + " " + ticket.getTicketArea()
									+ "\t관람일 : " + ticket.getTicketDate() + "\n상영관 : " + ticket.getTicketCinema() + " "
									+ ticket.getTicketTime() + "\t좌석 : " + temp[i - 1] + "\t총 예매 가격 : "
									+ Integer.parseInt(ticket.getTicketPrice()) * tempCount[i - 1] + "원" + " ( 1개 = "
									+ ticket.getTicketPrice() + "원 )\n");
					getTicketInfoPanel().getTicketInfoArea().append("\n");
					i++;
				}
			}
		}
		// 뒤로가기
		getTicketInfoPanel().getTicketInfoBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getTicketInfoPanel().setVisible(false);
				// 회원정보창 초기화
				getTicketInfoPanel().removeAll();
				getMainPanel().setVisible(true);
				mainPanel();
			}
		});
	}

	public void adminUserInfoPanel() {
		getAdminUserInfoPanel().adminUserInfoPage();
		adminUserInfo();
	}

	public void adminUserInfo() {
		// 이미 userController.getUserDB()는 최신버전이다
		int i = 1;
		for (User user : userController.getUserDB().getArrayList()) {
			if (user instanceof Guest) {
				getAdminUserInfoPanel().getAdminUserInfoArea().append("회원 " + "[ " + i + " ]" + "\n");
				getAdminUserInfoPanel().getAdminUserInfoArea()
						.append("ID : " + user.getId() + "\tPW : " + user.getPassword() + "\t이름 : " + user.getName()
								+ "\t나이 : " + user.getAge() + "\t성별 : " + user.getGender() + "\t핸드폰번호 : "
								+ user.getPhoneNumber() + "\n");
				getAdminUserInfoPanel().getAdminUserInfoArea().append("\n");
				i++;
			}
		}
		// 뒤로가기
		getAdminUserInfoPanel().getAdminUserInfoBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminUserInfoPanel().setVisible(false);
				// 회원정보창 초기화
				getAdminUserInfoPanel().removeAll();
				getAdminMainPanel().setVisible(true);
				adminMainPanel();
			}
		});
	}

	public void adminMovieInfoPanel() {
		getAdminMovieInfoPanel().adminMovieInfoPage();
		adminMovieInfo();
	}

	public void adminMovieInfo() {
		// 이미 getMovieDB는 최신버젼이다
		int i = 1;

		for (Movie movie : getMovieDB().getArrayList()) {
			getAdminMovieInfoPanel().getAdminMovieInfoArea().append("영화 " + "[ " + i + " ]" + "\n");
			getAdminMovieInfoPanel().getAdminMovieInfoArea()
					.append("제목 : " + movie.getName() + ", 장르 : " + movie.getGenre() + ", 관람등급 : " + movie.getGrade()
							+ ", 제작사 : " + movie.getProducer() + ", 감독 : " + movie.getDirector() + ", 주연 : "
							+ movie.getLeadingActor() + ", 조연 : " + movie.getSupportingActor() + "\n");
			getAdminMovieInfoPanel().getAdminMovieInfoArea()
					.append("영화 " + "[ " + i + " ]" + " 상영관 정보\n" + movie.getCinemaList() + "\n");
			i++;
			getAdminMovieInfoPanel().getAdminMovieInfoArea().append("\n");
		}

		getAdminMovieInfoPanel().getAdminMovieInfoArea()
				.setCaretPosition(getAdminMovieInfoPanel().getAdminMovieInfoArea().getDocument().getLength());
		// 뒤로가기
		getAdminMovieInfoPanel().getAdminMovieInfoBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminMovieInfoPanel().setVisible(false);
				// 영화정보창 초기화
				getAdminMovieInfoPanel().removeAll();
				getAdminMainPanel().setVisible(true);
				adminMainPanel();
			}
		});
	}

	public void adminMainPanel() {
		getAdminMainPanel().adminMainPage();
		adminMain();
	}

	public void adminMain() {
		// 다시한번 영화 최신화
		updateMovieDB();

		// 회원정보 창으로 이동
		getAdminMainPanel().getAdminUserInfoBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminMainPanel().setVisible(false);
				getAdminUserInfoPanel().setVisible(true);
				getAdminMainPanel().removeAll();
				adminUserInfoPanel();
			}
		});
		// 영화정보 창으로 이동
		getAdminMainPanel().getAdminMovieInfoBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminMainPanel().setVisible(false);
				getAdminMovieInfoPanel().setVisible(true);
				getAdminMainPanel().removeAll();
				adminMovieInfoPanel();
			}
		});
		// 영화등록창으로 이동
		getAdminMainPanel().getAdminMovieRegBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminMainPanel().setVisible(false);
				getMovieRegistrationPanel().setVisible(true);
				getAdminMainPanel().removeAll();
				movieRegistrationPanel();
			}
		});
		// 로그아웃
		getAdminMainPanel().getAdminExitBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getAdminMainPanel().setVisible(false);
				getAdminMainPanel().removeAll();

				// 유저컨트롤러의 user를 초기화함 = 빈객체를 넣으므로써
				getUserController().setUser(new User());
				getUserController().getLoginPanel().setVisible(true);
				getUserController().loginPanel();
				JOptionPane.showMessageDialog(null, "로그아웃 되었습니다.");
			}
		});
	}

	public void cinemaRegistrationPanel() {
		getCinemaRegistrationPanel().CinemaRegistrationPage();
		cinemaRegistration();
	}

	public void cinemaRegistration() {
		// 시네마패널에 있는 버튼들의 리스트들을 주소값을 복사해서 이벤트처리용으로 저장해논 리스트들
		JButton[] cinemaRegCinema = getCinemaRegistrationPanel().getCinemaRegCinemaBtnList(); // 상영관버튼
		JButton[] cinemaRegTime = getCinemaRegistrationPanel().getCinemaRegTimeBtnList(); // 시간버튼

		// 달력 이전버튼이벤트처리 = 저번달로 변경
		getCinemaRegistrationPanel().getPrevbtn().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getCinemaRegistrationPanel().do_prevbtn_actionPerformed(e);
			}
		});
		// 달력 이전버튼이벤트처리 = 다음달로 변경
		getCinemaRegistrationPanel().getNextbtn().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getCinemaRegistrationPanel().do_nextbtn_actionPerformed(e);
			}
		});

		// getCinemaRegistrationPanel().getDate(); 현재 달력의 년도 + 달
		// DayView테이블이벤트처리
		getCinemaRegistrationPanel().getDayViewTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// day일 로 출력되는 구문인데 이걸 여러개 선택 할 수 있게 해야하는데 되나?
				int row = getCinemaRegistrationPanel().getDayViewTable().getSelectedRow();// 열
				int column = getCinemaRegistrationPanel().getDayViewTable().getSelectedColumn();// 행
				String value = "";
				if (getCinemaRegistrationPanel().getDayViewTable().getValueAt(row, column).toString().replace(" ", "")
						.equals("")) {
					value = "";// 현재 선택값
				} else {
					value = getCinemaRegistrationPanel().getDayViewTable().getValueAt(row, column).toString()
							.replace(" ", "");// 현재 선택값
					setValue(value);
				}
			}
		});
		// 상영일 저장 + 라벨에 띄우기
		getCinemaRegistrationPanel().getCinemaRegStartBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String ymd = getCinemaRegistrationPanel().getDate() + "." + getValue();
				setStartDate(ymd);
				getCinemaRegistrationPanel().getCinemaRegStartLabel().setText(ymd);
			}
		});
		// 종영일
		getCinemaRegistrationPanel().getCinemaRegEndBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String ymd = getCinemaRegistrationPanel().getDate() + "." + getValue();
				setEndDate(ymd);
				getCinemaRegistrationPanel().getCinemaRegEndLabel().setText(ymd);
			}
		});
		// 타임리스트
		setTimeList(new ArrayList<String>());
		setScreenList(new HashMap<String, ArrayList<String>>());

		// 상영관
		for (int i = 0; i < cinemaRegCinema.length; i++) {
			cinemaRegCinema[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (int i = 0; i < cinemaRegCinema.length; i++) {
						if (e.getSource() == cinemaRegCinema[i] && cinemaRegCinema[i].getBackground() == Color.white) {
							if (getSeatCount() == 0) {
								setIndex(i);
								cinemaRegCinema[i].setBackground(Color.CYAN);
								setFlag(true);
								setSeatCount(getSeatCount() + 1);

								break;
							} else {
								JOptionPane.showMessageDialog(null, "상영관은 하나씩 선택 가능합니다.");
								break;
							}
						} else if (e.getSource() == cinemaRegCinema[i]
								&& cinemaRegCinema[i].getBackground() == Color.CYAN) {
							cinemaRegCinema[i].setBackground(Color.white);
							setSeatCount(getSeatCount() - 1);// 상영관선택갯수
							setFlag(false);
							break;
						}
					}

				}
			});
		}

		// 시간
		for (int i = 0; i < cinemaRegTime.length; i++) {
			cinemaRegTime[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// ArrayList<String> temp = new ArrayList<String>();
					if (isFlag() && getSeatCount() == 1 && getSeatCount() != 0) {
						for (int i = 0; i < cinemaRegTime.length; i++) {
							if (e.getSource() == cinemaRegTime[i] && cinemaRegTime[i].getBackground() == Color.white) {
								cinemaRegTime[i].setBackground(Color.CYAN);
								getTimeList().add(cinemaRegTime[i].getText());
								break;
							} else if (e.getSource() == cinemaRegTime[i]
									&& cinemaRegTime[i].getBackground() == Color.CYAN) {
								cinemaRegTime[i].setBackground(Color.white);
								for (String str : getTimeList()) {
									if (str != null) {
										if (str.equals(cinemaRegTime[i].getText())) {
											getTimeList().remove(str);
											break;
										}
									}

								}
								break;
							}
						}
					} else {
						JOptionPane.showMessageDialog(null, "상영관을 먼저 선택해주세요.");
					}
				}
			});
		}

		// 저장
		getCinemaRegistrationPanel().getCinemaRegInsertBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 저장버튼을 누르면 상영관 1개에 엮인 시간들 전부 상영관R관 리스트에 들어가야한다

				// A관 리스트 에 시간을 key - value 관계로 묶음 (상영관 - 시간리스트[])
				getScreenList().put(cinemaRegCinema[getIndex()].getText(), getTimeList());
				// 시간버튼리스트 초기화
				setTimeList(new ArrayList<String>()); // 얘가 핵심

				// 시간버튼들 색 바꾸는(초기화기능)
				for (int i = 0; i < cinemaRegCinema.length; i++) {
					cinemaRegCinema[i].setBackground(Color.white);
					cinemaRegTime[i].setBackground(Color.white);
				}
				// 클릭수 1로 고정하기 - 상영관 초기화
				setSeatCount(0);

			}
		});

		// 돌아가기
		getCinemaRegistrationPanel().getCinemaRegBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getCinemaRegistrationPanel().setVisible(false);
				// 상영관등록창의 스크린 리스트 초기화
				setScreenList(new HashMap<String, ArrayList<String>>());
				// 상영관등록창의 상영관 1개로 고정시키기
				setSeatCount(0);
				setValue("");
				getMovieRegistrationPanel().setVisible(true);
				getCinemaRegistrationPanel().removeAll();
				movieRegistrationPanel();
			}
		});

		// 도고르기(서울, 경남 ,경기)
		getCinemaRegistrationPanel().getCinemaRegTxtCity().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Iterator<String> boroughKey = getCinemaRegistrationPanel().getBorough().keySet().iterator();
				String city = getCinemaRegistrationPanel().getCinemaRegTxtCity().getSelectedItem().toString();
				while (boroughKey.hasNext()) {
					String cityKey = boroughKey.next();
					if (cityKey.equals(city)) {
						getCinemaRegistrationPanel().getCinemaRegTxtBorough().setModel(
								new DefaultComboBoxModel(getCinemaRegistrationPanel().getBorough().get(city)));
						break;
					}
				}
			}
		});

		// 시고르기(강남,용인,여수)
		getCinemaRegistrationPanel().getCinemaRegTxtBorough().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Iterator<String> areaKey = getCinemaRegistrationPanel().getArea().keySet().iterator();
				String borough = getCinemaRegistrationPanel().getCinemaRegTxtBorough().getSelectedItem().toString();
				while (areaKey.hasNext()) {
					String boroughKey = areaKey.next();
					if (boroughKey.equals(borough)) {
						getCinemaRegistrationPanel().getCinemaRegTxtArea().setModel(
								new DefaultComboBoxModel(getCinemaRegistrationPanel().getArea().get(borough)));
						break;
					}
				}
			}
		});
		// 등록
		getCinemaRegistrationPanel().getCinemaRegRegBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (getStartDate().equals("") || getEndDate().equals("")) {
					// 경고문
					JOptionPane.showMessageDialog(null, "상영날짜와 종영날짜 모두 선택해주세요.");
					getCinemaRegistrationPanel().removeAll();
					cinemaRegistrationPanel();
				} else if (getScreenList() == null) {
					// 경고문
					JOptionPane.showMessageDialog(null, "상영관과 시간을 모두 선택해주세요.");
					getCinemaRegistrationPanel().removeAll();
					cinemaRegistrationPanel();
				} else {
					// 현재 있는 시네마 정보 추가하고 초기화
					getScreenList().put(cinemaRegCinema[getIndex()].getText(), getTimeList());
					Iterator<String> areaKey = getCinemaRegistrationPanel().getArea().keySet().iterator();
					String cinemaName = getCinemaRegistrationPanel().getCinemaRegTxtCinema().getSelectedItem()
							.toString();
					String city = getCinemaRegistrationPanel().getCinemaRegTxtCity().getSelectedItem().toString();
					String borough = getCinemaRegistrationPanel().getCinemaRegTxtBorough().getSelectedItem().toString();
					String area = getCinemaRegistrationPanel().getCinemaRegTxtArea().getSelectedItem().toString();
					String price = getCinemaRegistrationPanel().getCinemaRegTxtTicketPrice().getSelectedItem()
							.toString();
					// 영화이름 > 시네마 > 도 > 시 > 지점 > 관람날짜 > 상영관 > 시간 > /<<앞에정보들을 키로 갖는 좌석 배열/ > 좌석
					// 시네마객체생성
					// getMovie().getCinema().getArea()
					setCinema(new Cinema(cinemaName, city, borough, area, getScreenList(), price, getStartDate(),
							getEndDate()));
					// 마지막 화면의 시네마정보로 시네마만듬
					getMovie().getCinemaList().add(getCinema());

					// 영화디비 소환
					updateMovieDB();
					getMovieDB().getArrayList().add(getMovie());
					// 영화 디비에 저장
					getMovieDB().saveMovieDB(getMovieDB().getArrayList());
					// 사용한객체 초기화
					setMovie(new Movie());
					setCinema(new Cinema());
					// 등록후 리스트와 버튼 색 초기화
					setScreenList(new HashMap<String, ArrayList<String>>());
					setTimeList(new ArrayList<String>()); // 얘가 핵심
					setSeatCount(0);
					// 스타트데이랑 엔드데이 초기화
					setStartDate("");
					setEndDate("");
					// 흰색초기화
					for (int i = 0; i < cinemaRegCinema.length; i++) {
						cinemaRegCinema[i].setBackground(Color.white);
						cinemaRegTime[i].setBackground(Color.white);
					}
					// 등록후 라벨 초기화
					getCinemaRegistrationPanel().getCinemaRegEndLabel().setText("");
					getCinemaRegistrationPanel().getCinemaRegStartLabel().setText("");

					getCinemaRegistrationPanel().revalidate();
					getCinemaRegistrationPanel().repaint();
					getCinemaRegistrationPanel().getCinemaRegTxtCinema()
							.setModel(new DefaultComboBoxModel(new String[] { "CGV", "메가박스", "롯데시네마" }));
					getCinemaRegistrationPanel().getCinemaRegTxtCity().setModel(new DefaultComboBoxModel(
							new String[] { "서울", "경기/인천", "부산/울산/경남", "대구/경북", "대전/충청/강원", "광주/전라/제주" }));
					getCinemaRegistrationPanel().getCinemaRegTxtBorough()
							.setModel(new DefaultComboBoxModel(new String[] { "도시 선택" }));
					getCinemaRegistrationPanel().getCinemaRegTxtArea()
							.setModel(new DefaultComboBoxModel(new String[] { "지역 선택" }));
					getCinemaRegistrationPanel().getCinemaRegTxtTicketPrice().setModel(
							new DefaultComboBoxModel(new String[] { "6000원", "7000원", "8000원", "9000원", "10000원" }));

					JOptionPane.showMessageDialog(null, "영화등록이 완료되었습니다. 관리자 메인페이지로 이동합니다.");
					getCinemaRegistrationPanel().setVisible(false);

					getCinemaRegistrationPanel().removeAll();
					getAdminMainPanel().setVisible(true);
					adminMainPanel();
				}
			}
		});
		// 추가하기?
		getCinemaRegistrationPanel().getCinemaRegAddBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (getStartDate().equals("") || getEndDate().equals("")) {
					// 경고문
					JOptionPane.showMessageDialog(null, "상영날짜와 종영날짜 모두 선택해주세요.");
					getCinemaRegistrationPanel().removeAll();
					cinemaRegistrationPanel();
				} else if (getScreenList() == null) {
					// 경고문
					JOptionPane.showMessageDialog(null, "상영관과 시간을 모두 선택해주세요.");
					getCinemaRegistrationPanel().removeAll();
					cinemaRegistrationPanel();
				} else {
					// 현재 있는 시네마 정보 추가하고 초기화
					getScreenList().put(cinemaRegCinema[getIndex()].getText(), getTimeList());
					Iterator<String> areaKey = getCinemaRegistrationPanel().getArea().keySet().iterator();
					String cinemaName = getCinemaRegistrationPanel().getCinemaRegTxtCinema().getSelectedItem()
							.toString();
					String city = getCinemaRegistrationPanel().getCinemaRegTxtCity().getSelectedItem().toString();
					String borough = getCinemaRegistrationPanel().getCinemaRegTxtBorough().getSelectedItem().toString();
					String area = getCinemaRegistrationPanel().getCinemaRegTxtArea().getSelectedItem().toString();
					String price = getCinemaRegistrationPanel().getCinemaRegTxtTicketPrice().getSelectedItem()
							.toString();

					// 시네마객체생성
					setCinema(new Cinema(cinemaName, city, borough, area, getScreenList(), price, getStartDate(),
							getEndDate()));
					// 마지막 화면의 시네마정보로 시네마만듬
					getMovie().getCinemaList().add(getCinema());

					// 등록후 리스트와 버튼 색 초기화
					setScreenList(new HashMap<String, ArrayList<String>>());
					setTimeList(new ArrayList<String>()); // 얘가 핵심
					setSeatCount(0);
					// 스타트데이랑 엔드데이 초기화
					setStartDate("");
					setEndDate("");
					// 흰색초기화
					for (int i = 0; i < cinemaRegCinema.length; i++) {
						cinemaRegCinema[i].setBackground(Color.white);
						cinemaRegTime[i].setBackground(Color.white);
					}
					// 등록후 라벨 초기화
					getCinemaRegistrationPanel().getCinemaRegEndLabel().setText("");
					getCinemaRegistrationPanel().getCinemaRegStartLabel().setText("");

					// 추가하기후 날리고 다시 상영관등록
					getCinemaRegistrationPanel().removeAll();
					cinemaRegistrationPanel();

					// 흰색초기화
					for (int i = 0; i < cinemaRegCinema.length; i++) {
						cinemaRegCinema[i].setBackground(Color.white);
						cinemaRegTime[i].setBackground(Color.white);
					}

					getCinemaRegistrationPanel().revalidate();
					getCinemaRegistrationPanel().repaint();
					getCinemaRegistrationPanel().getCinemaRegTxtCinema()
							.setModel(new DefaultComboBoxModel(new String[] { "CGV", "메가박스", "롯데시네마" }));
					getCinemaRegistrationPanel().getCinemaRegTxtCity().setModel(new DefaultComboBoxModel(
							new String[] { "서울", "경기/인천", "부산/울산/경남", "대구/경북", "대전/충청/강원", "광주/전라/제주" }));
					getCinemaRegistrationPanel().getCinemaRegTxtBorough()
							.setModel(new DefaultComboBoxModel(new String[] { "도시 선택" }));
					getCinemaRegistrationPanel().getCinemaRegTxtArea()
							.setModel(new DefaultComboBoxModel(new String[] { "지역 선택" }));
					getCinemaRegistrationPanel().getCinemaRegTxtTicketPrice().setModel(
							new DefaultComboBoxModel(new String[] { "6000원", "7000원", "8000원", "9000원", "10000원" }));

				}
			}
		});
	}

	// 영화등록
	public void movieRegistrationPanel() {
		getMovieRegistrationPanel().movieRegistrationPage();
		movieRegistration();
	}

	public void movieRegistration() {
		// 빈칸채우기들
		getMovieRegistrationPanel().getMovieRegTxtName().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getMovieRegistrationPanel().getMovieRegTxtName().setText("");
			}
		});

		getMovieRegistrationPanel().getMovieRegTxtPro().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getMovieRegistrationPanel().getMovieRegTxtPro().setText("");
			}
		});

		getMovieRegistrationPanel().getMovieRegTxtDir().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getMovieRegistrationPanel().getMovieRegTxtDir().setText("");
			}
		});
		// 시네마등록창으로 이동하고, 무비창 초기화, 무비객체생성
		getMovieRegistrationPanel().getMovieRegRegBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 이 이벤트가 동작하면 영화 등록 창에 있는 txt필드, 콤보박스의 값을 저장
				if (getMovieRegistrationPanel().getMovieRegTxtName().getText().equals("")
						|| getMovieRegistrationPanel().getMovieRegTxtPro().getText().equals("")
						|| getMovieRegistrationPanel().getMovieRegTxtDir().getText().equals("")
						|| getMovieRegistrationPanel().getMovieRegTxtLeadAc().getText().equals("")
						|| getMovieRegistrationPanel().getMovieRegTxtSupAc().getText().equals("")) {
					JOptionPane.showMessageDialog(null, "빈칸이 존재합니다. 모든 항목을 입력해주세요.");
					// 초기화
					getMovieRegistrationPanel().removeAll();
					setMovie(new Movie());
					movieRegistrationPanel();
				} else if (getMovieRegistrationPanel().getMovieRegTxtName().getText().equals("작품명 입력")
						|| getMovieRegistrationPanel().getMovieRegTxtPro().getText().equals("제작사 입력")
						|| getMovieRegistrationPanel().getMovieRegTxtDir().getText().equals("감독 입력")) {
					JOptionPane.showMessageDialog(null, "빈칸이 존재합니다. 모든 항목을 입력해주세요.");
					// 초기화
					getMovieRegistrationPanel().removeAll();
					setMovie(new Movie());
					movieRegistrationPanel();
				} else {
					// 빈칸없이 모두 입력하면 다음 화면으로 넘어감
					String name = getMovieRegistrationPanel().getMovieRegTxtName().getText();
					String genre = getMovieRegistrationPanel().getMovieRegTxtGenre().getSelectedItem().toString();
					String grade = getMovieRegistrationPanel().getMovieRegTxtGrade().getSelectedItem().toString();
					String producer = getMovieRegistrationPanel().getMovieRegTxtPro().getText();
					String director = getMovieRegistrationPanel().getMovieRegTxtDir().getText();
					String[] tempLeadingActor = getMovieRegistrationPanel().getMovieRegTxtLeadAc().getText()
							.split(", ");
					String[] tempSupportingActor = getMovieRegistrationPanel().getMovieRegTxtSupAc().getText()
							.split(", ");
					// String 배열을 ArrayList로 변환
					ArrayList<String> leadingActor = new ArrayList<>(Arrays.asList(tempLeadingActor));
					ArrayList<String> supportingActor = new ArrayList<>(Arrays.asList(tempSupportingActor));

					// 새로운 Movie생성
					setMovie(new Movie(name, genre, grade, producer, director, leadingActor, supportingActor));
					// 아직 영화객체안에 시네마가 아무것도 없지만 다음단계에 필요하기 때문에 미리 초기화해서 만들어둔다
					getMovie().setCinemaList(new ArrayList<Cinema>());
					getMovieRegistrationPanel().setVisible(false);
					getCinemaRegistrationPanel().setVisible(true);
					getMovieRegistrationPanel().removeAll();
					cinemaRegistrationPanel();
				}
			}
		});

		// 돌아가기
		getMovieRegistrationPanel().getMovieRegBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 초기화
				getMovieRegistrationPanel().setVisible(false);
				getAdminMainPanel().setVisible(true);
				setMovie(new Movie());
				getMovieRegistrationPanel().removeAll();
				adminMainPanel();
			}
		});
	}

	public void mainPanel() {
		getMainPanel().mainPage();
		getSeatPanel().removeAll();
		main();
	}

	public void main() {
		// main에 들어온 유저컨트롤러는 최신DB를 가지고있다
		// 다시한번 영화 최신화
		getUserController().updateUserDB();
		// 초기화
		getMainPanel().getPrevvbtn().setEnabled(true);
		getMainPanel().getNexttbtn().setEnabled(true);
		setTimeCount(0);
		setSeatCount(0);
		// 영화이름에서 필터링된 cinema객체 모음
		setChoiceCinemaList1(new ArrayList<Cinema>());
		setChoiceCinemaList2(new ArrayList<Cinema>());
		setChoiceCinemaList3(new ArrayList<Cinema>());
		setChoiceCinemaList4(new ArrayList<Cinema>());
		setValue("");
		getMainPanel().getTicketPrice().setText("");
		getMainPanel().getDate().setText(getValue());
		updateMovieDB();
		// deleteMovieDB(getMovieDB().getArrayList(), "d");
		// updateMovieDB();
		// 티켓리스트 최신화
		updateTicketDB();
		// 로그인 위치에 이름달기
		getMainPanel().getUserNameLabel().setText(getUserController().getUser().getName());
		// 들어오자마자 영화 이름 세팅
		String[] movieName = new String[getMovieDB().getArrayList().size()];
		Movie[] movieRating = new Movie[getMovieDB().getArrayList().size()];
		// 티켓구매기준으로 다시 정렬
		// 디비초기화구문 - Count를 초기화할때 사용
		/*
		 * for (Movie movie : getMovieDB().getArrayList()) {
		 * movie.setTicketPurchaseCount(0); }
		 * getMovieDB().saveMovieDB(getMovieDB().getArrayList());
		 */

		for (int i = 0; i < movieName.length; i++) {
			movieRating[i] = getMovieDB().getArrayList().get(i);
		}
		Arrays.sort(movieRating);
		for (int i = 0; i < movieRating.length; i++) {
			// System.out.println("영화 순서 : "+movieRating[i].getName() + " " +
			// movieRating[i].getTicketPurchaseCount());
			movieName[i] = movieRating[i].getName();

		}
		getMainPanel().getMylist().setListData((String[]) movieName);

		// 버튼 닫아놓기 순서에 맞게 필요할때마다 오픈한다
		getMainPanel().getAllBtn().setEnabled(false);
		getMainPanel().getCgvBtn().setEnabled(false);
		getMainPanel().getMegaBtn().setEnabled(false);
		getMainPanel().getLotteBtn().setEnabled(false);
		getMainPanel().getUserMainNextBtn().setEnabled(false);
		for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
			getMainPanel().getMainCinemaList()[i].setEnabled(false);
			getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
		}
		for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
			getMainPanel().getMainTimeList()[i].setEnabled(false);
			getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
		}
		// 예매확인버튼
		getMainPanel().getUserMainUserCartBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getMainStartDateL().setText("");
				getMainPanel().getTime().setText(getScreenName());
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);

				String[] s = { "" };
				getMainPanel().getCityChoice().setListData((String[]) s);
				getMainPanel().getCity2Choice().setListData((String[]) s);
				getMainPanel().getCity3Choice().setListData((String[]) s);
				setValue("");
				getMainPanel().getDate().setText("");
				getMainPanel().getTicketPrice().setText("");
				getMainPanel().setVisible(false);
				getTicketInfoPanel().setVisible(true);
				getMainPanel().removeAll();
				ticketInfoPanel();
			}
		});

		// 전체 버튼
		getMainPanel().getAllBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 전체버튼이 불렸을 경우
				// 시네마모음집 크기
				// String[] city = new String[getMovie().getCinemaList().size()];
				// 전체버튼이 해줘야할일 set도해서 중복없애기 처리해줘야한다.
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getTicketPrice().setText("");
				getMainPanel().getMainStartDateL().setText("");
				getMainPanel().getTime().setText(getScreenName());
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn2.jpg"));
				getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
				getMainPanel().getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
				getMainPanel().getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));
				// 각 도 시 지점 리스트 초기화
				String[] s = { "" };
				getMainPanel().getCityChoice().setListData((String[]) s);
				getMainPanel().getCity2Choice().setListData((String[]) s);
				getMainPanel().getCity3Choice().setListData((String[]) s);
				setValue("");
				getMainPanel().getDate().setText("");
				ArrayList<String> temp = new ArrayList<String>();
				for (Cinema cinema : getMovie().getCinemaList()) {
					if (cinema != null) {
						getChoiceCinemaList1().add(cinema);
						temp.add(cinema.getCity());
					}
				}
				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temp);
				temp.clear();
				temp.addAll(hs);
				String[] cityList = new String[temp.size()];
				for (int i = 0; i < cityList.length; i++) {
					cityList[i] = temp.get(i);
				}
				getMainPanel().getCityChoice().setListData((String[]) cityList);
				getMainPanel().getCinemaName().setText("");
				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
			}
		});

		// CGV 버튼
		getMainPanel().getCgvBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// CGV버튼이 눌렸을경우
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getMainStartDateL().setText("");
				getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn1.jpg"));
				getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn2.jpg"));
				getMainPanel().getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
				getMainPanel().getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));
				// 각 도 시 지점 리스트 초기화
				String[] s = { "" };
				getMainPanel().getCityChoice().setListData((String[]) s);
				getMainPanel().getCity2Choice().setListData((String[]) s);
				getMainPanel().getCity3Choice().setListData((String[]) s);
				getMainPanel().getCinemaName().setText("");
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getTime().setText(getScreenName());
				// 초기화
				getChoiceCinemaList1().clear();
				getChoiceCinemaList2().clear();
				getChoiceCinemaList3().clear();
				getChoiceCinemaList4().clear();
				setValue("");
				getMainPanel().getDate().setText("");
				// 영화 객체 필터링
				getMainPanel().getTicketPrice().setText("");
				ArrayList<String> temp = new ArrayList<String>();
				ArrayList<Cinema> temps = new ArrayList<Cinema>();
				for (Cinema cinema : getMovie().getCinemaList()) {
					if (cinema != null) {
						temps.add(cinema);
						temp.add(cinema.getCity());
					}
				}
				// temps< 전체 객체가 들어있다
				getChoiceCinemaList1().clear();
				// temps는 영화에 걸린것을그대로 가져온것 조건에 필터링해서 다시 getChoiceCinemaList1()에 넣어줘야함
				for (Cinema c : temps) {
					if (c.getName().equals("CGV")) {
						getChoiceCinemaList1().add(c);
					}
				}
				temp.clear();
				for (Cinema c : getChoiceCinemaList1()) {
					if (c != null) {
						temp.add(c.getCity());
					}
				}
				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temp);
				temp.clear();
				temp.addAll(hs);
				String[] cityList = new String[temp.size()];
				for (int i = 0; i < cityList.length; i++) {
					cityList[i] = temp.get(i);
				}
				getMainPanel().getCityChoice().setListData((String[]) cityList);

				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}

			}
		});

		// 메가 버튼
		getMainPanel().getMegaBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 메가박스버튼이 눌렸을경우
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getMainStartDateL().setText("");
				getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn1.jpg"));
				getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
				getMainPanel().getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn2.jpg"));
				getMainPanel().getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));
				// 각 도 시 지점 리스트 초기화
				String[] s = { "" };
				getMainPanel().getCityChoice().setListData((String[]) s);
				getMainPanel().getCity2Choice().setListData((String[]) s);
				getMainPanel().getCity3Choice().setListData((String[]) s);
				getMainPanel().getCinemaName().setText("");

				// 초기화
				getChoiceCinemaList1().clear();
				getChoiceCinemaList2().clear();
				getChoiceCinemaList3().clear();
				getChoiceCinemaList4().clear();
				setValue("");
				getMainPanel().getDate().setText("");
				// 영화 객체 필터링
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				getMainPanel().getTicketPrice().setText("");
				setTimeCount(0);
				getMainPanel().getTime().setText(getScreenName());
				ArrayList<String> temp = new ArrayList<String>();
				ArrayList<Cinema> temps = new ArrayList<Cinema>();
				for (Cinema cinema : getMovie().getCinemaList()) {
					if (cinema != null) {
						temps.add(cinema);
						temp.add(cinema.getCity());
					}
				}
				getChoiceCinemaList1().clear();
				// temps는 영화에 걸린것을그대로 가져온것 조건에 필터링해서 다시 getChoiceCinemaList1()에 넣어줘야함
				for (Cinema c : temps) {
					if (c.getName().equals("메가박스")) {
						getChoiceCinemaList1().add(c);
					}
				}
				temp.clear();
				for (Cinema c : getChoiceCinemaList1()) {
					if (c != null) {
						temp.add(c.getCity());
					}
				}

				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temp);
				temp.clear();
				temp.addAll(hs);
				// temp확인
				String[] cityList = new String[temp.size()];
				for (int i = 0; i < cityList.length; i++) {
					cityList[i] = temp.get(i);
				}
				getMainPanel().getCityChoice().setListData((String[]) cityList);

				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
			}
		});

		// 롯데 버튼
		getMainPanel().getLotteBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 롯데시네마버튼이 눌렸을경우
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				setTimeCount(0);
				getMainPanel().getTime().setText(getScreenName());
				getMainPanel().getMainStartDateL().setText("");
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn1.jpg"));
				getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
				getMainPanel().getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
				getMainPanel().getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn2.jpg"));
				// 각 도 시 지점 리스트 초기화
				String[] s = { "" };
				getMainPanel().getCityChoice().setListData((String[]) s);
				getMainPanel().getCity2Choice().setListData((String[]) s);
				getMainPanel().getCity3Choice().setListData((String[]) s);
				getMainPanel().getCinemaName().setText("");
				// 초
				// 초기화
				getChoiceCinemaList1().clear();
				getChoiceCinemaList2().clear();
				getChoiceCinemaList3().clear();
				getChoiceCinemaList4().clear();
				setValue("");
				getMainPanel().getDate().setText(getValue());
				getMainPanel().getTicketPrice().setText("");
				// 영화 객체 필터링

				ArrayList<String> temp = new ArrayList<String>();
				ArrayList<Cinema> temps = new ArrayList<Cinema>();
				for (Cinema cinema : getMovie().getCinemaList()) {
					if (cinema != null) {
						temps.add(cinema);
						temp.add(cinema.getCity());
					}
				}
				// temps는 영화에 걸린것을그대로 가져온것 조건에 필터링해서 다시 getChoiceCinemaList1()에 넣어줘야함
				getChoiceCinemaList1().clear();
				for (Cinema c : temps) {
					if (c.getName().equals("롯데시네마")) {
						getChoiceCinemaList1().add(c);
					}
				}
				temp.clear();
				for (Cinema c : getChoiceCinemaList1()) {
					if (c != null) {
						temp.add(c.getCity());
					}
				}
				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temp);
				temp.clear();
				temp.addAll(hs);
				// temp확인

				String[] cityList = new String[temp.size()];
				for (int i = 0; i < cityList.length; i++) {
					cityList[i] = temp.get(i);
				}
				getMainPanel().getCityChoice().setListData((String[]) cityList);

				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {

					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
			}
		});

		// 영화선택
		getMainPanel().getMylist().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getTime().setText(getScreenName());
				for (Movie movie : getMovieDB().getArrayList()) {

					if (getMainPanel().getMylist().getSelectedValue().equals(movie.getName())) {
						getMainPanel().setCiName(new JLabel(movie.getName()));
						setMovie(movie);
						break;
					}
				}
				if (getMovie().getGrade().equals("전체 이용가")) {
					// 전체버튼을 누른다

					getMainPanel().getPoster()
							.setIcon(new ImageIcon("./images/moviePoster/" + getMovie().getName() + ".jpg"));
					getMainPanel().getAllBtn().setEnabled(true);
					getMainPanel().getCgvBtn().setEnabled(true);
					getMainPanel().getMegaBtn().setEnabled(true);
					getMainPanel().getLotteBtn().setEnabled(true);
					getMainPanel().getPrevvbtn().setEnabled(true);
					getMainPanel().getNexttbtn().setEnabled(true);
					getMainPanel().getTitle().setText(getMovie().getName());
					getMainPanel().getCinemaName().setText("전체");
					getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn2.jpg"));
					getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
					getMainPanel().getMegaBtn().setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
					getMainPanel().getLotteBtn().setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));
					getMainPanel().getTicketPrice().setText("");
					// 각 도 시 지점 리스트 초기화
					String[] s = { "" };
					getMainPanel().getCityChoice().setListData((String[]) s);
					getMainPanel().getCity2Choice().setListData((String[]) s);
					getMainPanel().getCity3Choice().setListData((String[]) s);
					// 초기화
					getChoiceCinemaList1().clear();
					getChoiceCinemaList2().clear();
					getChoiceCinemaList3().clear();
					getChoiceCinemaList4().clear();
					ArrayList<String> temp = new ArrayList<String>();
					for (Cinema cinema : getMovie().getCinemaList()) {
						if (cinema != null) {
							getChoiceCinemaList1().add(cinema);
							temp.add(cinema.getCity());
						}
					}
					// city중복제거
					HashSet hs = new HashSet();
					hs.addAll(temp);
					temp.clear();
					temp.addAll(hs);
					// temp확인

					String[] cityList = new String[temp.size()];
					for (int i = 0; i < cityList.length; i++) {
						cityList[i] = temp.get(i);
					}
					getMainPanel().getCityChoice().setListData((String[]) cityList);
					getMainPanel().getCinemaName().setText("");

				} else {
					if (Integer.parseInt(getMovie().getGrade().replace("세", "")) > Integer
							.parseInt(getUserController().getUser().getAge())) {
						JOptionPane.showMessageDialog(null, "관람등급 제한 연령입니다.");
						setMovie(new Movie());
						getMainPanel().removeAll();
						mainPanel();
					} else {
						// 전체버튼을 누른다
						getMainPanel().getPoster()
								.setIcon(new ImageIcon("./images/moviePoster/" + getMovie().getName() + ".jpg"));
						getMainPanel().getAllBtn().setEnabled(true);
						getMainPanel().getCgvBtn().setEnabled(true);
						getMainPanel().getMegaBtn().setEnabled(true);
						getMainPanel().getPrevvbtn().setEnabled(true);
						getMainPanel().getNexttbtn().setEnabled(true);
						getMainPanel().getLotteBtn().setEnabled(true);
						getMainPanel().getTicketPrice().setText("");
						getMainPanel().getTitle().setText(getMovie().getName());
						getMainPanel().getCinemaName().setText("전체");
						getMainPanel().getAllBtn().setIcon(new ImageIcon("./images/userMainPage/userMainAllBtn2.jpg"));
						getMainPanel().getCgvBtn().setIcon(new ImageIcon("./images/userMainPage/userMainCgvBtn1.jpg"));
						getMainPanel().getMegaBtn()
								.setIcon(new ImageIcon("./images/userMainPage/userMainMegaBtn1.jpg"));
						getMainPanel().getLotteBtn()
								.setIcon(new ImageIcon("./images/userMainPage/userMainLotteBtn1.jpg"));

						// 각 도 시 지점 리스트 초기화
						String[] s = { "" };
						getMainPanel().getCityChoice().setListData((String[]) s);
						getMainPanel().getCity2Choice().setListData((String[]) s);
						getMainPanel().getCity3Choice().setListData((String[]) s);
						// 초기화
						getChoiceCinemaList1().clear();
						getChoiceCinemaList2().clear();
						getChoiceCinemaList3().clear();
						getChoiceCinemaList4().clear();
						ArrayList<String> temp = new ArrayList<String>();
						for (Cinema cinema : getMovie().getCinemaList()) {
							if (cinema != null) {
								getChoiceCinemaList1().add(cinema);
								temp.add(cinema.getCity());
							}
						}
						// city중복제거
						HashSet hs = new HashSet();
						hs.addAll(temp);
						temp.clear();
						temp.addAll(hs);
						// temp확인

						String[] cityList = new String[temp.size()];
						for (int i = 0; i < cityList.length; i++) {
							cityList[i] = temp.get(i);
						}
						getMainPanel().getCityChoice().setListData((String[]) cityList);
						getMainPanel().getCinemaName().setText("");
						getMainPanel().getMainStartDateL().setText("");
						setValue("");
						getMainPanel().getDate().setText(getValue());
					}
				}
			}
		});
		// 도 선택
		getMainPanel().getCityChoice().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// 초기화
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getTicketPrice().setText("");
				getMainPanel().getTime().setText(getScreenName());
				getChoiceCinemaList2().clear();
				getChoiceCinemaList3().clear();
				getChoiceCinemaList4().clear();
				for (Cinema c : getChoiceCinemaList1()) {
					if (c.getCity().equals((String) getMainPanel().getCityChoice().getSelectedValue())) {
						getChoiceCinemaList2().add(c);
					}
				}
				// 도가 선택됬을경우 지점리스트를 초기화
				String[] s = { "" };
				getMainPanel().getCity3Choice().setListData((String[]) s);

				ArrayList<String> temp = new ArrayList<String>();
				for (Cinema cinema : getChoiceCinemaList2()) {
					if (cinema != null) {
						temp.add(cinema.getBorough());
					}
				}
				String[] boroughArray = new String[3];
				Iterator<String> boroughKey = getMainPanel().getBorough().keySet().iterator();
				String city = (String) getMainPanel().getCityChoice().getSelectedValue();
				ArrayList<String> temp2 = new ArrayList<String>();
				while (boroughKey.hasNext()) {
					String cityKey = boroughKey.next();
					if (cityKey.equals(city)) {
						for (int i = 0; i < getMainPanel().getBorough().get(city).length; i++) {
							boroughArray[i] = getMainPanel().getBorough().get(city)[i];
						}
						break;
					}
				}
				ArrayList<String> temps = new ArrayList<String>();
				for (String str : temp) {
					if (boroughArray[0].equals(str)) {
						temps.add(str);
					} else if (boroughArray[1].equals(str)) {
						temps.add(str);
					} else if (boroughArray[2].equals(str)) {
						temps.add(str);
					}
				}

				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temps);
				temps.clear();
				temps.addAll(hs);
				// temp확인

				String[] boList = new String[temps.size()];
				for (int i = 0; i < boList.length; i++) {
					boList[i] = temps.get(i);
				}
				getMainPanel().getCity2Choice().setListData((String[]) boList);
				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {

					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getMainStartDateL().setText("");
				setValue("");
				getMainPanel().getDate().setText(getValue());
			}
		});
		// 시 선택
		getMainPanel().getCity2Choice().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// 빈 시네마리스트가 필요해서 초기화함
				setScreenName("");
				setScreenTime("");
				setSeatCount(0);
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getTicketPrice().setText("");
				setTimeCount(0);
				getMainPanel().getTime().setText(getScreenName());
				getChoiceCinemaList3().clear();
				getChoiceCinemaList4().clear();
				for (Cinema c : getChoiceCinemaList2()) {
					if (c.getBorough().equals((String) getMainPanel().getCity2Choice().getSelectedValue())) {
						getChoiceCinemaList3().add(c);

					}
				}

				ArrayList<String> areaTemp = new ArrayList<String>();
				ArrayList<String> cinemaTemp = new ArrayList<String>();
				for (Cinema cinema : getChoiceCinemaList3()) {
					if (cinema != null) {
						cinemaTemp.add(cinema.getName());
						areaTemp.add(cinema.getArea());
					}
				}
				String[] areaArray = new String[2];
				Iterator<String> areaKey = getMainPanel().getArea().keySet().iterator();
				String borough = (String) getMainPanel().getCity2Choice().getSelectedValue();
				ArrayList<String> temp2 = new ArrayList<String>();
				while (areaKey.hasNext()) {
					String boroughKey = areaKey.next();
					if (boroughKey.equals(borough)) {
						for (int i = 0; i < getMainPanel().getArea().get(borough).length; i++) {
							areaArray[i] = getMainPanel().getArea().get(borough)[i];
						}
						break;
					}
				}
				ArrayList<String> temp = new ArrayList<String>();
				for (int i = 0; i < areaTemp.size(); i++) {
					if (areaArray[0].equals(areaTemp.get(i))) {
						temp.add(cinemaTemp.get(i) + " " + areaTemp.get(i));
					} else if (areaArray[1].equals(areaTemp.get(i))) {
						temp.add(cinemaTemp.get(i) + " " + areaTemp.get(i));
					}
				}

				// city중복제거
				HashSet hs = new HashSet();
				hs.addAll(temp);
				temp.clear();
				temp.addAll(hs);
				// temp확인

				String[] areaList = new String[temp.size()];
				for (int i = 0; i < areaList.length; i++) {
					areaList[i] = temp.get(i);
				}
				getMainPanel().getCity3Choice().setListData((String[]) areaList);

				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {

					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
				getMainPanel().getCinemaName().setText("");
				getMainPanel().getMainStartDateL().setText("");
				setValue("");
				getMainPanel().getDate().setText(getValue());
			}
		});
		// 지점 선택
		getMainPanel().getCity3Choice().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setScreenName("");
				getMainPanel().getPrevvbtn().setEnabled(true);
				getMainPanel().getNexttbtn().setEnabled(true);
				getMainPanel().getTicketPrice().setText("");
				setScreenTime("");
				setSeatCount(0);
				setTimeCount(0);
				getMainPanel().getTime().setText(getScreenName());
				getChoiceCinemaList4().clear();
				String value = (String) getMainPanel().getCity3Choice().getSelectedValue();

				// 빈 시네마리스트가 필요해서 초기화함 = 2번초기화
				for (Cinema c : getChoiceCinemaList3()) {
					if (c != null) {
						if (value.equals(c.getName() + " " + c.getArea())) {
							getChoiceCinemaList4().add(c);
							// 최종 선택된 cinema
							setCinema(c);
						}
					}
				}

				for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
					getMainPanel().getMainCinemaList()[i].setEnabled(false);
					getMainPanel().getMainCinemaList()[i].setBackground(Color.WHITE);
				}
				for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
					getMainPanel().getMainTimeList()[i].setEnabled(false);
					getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
				}
				getMainPanel().getCinemaName().setText(getCinema().getName() + " " + getCinema().getArea());
				getMainPanel().getMainStartDateL()
						.setText(getCinema().getStartDate() + "                " + getCinema().getEndDate());
				setValue("");
				getMainPanel().getDate().setText(getValue());
			}
		});

		// 메인문에 캘린더 이벤트처리
		// getCinemaRegistrationPanel().getDate(); 현재 달력의 년도 + 달
		// DayView테이블이벤트처리
		getMainPanel().getDayViewTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// day일 로 출력되는 구문인데 이걸 여러개 선택 할 수 있게 해야하는데 되나?
				int row = getMainPanel().getDayViewTable().getSelectedRow();// 열
				int column = getMainPanel().getDayViewTable().getSelectedColumn();// 행
				String value = "";
				if (getMainPanel().getDayViewTable().getValueAt(row, column).toString().replace(" ", "").equals("")) {
					value = "";// 현재 선택값
				} else {
					value = getMainPanel().getDayViewTable().getValueAt(row, column).toString().replace(" ", "");// 현재
					String[] startStr;
					String[] endStr;
					String[] chDate;
					chDate = getMainPanel().getCalDate().split("\\.");
					startStr = getCinema().getStartDate().split("\\.");
					endStr = getCinema().getEndDate().split("\\.");

					String startyy = startStr[0];
					String startmm = startStr[1];
					String endyy = endStr[0];
					String endmm = endStr[1];
					String startdd = startStr[2];
					String enddd = endStr[2];
					if (value.equals(null)) {
						JOptionPane.showMessageDialog(null, "관람이 불가한 날입니다. 다시 선택해주세요.");
					} else {
						// yy가 같은 경우
						if (Integer.parseInt(chDate[0]) == Integer.parseInt(startStr[0])) {
							getMainPanel().getPrevvbtn().setEnabled(false);
							getMainPanel().getNexttbtn().setEnabled(false);
							// mm이 같은 경우
							if (Integer.parseInt(startStr[1]) == Integer.parseInt(chDate[1])) {
								getMainPanel().getPrevvbtn().setEnabled(false);
								getMainPanel().getNexttbtn().setEnabled(false);
								// dd값이 상영예정일부터 종영예정일 사이에만 예매가 가능하다
								if (Integer.parseInt(startStr[2]) <= Integer.parseInt(value)
										&& Integer.parseInt(endStr[2]) >= Integer.parseInt(value)) {
									setScreenName("");
									setTimeCount(0);
									// 선택값
									String ymd = getMainPanel().getCalDate() + "." + value;
									// 시네마 컨트롤러라 초기화해야함
									setValue(ymd);
									// 상영관 시간버튼 활성화
									getMainPanel().getDate().setText(getValue());
									Set set = getCinema().getScreenList().entrySet();
									Iterator iterator = set.iterator();
									ArrayList<String> screenKeyList = new ArrayList<String>(); // 상영관 받아올리스트
									ArrayList<ArrayList<String>> timeValueList = new ArrayList<ArrayList<String>>(); // 상영관
																														// 받아올리스트
									while (iterator.hasNext()) {
										Map.Entry entry = (Map.Entry) iterator.next();
										String key = (String) entry.getKey();
										screenKeyList.add(key);
										ArrayList<String> v = (ArrayList<String>) entry.getValue();
										timeValueList.add(v);

									}

									setScreenName("");
									setScreenTime("");
									setSeatCount(0);
									setTimeCount(0);
									getMainPanel().getTicketPrice().setText("");
									getMainPanel().getTime().setText(getScreenName());
									for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
										for (String screenName : screenKeyList) {
											if (screenName != null) {
												if (getMainPanel().getMainCinemaList()[i].getText()
														.equals(screenName.replace("관", ""))) {
													getMainPanel().getMainCinemaList()[i].setEnabled(true);
													getMainPanel().getMainCinemaList()[i].setBackground(Color.white);
													getMainPanel().getMainTimeList()[i].setBackground(Color.white);
												} else {
													getMainPanel().getMainCinemaList()[i].setEnabled(false);
													getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
													getMainPanel().getMainCinemaList()[i].setBackground(Color.white);
												}
											}
										}
									}
									// 이벤트가 동작 될 때 마다 상영관과 시간 버튼 부분을 전부 초기화한다
									setScreenName("");
									setScreenTime("");
									setSeatCount(0);
									setTimeCount(0);
									getMainPanel().getTicketPrice().setText("");
									getMainPanel().getTime().setText(getScreenName());
									for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
										for (ArrayList<String> timeValue : timeValueList) {
											for (String time : timeValue) {
												if (time != null) {
													if (getMainPanel().getMainTimeList()[i].getText().equals(time)) {
														getMainPanel().getMainTimeList()[i].setEnabled(true);
													} else {
														getMainPanel().getMainCinemaList()[i]
																.setBackground(Color.white);
														getMainPanel().getMainCinemaList()[i]
																.setBackground(Color.white);
													}

												}
											}
										}
									}
								} else {
									// 이벤트가 동작 될 때 마다 상영관과 시간 버튼 부분을 전부 초기화한다
									JOptionPane.showMessageDialog(null, "관람이 불가한 날입니다. 다시 선택해주세요.");
									setScreenName("");
									setScreenTime("");
									setSeatCount(0);
									setTimeCount(0);
									getMainPanel().getPrevvbtn().setEnabled(true);
									getMainPanel().getNexttbtn().setEnabled(true);
									getMainPanel().getTicketPrice().setText("");
									for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
										getMainPanel().getMainCinemaList()[i].setEnabled(false);
										getMainPanel().getMainCinemaList()[i].setBackground(Color.white);
										getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
									}
									for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
										getMainPanel().getMainTimeList()[i].setEnabled(false);
										getMainPanel().getMainCinemaList()[i].setBackground(Color.white);
										getMainPanel().getMainTimeList()[i].setBackground(Color.WHITE);
									}
								}
								// mm이 상영 예정달 < 선택한 달
								// 상영 예정달의 상영 예정일부터 선택한달
							} else {
								JOptionPane.showMessageDialog(null, "관람이 불가한 달입니다. 다시 선택해주세요.");
								getMainPanel().getPrevvbtn().setEnabled(true);
								getMainPanel().getNexttbtn().setEnabled(true);
							}
						} else {
							JOptionPane.showMessageDialog(null, "관람이 불가한 년도입니다. 다시 선택해주세요.");
							getMainPanel().getPrevvbtn().setEnabled(true);
							getMainPanel().getNexttbtn().setEnabled(true);
						}
					}
				}
			}
		});

		// 상영관
		for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
			getMainPanel().getMainCinemaList()[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (int i = 0; i < getMainPanel().getMainCinemaList().length; i++) {
						if (e.getSource() == getMainPanel().getMainCinemaList()[i]
								&& getMainPanel().getMainCinemaList()[i].getBackground() == Color.white) {
							if (getSeatCount() < 1) {
								// setIndex(i);
								getMainPanel().getMainCinemaList()[i].setBackground(Color.CYAN);
								setScreenName(getMainPanel().getMainCinemaList()[i].getText());
								setFlag(true);
								setSeatCount(getSeatCount() + 1);
								getMainPanel().getTicketPrice().setText("");
								getMainPanel().getTime().setText(getScreenName() + "관");
								break;
							} else {
								JOptionPane.showMessageDialog(null, "상영관은 하나만 선택 가능합니다.");
								break;
							}
						} else if (e.getSource() == getMainPanel().getMainCinemaList()[i]
								&& getMainPanel().getMainCinemaList()[i].getBackground() == Color.CYAN) {
							getMainPanel().getMainCinemaList()[i].setBackground(Color.white);
							for (int j = 0; j < getMainPanel().getMainTimeList().length; j++) {
								getMainPanel().getMainTimeList()[j].setBackground(Color.white);
							}
							setScreenName("");
							setTimeCount(0);
							getMainPanel().getTicketPrice().setText("");
							setSeatCount(getSeatCount() - 1);
							setFlag(false);
							getMainPanel().getTime().setText(getScreenName());
							break;
						}
					}

				}
			});
		}
		// 시간
		for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
			getMainPanel().getMainTimeList()[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (isFlag() && getSeatCount() <= 1 && getSeatCount() > 0) {
						for (int i = 0; i < getMainPanel().getMainTimeList().length; i++) {
							if (e.getSource() == getMainPanel().getMainTimeList()[i]
									&& getMainPanel().getMainTimeList()[i].getBackground() == Color.white) {
								if (getTimeCount() < 1) {
									// setIndex(i);
									getMainPanel().getMainTimeList()[i].setBackground(Color.CYAN);
									setScreenTime(getMainPanel().getMainTimeList()[i].getText());
									setFlag(true);
									setTimeCount(getTimeCount() + 1);
									getMainPanel().getUserMainNextBtn().setEnabled(true);
									// 걸러보자시네마로
									for (Cinema cinema : getChoiceCinemaList4()) {
										if (cinema != null) {
											getMainPanel().getTicketPrice().setText(cinema.getPrice());
											break;
										}
									}

									// 예매정보화면 띄워주면될듯
									getMainPanel().getTime().setText(getScreenName() + "관 " + " " + getScreenTime());
									break;
								} else {
									JOptionPane.showMessageDialog(null, "상영 시간은 하나만 선택 가능합니다.");
									break;
								}
							} else if (e.getSource() == getMainPanel().getMainTimeList()[i]
									&& getMainPanel().getMainTimeList()[i].getBackground() == Color.CYAN) {
								getMainPanel().getMainTimeList()[i].setBackground(Color.white);
								setScreenTime("");
								getMainPanel().getTicketPrice().setText("");
								setTimeCount(getTimeCount() - 1);
								getMainPanel().getTime().setText(getScreenName() + "관 " + " " + getScreenTime());

							}
						}
					} else {
						JOptionPane.showMessageDialog(null, "상영관을 먼저 선택해주세요.");
					}

				}
			});
		}

		// 달력이전버튼
		getMainPanel().getPrevvbtn().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getMainPanel().do_prevvbtn_actionPerformed(e);
			}
		});
		// 달력다음버튼
		getMainPanel().getNexttbtn().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getMainPanel().do_nexttbtn_actionPerformed(e);
			}
		});

		// 예매하기 - 티켓만들어야함
		getMainPanel().getUserMainNextBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// 앞에서 선택한 정보를 바탕으로 setTicket(new Ticket())<<내가지금 선택해서 작성하고 있는 Ticket 좌석만 선택안된티켓
				// 티켓DB에서 티켓들을 담고있는 어레이 리스트다 temp = getTicketDB().getArrayList()
				// getTicketDB().getArrayList()요기안에서 영화명>시네마명>도>시>지점>관람날짜>상영관>상영시간 까지 똑같은
				// ticket이 있는지 확인해야함(검색해야함)
				// 만약 이것이 존재하면 그 ticket의 seatList에 들어가서 true false를 찾은다음 그것으로 seatPanel을 구성해야함
				// 밑이 내가 메인화면에서 값을 긁어서 새로 생성하는 Ticket 객체

				String movieName = (String) getMainPanel().getMylist().getSelectedValue(); // 선택한 영화이름
				String city = (String) getMainPanel().getCityChoice().getSelectedValue(); // 선택한 도
				String borough = (String) getMainPanel().getCity2Choice().getSelectedValue(); // 선택한 시
				String areaValue = (String) getMainPanel().getCity3Choice().getSelectedValue(); // 선택한 지점
				String[] str = areaValue.split(" ");
				String brandName = str[0]; // 브랜드네임
				String area = str[1]; // 강남점
				String date = getValue(); // 선택한 날짜

				if (brandName.equals("CGV")) {
					setTicket(new Ticket(movieName, brandName, "6000", city, borough, area, date, getScreenName() + "관",
							getScreenTime()));
				} else if (brandName.equals("메가박스")) {
					setTicket(new Ticket(movieName, brandName, "7000", city, borough, area, date, getScreenName() + "관",
							getScreenTime()));
				} else if (brandName.equals("롯데시네마")) {
					setTicket(new Ticket(movieName, brandName, "8000", city, borough, area, date, getScreenName() + "관",
							getScreenTime()));
				}
				// 구매자 아이디를 넣어둔다
				getTicket().setUserId(getUserController().getUser().getId());
				// 영화 장르를 넣어둔다
				getTicket().setTicketMovieGenre(getMovie().getGenre());
				setValue("");
				getMainPanel().setVisible(false);
				getSeatPanel().setVisible(true);
				seatPanel();
			}
		});
		// 로그아웃
		getMainPanel().getUserMainLogOutBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "로그아웃합니다.");
				getMainPanel().setVisible(false);
				getUserController().getLoginPanel().setVisible(true);
				// 티켓초기화
				setTicket(new Ticket());
				// 유저초기화
				getUserController().setUser(new User());
				getMainPanel().removeAll();
				getUserController().loginPanel();

			}
		});
	}

	public void seatPanel() {
		getSeatPanel().seatPage();
		seat();
	}

	public void seat() {
		// 시트초기화
		// 시트 리스트 초기화
		boolean[] ticketSeatList = new boolean[49];
		for (int i = 0; i < ticketSeatList.length; i++) {
			ticketSeatList[i] = false;
		}
		getTicket().setTicketSeatList(ticketSeatList);
		// 좌석
		setSeatCount(0);
		setClient(4);
		// 티켓디비 최신화
		updateTicketDB();

		// 기본좌석 생성 구문
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				int k = i * 7 + j;
				String str = new Integer(k + 1).toString();
				getSeatPanel().getSeatNum()[k] = new JButton(str);
				getSeatPanel().getSeatScreenPn().add(getSeatPanel().getSeatNum()[k] = new JButton(str));
				getSeatPanel().getSeatNum()[k].setBackground(Color.WHITE);
				getSeatPanel().getSeatNum()[k].setFont(new Font("맑은 고딕", Font.PLAIN, 15));
				getSeatPanel().getSeatNum()[k].setHorizontalAlignment(JLabel.CENTER);
				getSeatPanel().getSeatNum()[k].setOpaque(true);
			}
		}

		// Ticket덩어리
		for (Ticket ticket : getTicketDB().getArrayList()) {
			if (ticket != null) {
				if (ticket.getTicketAllInfo().equals(getTicket().getTicketAllInfo())) {
					for (int i = 0; i < 7; i++) {
						for (int j = 0; j < 7; j++) {
							int k = i * 7 + j;
							// 이미 예매된 것을 티켓을보고 색을 바꾸는 조건문
							if (ticket.getTicketSeatList()[k] == true) {
								getSeatPanel().getSeatNum()[k].setBackground(Color.lightGray);
							}
						}
					}
				}
			}
		}
		// 좌석 선택하기
		ArrayList<String> labelTxt = new ArrayList<String>();
		JButton[] bts = getSeatPanel().getSeatNum();
		for (int i = 0; i < bts.length; i++) {
			bts[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String temp;
					for (int i = 0; i < bts.length; i++) {
						temp = new Integer(i + 1).toString();
						if (getClient() > 0 && e.getSource() == bts[i] && bts[i].getBackground() == Color.white) {
							if (getSeatCount() == 0) {
								bts[i].setBackground(Color.CYAN);
								labelTxt.add(temp + "석");
								getTicket().getTicketSeatList()[i] = true;
								String strs = "";
								for (String seatText : labelTxt) {
									if (labelTxt != null) {
										strs += seatText + " ";
										getSeatPanel().getSeatLabel().setText(strs);
									}
								}
								setSeatCount(getSeatCount() + 1);
								setClient(getClient() - 1);
								break;
							} else if (getSeatCount() == 1) {
								bts[i].setBackground(Color.CYAN);
								labelTxt.add(temp + "석");
								getTicket().getTicketSeatList()[i] = true;
								String strs = "";
								for (String seatText : labelTxt) {
									if (labelTxt != null) {
										strs += seatText + " ";
										getSeatPanel().getSeatLabel().setText(strs);
									}
								}
								setSeatCount(getSeatCount() + 1);
								setClient(getClient() - 1);
								break;
							} else if (getSeatCount() == 2) {
								bts[i].setBackground(Color.CYAN);
								labelTxt.add(temp + "석");
								getTicket().getTicketSeatList()[i] = true;
								String strs = "";
								for (String seatText : labelTxt) {
									if (labelTxt != null) {
										strs += seatText + " ";
										getSeatPanel().getSeatLabel().setText(strs);
									}
								}
								setSeatCount(getSeatCount() + 1);
								setClient(getClient() - 1);
								break;
							} else if (getSeatCount() == 3) {
								bts[i].setBackground(Color.CYAN);
								labelTxt.add(temp + "석");
								getTicket().getTicketSeatList()[i] = true;
								String strs = "";
								for (String seatText : labelTxt) {
									if (labelTxt != null) {
										strs += seatText + " ";
										getSeatPanel().getSeatLabel().setText(strs);
									}
								}
								setSeatCount(getSeatCount() + 1);
								setClient(getClient() - 1);
								break;
							}
						} else if (e.getSource() == bts[i] && bts[i].getBackground() == Color.CYAN) {
							bts[i].setBackground(Color.white);
							getTicket().getTicketSeatList()[i] = false;
							setSeatCount(getSeatCount() - 1);
							setClient(getClient() + 1);
							for (String str : labelTxt) {
								if (str != null) {
									if (str.equals(temp + "석")) {
										labelTxt.remove(str);
										break;
									}
								}
							}
							String strs = "";
							if (getSeatCount() == 0) {
								getSeatPanel().getSeatLabel().setText("");
							} else {
								for (String seatText : labelTxt) {
									if (labelTxt != null) {
										strs += seatText + " ";
										getSeatPanel().getSeatLabel().setText(strs);
									}
								}
							}

							break;
						} else if (getClient() > 0 && e.getSource() == bts[i]
								&& bts[i].getBackground() == Color.lightGray) {
							JOptionPane.showMessageDialog(null, "이미 예매된 좌석입니다. 다른 좌석 골라라");
							break;
						} else if (getClient() == 0 && e.getSource() == bts[i]) {
							JOptionPane.showMessageDialog(null, "제한인원을 초과하였습니다.");
							break;
						}
					}
				}

			});
		}

		// 돌아가기
		getSeatPanel().getSeatBackBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// 초기화
				setTimeCount(0);
				setSeatCount(0);
				getSeatPanel().setVisible(false);
				getMainPanel().setVisible(true);
				getSeatPanel().removeAll();
				getMainPanel().removeAll();
				mainPanel();
			}
		});
		// 결제btn 결제창 이동
		getSeatPanel().getSeatNextBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// 좌석
				setSeatCount(0);
				// 4개제한
				setClient(4);
				boolean flag = false;
				for (int i = 0; i < getTicket().getTicketSeatList().length; i++) {
					if (getTicket().getTicketSeatList()[i] == true) {
						flag = true;
					}
				}
				if (flag == true) {
					getSeatPanel().setVisible(false);
					getPayPanel().setVisible(true);
					getPayPanel().removeAll();
					payPanel();

					Integer count = 0;
					ArrayList<String> seatNumber = new ArrayList<String>();
					String[] seatNum = { "", "", "", "" };
					Integer seatCount = 0;
					for (int i = 0; i < getTicket().getTicketSeatList().length; i++) {
						String temp = new Integer(i + 1).toString();
						if (getTicket().getTicketSeatList()[i] == true) {
							seatNum[seatCount] = temp;
							seatCount += 1;
						}
					}
					String s = "";
					for (String str : seatNum) {
						if (!str.equals("")) {
							s += "[" + str + "] ";
							// 좌석번호 입력
							getPayPanel().getSeat().setText(s);
						}
					}
					// 관람인원 입력
					getPayPanel().getMember().setText(seatCount.toString() + "명");

					// 영화정보 포스터 입력
					getPayPanel().getPoster()
							.setIcon(new ImageIcon("./images/moviePoster/" + getMovie().getName() + ".jpg"));

					// 영화정보 제목 입력
					getPayPanel().getTitle().setText(getTicket().getTicketMovieName());

					// 영화정보 날짜 입력
					getPayPanel().getDate().setText(getTicket().getTicketDate());

					// 영화정보 시간 입력
					getPayPanel().getTime().setText(getTicket().getTicketTime());

					// 금액정보 티켓가격 및 수수료 입력
					Integer ticketPrice = (Integer.parseInt(getTicket().getTicketPrice())) * seatCount * 90 / 100;
					Integer commition = (Integer.parseInt(getTicket().getTicketPrice()) * seatCount) - ticketPrice;
					Integer totalPrice = Integer.parseInt(getTicket().getTicketPrice()) * seatCount;
					getPayPanel().getTicketPrice().setText(ticketPrice.toString());
					getPayPanel().getReservCommition().setText(commition.toString());

					// 금액정보 총가격 입력
					getPayPanel().getTotalPrice().setText(totalPrice.toString());
				} else {
					JOptionPane.showMessageDialog(null, "좌석을 먼저 선택해주세요.");
					getSeatPanel().removeAll();
					seatPanel();
				}

			}
		});

	}

	public void payPanel() {
		getPayPanel().PayPage();
		pay();
	}

	public void billPanel() {
		getBillPanel().billPage();
	}

	public void pay() {
		// 결제 버튼 눌렀을때 액션
		getPayPanel().getPayBtn().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// 결제방법으로 선택된값 저장
				String howToPay = getPayPanel().getPayCombo().getSelectedItem().toString();

				// 결제방법에 따라 CreditPanel, AccountPanel, PhonePanel 각각 켜줌
				if (howToPay.equals("신용카드")) {
					getCreditPanel().creditPage();
					// 신용카드 입력확인 버튼 액션리스너.
					getCreditPanel().getInputBtn().addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							// 공백이 있을시 경고문 출력
							if (getCreditPanel().getCardNum().getText().equals("")
									|| getCreditPanel().getCvcNum().getText().equals("")
									|| getCreditPanel().getMmyy().getText().equals("")) {
								JOptionPane.showMessageDialog(null, "빈칸이 존재합니다. 항목을 입력하세요");

							} else {
								// 공백이 없으면 입력한 정보 출력 후 CreditPanel의 Confirm버튼 활성화
								getCreditPanel().setCardNumSave(getCreditPanel().getCardNum().getText());
								getCreditPanel().setCvcNumSave(getCreditPanel().getCvcNum().getText());
								getCreditPanel().setMmyySave(getCreditPanel().getMmyy().getText());
								JOptionPane.showMessageDialog(null,
										"카드번호 : " + getCreditPanel().getCardNumSave() + "\n" + "cvc : "
												+ getCreditPanel().getCvcNumSave() + "\n" + "유효기간 : "
												+ getCreditPanel().getMmyySave());
								getCreditPanel().getConfirmBtn().setEnabled(true);
							}
							// CreditPanel Confirm버튼 눌렀을때 이벤트처리
							getCreditPanel().getConfirmBtn().addActionListener(new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									// BillPanel 띄우기 전에 BillPanel에 들어갈 값들 정리 현재는 결제방법, 좌석, 인원수(인원수는 이후 요금결제에도 필요)
									String creditCard = "카드결제";
									getBillPanel().setHowToPay(new JLabel(creditCard));

									Integer count = 0;
									ArrayList<String> seatNumber = new ArrayList<String>();
									String[] seatNum = { "", "", "", "" };
									Integer seatCount = 0;
									for (int i = 0; i < getTicket().getTicketSeatList().length; i++) {
										String temp = new Integer(i + 1).toString();
										if (getTicket().getTicketSeatList()[i] == true) {
											seatNum[seatCount] = temp;
											seatCount += 1;
										}
									}
									String s = "";
									for (String str : seatNum) {
										if (!str.equals("")) {

											s += "[" + str + "] ";
											getBillPanel().setSeatNum(new JLabel(s));
										}
									}
									getBillPanel().setBillMemberNum(new JLabel(seatCount.toString() + "명"));

									// 로그인 되어있는 객체의 핸드폰 번호를 가져와 BillPanel에 넣기
									if (getUserController().getUser().isLogin() == true) {
										getBillPanel().setPhoneNum(
												new JLabel(getUserController().getUser().getPhoneNumber()));
									}
									// 임의의 티켓값
									Integer ticketPrice = Integer.parseInt(getTicket().getTicketPrice()) * seatCount;
									// 잔액이 티켓값보다 많을때 결제 승인이 이루어지고 결제창 닫고 BillPanel 띄워줌
									if (getUserController().getUser().getPay() >= ticketPrice) {
										getCreditPanel().close();
										getBillPanel().billPage();
										// bill지에 티켓값 입력
										getBillPanel().getPayMoney().setText(ticketPrice.toString());
										// bill에 타이틀 입력
										getBillPanel().getBillMovieTitle().setText(getTicket().getTicketMovieName());
										// bill에 상영시간 입력
										getBillPanel().getRunningTime().setText(getTicket().getTicketTime());
										// bill에 상영관 입력
										getBillPanel().getTheater().setText(getTicket().getTicketCinemaName()
												+ getTicket().getTicketArea() + getTicket().getTicketCinema());
										// BillPanel의 완료버튼 누를때 userDB의 돈을 가져와 티켓가격을 빼고 다시 userDB에 save
										// BillPanel 닫아주고 결제화면 초기화, 메인화면 초기화 후 메인화면으로 이동
										getBillPanel().getComplete().addActionListener(new ActionListener() {

											@Override
											public void actionPerformed(ActionEvent e) {
												ArrayList<User> temp = new ArrayList<User>();
												temp = getUserController().getUserDB().loadUserDB();
												for (User user : temp) {
													if (user instanceof Guest) {
														if (getUserController().getUser().getId()
																.equals(user.getId())) {
															user.setPay(getUserController().getUser().getPay()
																	- (ticketPrice));
															getUserController().getUser()
																	.setPay(getUserController().getUser().getPay()
																			- (ticketPrice));
															getUserController().getUser().setTicket(getTicket());
															user.setTicket(getTicket());
														}
													}
												}
												for (Movie movie : getMovieDB().getArrayList()) {
													if (movie != null) {
														if (movie.getName().equals(getMovie().getName())) {
															movie.setTicketPurchaseCount(
																	getMovie().getTicketPurchaseCount() + 1);
														}
													}
												}
												getMovieDB().saveMovieDB(getMovieDB().getArrayList());
												// 밑에 2줄은 TicketDB에 좌석값 저장
												getTicketDB().getArrayList().add(getTicket());
												getTicketDB().saveTicketDB(getTicketDB().getArrayList());
												getUserController().getUserDB().saveUserDB(temp);
												getBillPanel().close();
												getPayPanel().setVisible(false);
												getMainPanel().setVisible(true);
												getMainPanel().removeAll();
												getPayPanel().removeAll();
												mainPanel();
											}
										});

									} else {
										JOptionPane.showMessageDialog(null, "잔액이 모자랍니다!");
										getCreditPanel().close();
									}

								}
							});
						}
					});

				} else if (howToPay.equals("계좌이체")) {
					getAccountPanel().accountPage();
					getAccountPanel().getInputBtn().addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (getAccountPanel().getAccountNum().getText().equals("")
									|| getAccountPanel().getPassword().getText().equals("")
									|| getAccountPanel().getOTP().getText().equals("")) {
								JOptionPane.showMessageDialog(null, "빈칸이 존재합니다. 항목을 입력하세요");

							} else {
								getAccountPanel().setAccountNumSave(getAccountPanel().getAccountNum().getText());
								getAccountPanel().setPasswordSave(getAccountPanel().getPassword().getText());
								getAccountPanel().setOTPSave(getAccountPanel().getOTP().getText());
								JOptionPane.showMessageDialog(null,
										"계좌번호 : " + getAccountPanel().getAccountNumSave() + "\n" + "비밀번호 : "
												+ getAccountPanel().getPasswordSave() + "\n" + "OTP : "
												+ getAccountPanel().getOTPSave());
								getAccountPanel().getConfirmBtn().setEnabled(true);
							}
							getAccountPanel().getConfirmBtn().addActionListener(new ActionListener() {

								public void actionPerformed(ActionEvent arg0) {
									String account = "계좌이체";
									getBillPanel().setHowToPay(new JLabel(account));
									Integer count = 0;
									ArrayList<String> seatNumber = new ArrayList<String>();
									String[] seatNum = { "", "", "", "" };
									Integer seatCount = 0;
									for (int i = 0; i < getTicket().getTicketSeatList().length; i++) {
										String temp = new Integer(i + 1).toString();
										if (getTicket().getTicketSeatList()[i] == true) {
											seatNum[seatCount] = temp;
											seatCount += 1;
										}
									}
									String s = "";
									for (String str : seatNum) {
										if (!str.equals("")) {
											s += "[" + str + "] ";
											getBillPanel().setSeatNum(new JLabel(s));
										}
									}
									getBillPanel().setBillMemberNum(new JLabel(seatCount.toString() + "명"));

									// 로그인 되어있는 객체의 핸드폰 번호를 가져와 BillPanel에 넣기
									if (getUserController().getUser().isLogin() == true) {
										getBillPanel().setPhoneNum(
												new JLabel(getUserController().getUser().getPhoneNumber()));
									}
									// 임의의 티켓값
									Integer ticketPrice = Integer.parseInt(getTicket().getTicketPrice()) * seatCount;
									// 잔액이 티켓값보다 많을때 결제 승인이 이루어지고 결제창 닫고 BillPanel 띄워줌
									if (getUserController().getUser().getPay() >= ticketPrice) {
										getAccountPanel().close();
										getBillPanel().billPage();
										// bill지에 티켓값 입력
										getBillPanel().getPayMoney().setText(ticketPrice.toString());
										// bill에 타이틀 입력
										getBillPanel().getBillMovieTitle().setText(getTicket().getTicketMovieName());
										// bill에 상영시간 입력
										getBillPanel().getRunningTime().setText(getTicket().getTicketTime());
										// bill에 상영관 입력
										getBillPanel().getTheater().setText(getTicket().getTicketCinemaName()
												+ getTicket().getTicketArea() + getTicket().getTicketCinema());
										// BillPanel의 완료버튼 누를때 userDB의 돈을 가져와 티켓가격을 빼고 다시 userDB에 save
										// BillPanel 닫아주고 결제화면 초기화, 메인화면 초기화 후 메인화면으로 이동
										getBillPanel().getComplete().addActionListener(new ActionListener() {

											@Override
											public void actionPerformed(ActionEvent e) {
												ArrayList<User> temp = new ArrayList<User>();
												temp = getUserController().getUserDB().loadUserDB();
												for (User user : temp) {
													if (user instanceof Guest) {
														if (getUserController().getUser().getId()
																.equals(user.getId())) {
															user.setPay(getUserController().getUser().getPay()
																	- (ticketPrice));
															getUserController().getUser()
																	.setPay(getUserController().getUser().getPay()
																			- (ticketPrice));
															getUserController().getUser().setTicket(getTicket());
															user.setTicket(getTicket());
														}
													}
												}
												for (Movie movie : getMovieDB().getArrayList()) {
													if (movie != null) {
														if (movie.getName().equals(getMovie().getName())) {
															movie.setTicketPurchaseCount(
																	getMovie().getTicketPurchaseCount() + 1);
														}
													}
												}
												getMovieDB().saveMovieDB(getMovieDB().getArrayList());
												// 밑에 2줄은 TicketDB에 좌석값 저장
												getTicketDB().getArrayList().add(getTicket());
												getTicketDB().saveTicketDB(getTicketDB().getArrayList());
												getUserController().getUserDB().saveUserDB(temp);
												getBillPanel().close();
												getPayPanel().setVisible(false);
												getMainPanel().setVisible(true);
												getMainPanel().removeAll();
												getPayPanel().removeAll();
												mainPanel();
											}
										});
									} else {
										JOptionPane.showMessageDialog(null, "잔액이 모자랍니다!");
										getAccountPanel().close();
									}
								}
							});
						}
					});

				} else {
					getPhonePanel().phonePage();
					// 인증번호 발송버튼 화면에 랜덤인 4자리수 발생시켜서 TextField 생성해서 값을 넣는다
					getPhonePanel().getPressNumBtn().addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							getPhonePanel().setRandom((int) (Math.random() * 9999) + 1);
							while (getPhonePanel().getRandom() < 1000) {
								getPhonePanel().setRandom((int) ((Math.random() * 9999) + 1));
							}
							// 랜덤 발생시킨 값 String으로 저장
							String numStr = String.valueOf(getPhonePanel().getRandom());

							JTextField randomNum = new JTextField();
							randomNum.setBounds(150, 90, 120, 25);
							getPhonePanel().getPhonePage().add(randomNum);
							randomNum.setEditable(false);
							randomNum.setText(numStr);
							// 인증번호 입력후 확인할 버튼 텍스트필드의 값과 위에 저장한 랜덤한 숫자를 비교 일치한다면 승인버튼 활성화
							getPhonePanel().getSendingBtn().addActionListener(new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									getPhonePanel().setInput(getPhonePanel().getInputNum().getText());
									if (getPhonePanel().getInput().equals(numStr)) {
										getPhonePanel().getConfirm().setVisible(true);
										getPhonePanel().getConfirmBtn().setEnabled(true);
									} else {
										JOptionPane.showMessageDialog(null, "인증번호를 다시 확인하세요.");
									}
								}
							});
						}
					});
					// 결제 승인버튼 이벤트처리
					getPhonePanel().getConfirmBtn().addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							String phone = "핸드폰 결제";
							getBillPanel().setHowToPay(new JLabel(phone));
							Integer count = 0;
							ArrayList<String> seatNumber = new ArrayList<String>();
							String[] seatNum = { "", "", "", "" };
							Integer seatCount = 0;
							for (int i = 0; i < getTicket().getTicketSeatList().length; i++) {
								String temp = new Integer(i + 1).toString();
								if (getTicket().getTicketSeatList()[i] == true) {
									seatNum[seatCount] = temp;
									seatCount += 1;
								}
							}
							String s = "";
							for (String str : seatNum) {
								if (!str.equals("")) {
									s += "[" + str + "] ";
									getBillPanel().setSeatNum(new JLabel(s));
								}
							}
							getBillPanel().setBillMemberNum(new JLabel(seatCount.toString() + "명"));

							// 로그인 되어있는 객체의 핸드폰 번호를 가져와 BillPanel에 넣기
							if (getUserController().getUser().isLogin() == true) {
								getBillPanel().setPhoneNum(new JLabel(getUserController().getUser().getPhoneNumber()));
							}
							// 임의의 티켓값
							Integer ticketPrice = Integer.parseInt(getTicket().getTicketPrice()) * seatCount;
							// 잔액이 티켓값보다 많을때 결제 승인이 이루어지고 결제창 닫고 BillPanel 띄워줌
							if (getUserController().getUser().getPay() >= ticketPrice) {
								getPhonePanel().close();
								getBillPanel().billPage();
								// bill지에 티켓값 입력
								getBillPanel().getPayMoney().setText(ticketPrice.toString());
								// bill에 타이틀 입력
								getBillPanel().getBillMovieTitle().setText(getTicket().getTicketMovieName());
								// bill에 상영시간 입력
								getBillPanel().getRunningTime().setText(getTicket().getTicketTime());
								// bill에 상영관 입력
								getBillPanel().getTheater().setText(getTicket().getTicketCinemaName()
										+ getTicket().getTicketArea() + getTicket().getTicketCinema());
								// BillPanel의 완료버튼 누를때 userDB의 돈을 가져와 티켓가격을 빼고 다시 userDB에 save
								// BillPanel 닫아주고 결제화면 초기화, 메인화면 초기화 후 메인화면으로 이동
								getBillPanel().getComplete().addActionListener(new ActionListener() {

									@Override
									public void actionPerformed(ActionEvent e) {
										ArrayList<User> temp = new ArrayList<User>();
										temp = getUserController().getUserDB().loadUserDB();
										for (User user : temp) {
											if (user instanceof Guest) {
												if (getUserController().getUser().getId().equals(user.getId())) {
													user.setPay(getUserController().getUser().getPay() - (ticketPrice));
													getUserController().getUser().setPay(
															getUserController().getUser().getPay() - (ticketPrice));
													getUserController().getUser().setTicket(getTicket());
													user.setTicket(getTicket());
												}
											}
										}
										for (Movie movie : getMovieDB().getArrayList()) {
											if (movie != null) {
												if (movie.getName().equals(getMovie().getName())) {
													movie.setTicketPurchaseCount(
															getMovie().getTicketPurchaseCount() + 1);
												}
											}
										}
										getMovieDB().saveMovieDB(getMovieDB().getArrayList());
										// 밑에 2줄은 TicketDB에 좌석값 저장
										getTicketDB().getArrayList().add(getTicket());
										getTicketDB().saveTicketDB(getTicketDB().getArrayList());
										getUserController().getUserDB().saveUserDB(temp);

										getBillPanel().close();
										getPayPanel().setVisible(false);
										getMainPanel().setVisible(true);
										getMainPanel().removeAll();
										getPayPanel().removeAll();
										mainPanel();
									}
								});
							} else {
								JOptionPane.showMessageDialog(null, "잔액이 모자랍니다!");
								getPhonePanel().close();
							}

						}
					});

				}
			}
		});
		// 이전버튼 눌렀을때 액션 -> 좌석으로 돌아감 (성공) 티켓의 좌석 리스트를 초기화
		getPayPanel().getPrevBtn().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				getPayPanel().setVisible(false);
				getSeatPanel().setVisible(true);
				getPayPanel().removeAll();
				getSeatPanel().removeAll();
				seatPanel();

			}
		});

// 필수동의 체크박스 해야 결제 활성화 -> 성공
		getPayPanel().getFirstCheckBox().addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (!(getPayPanel().getFirstCheckBox().isSelected()
						&& getPayPanel().getSecondCheckBox().isSelected())) {
					getPayPanel().getPayBtn().setEnabled(false);
				} else {
					getPayPanel().getPayBtn().setEnabled(true);
				}

			}
		});

// 필수동의 체크박스 해야 결제 활성화 -> 성공
		getPayPanel().getSecondCheckBox().addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (!(getPayPanel().getFirstCheckBox().isSelected()
						&& getPayPanel().getSecondCheckBox().isSelected())) {
					getPayPanel().getPayBtn().setEnabled(false);
				} else {
					getPayPanel().getPayBtn().setEnabled(true);
				}

			}
		});

	}

	// getter setter
	public AdminUserInfoPanel getAdminUserInfoPanel() {
		return adminUserInfoPanel;
	}

	public void setAdminUserInfoPanel(AdminUserInfoPanel adminUserInfoPanel) {
		this.adminUserInfoPanel = adminUserInfoPanel;
	}

	public AdminMovieInfoPanel getAdminMovieInfoPanel() {
		return adminMovieInfoPanel;
	}

	public void setAdminMovieInfoPanel(AdminMovieInfoPanel adminMovieInfoPanel) {
		this.adminMovieInfoPanel = adminMovieInfoPanel;
	}

	public CinemaRegistrationPanel getCinemaRegistrationPanel() {
		return cinemaRegistrationPanel;
	}

	public void setCinemaRegistrationPanel(CinemaRegistrationPanel cinemaRegistrationPanel) {
		this.cinemaRegistrationPanel = cinemaRegistrationPanel;
	}

	public MovieDB getMovieDB() {
		return movieDB;
	}

	public void setMovieDB(MovieDB movieDB) {
		this.movieDB = movieDB;
	}

	public ArrayList getModel() {
		return model;
	}

	public void setModel(ArrayList model) {
		this.model = model;
	}

	public ArrayList getView() {
		return view;
	}

	public void setView(ArrayList view) {
		this.view = view;
	}

	public UserController getUserController() {
		return userController;
	}

	public void setUserController(UserController userController) {
		this.userController = userController;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Cinema getCinema() {
		return cinema;
	}

	public void setCinema(Cinema cinema) {
		this.cinema = cinema;
	}

	public MainPanel getMainPanel() {
		return mainPanel;
	}

	public void setMainPanel(MainPanel mainPanel) {
		this.mainPanel = mainPanel;
	}

	public AdminMainPanel getAdminMainPanel() {
		return adminMainPanel;
	}

	public void setAdminMainPanel(AdminMainPanel adminMainPanel) {
		this.adminMainPanel = adminMainPanel;
	}

	public MovieRegistrationPanel getMovieRegistrationPanel() {
		return movieRegistrationPanel;
	}

	public void setMovieRegistrationPanel(MovieRegistrationPanel movieRegistrationPanel) {
		this.movieRegistrationPanel = movieRegistrationPanel;
	}

	public SeatPanel getSeatPanel() {
		return seatPanel;
	}

	public void setSeatPanel(SeatPanel seatPanel) {
		this.seatPanel = seatPanel;
	}

	public int getSeatCount() {
		return seatCount;
	}

	public void setSeatCount(int seatCount) {
		this.seatCount = seatCount;
	}

	public int getClient() {
		return client;
	}

	public void setClient(int client) {
		this.client = client;
	}

	public BillPanel getBillPanel() {
		return billPanel;
	}

	public void setBillPanel(BillPanel billPanel) {
		this.billPanel = billPanel;
	}

	public PayPanel getPayPanel() {
		return payPanel;
	}

	public void setPayPanel(PayPanel payPanel) {
		this.payPanel = payPanel;
	}

	public CreditPanel getCreditPanel() {
		return creditPanel;
	}

	public void setCreditPanel(CreditPanel creditPanel) {
		this.creditPanel = creditPanel;
	}

	public AccountPanel getAccountPanel() {
		return accountPanel;
	}

	public void setAccountPanel(AccountPanel accountPanel) {
		this.accountPanel = accountPanel;
	}

	public PhonePanel getPhonePanel() {
		return phonePanel;
	}

	public void setPhonePanel(PhonePanel phonePanel) {
		this.phonePanel = phonePanel;
	}

	public ArrayList<String> getTimeList() {
		return timeList;
	}

	public TicketInfoPanel getTicketInfoPanel() {
		return ticketInfoPanel;
	}

	public void setTicketInfoPanel(TicketInfoPanel ticketInfoPanel) {
		this.ticketInfoPanel = ticketInfoPanel;
	}

	public void setTimeList(ArrayList<String> timeList) {
		this.timeList = timeList;
	}

	public HashMap<String, ArrayList<String>> getScreenList() {
		return screenList;
	}

	public void setScreenList(HashMap<String, ArrayList<String>> screenList) {
		this.screenList = screenList;
	}

	public String getScreenTime() {
		return screenTime;
	}

	public void setScreenTime(String screenTime) {
		this.screenTime = screenTime;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public TicketDB getTicketDB() {
		return ticketDB;
	}

	public ArrayList<Cinema> getChoiceCinemaList3() {
		return choiceCinemaList3;
	}

	public void setChoiceCinemaList3(ArrayList<Cinema> choiceCinemaList3) {
		this.choiceCinemaList3 = choiceCinemaList3;
	}

	public ArrayList<Cinema> getChoiceCinemaList4() {
		return choiceCinemaList4;
	}

	public void setChoiceCinemaList4(ArrayList<Cinema> choiceCinemaList4) {
		this.choiceCinemaList4 = choiceCinemaList4;
	}

	public void setTicketDB(TicketDB ticketDB) {
		this.ticketDB = ticketDB;
	}

	public ArrayList<Cinema> getChoiceCinemaList1() {
		return choiceCinemaList1;
	}

	public void setChoiceCinemaList1(ArrayList<Cinema> choiceCinemaList1) {
		this.choiceCinemaList1 = choiceCinemaList1;
	}

	public ArrayList<Cinema> getChoiceCinemaList2() {
		return choiceCinemaList2;
	}

	public void setChoiceCinemaList2(ArrayList<Cinema> choiceCinemaList2) {
		this.choiceCinemaList2 = choiceCinemaList2;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Ticket getOldTicket() {
		return oldTicket;
	}

	public void setOldTicket(Ticket oldTicket) {
		this.oldTicket = oldTicket;
	}

	public int getTimeCount() {
		return timeCount;
	}

	public void setTimeCount(int timeCount) {
		this.timeCount = timeCount;
	}

}

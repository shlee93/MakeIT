package application;

import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;

import controller.CinemaController;
import controller.UserController;
import model.Admin;
import model.Movie;
import model.MovieDB;
import model.Ticket;
import model.TicketDB;
import model.User;
import model.UserDB;
import view.AccountPanel;
import

view.AdminMainPanel;
import view.AdminMovieInfoPanel;
import view.AdminUserInfoPanel;
import view.BillPanel;
import view.CinemaRegistrationPanel;
import view.CreditPanel;
import view.LoginPanel;
import view.MainPanel;
import view.MovieRegistrationPanel;
import view.PayPanel;
import view.PhonePanel;
import view.SeatPanel;
import view.SignUpPanel;
import view.TicketInfoPanel;

public class TMI {
	public static void main(String[] args) {
		User user = new User();
		ArrayList<User> temp = new ArrayList<User>();	
		//Admin admin = new Admin("admin","admin","관리자","30","양성","112",true,true,true);	
		//temp.add(admin);
		UserDB userDB = new UserDB(temp, "userDB.txt");
		MovieDB movieDB = new MovieDB(new ArrayList<Movie>(), "movieDB.txt");
		TicketDB ticketDB = new TicketDB(new ArrayList<Ticket>(), "ticketDB.txt");
		// 모델관리
		ArrayList model = new ArrayList();
		model.add(userDB);
		model.add(movieDB);
		model.add(ticketDB);

		// 뷰관리
		ArrayList view = new ArrayList();
		JFrame frame = new JFrame(); // 메인프레임 이창 전부 공유 모든패널이
		frame.setTitle("Ticket Managing Information Application");
		MainPanel mainPanel = new MainPanel(frame);
		AdminMainPanel adminMainPanel = new AdminMainPanel(frame);
		MovieRegistrationPanel movieRegistrationPanel = new MovieRegistrationPanel(frame);
		CinemaRegistrationPanel cinemaRegistrationPanel = new CinemaRegistrationPanel(frame);
		LoginPanel loginPanel = new LoginPanel(frame);
		SignUpPanel signUpPanel = new SignUpPanel(frame);
		AdminUserInfoPanel adminUserInfoPanel = new AdminUserInfoPanel(frame);
		AdminMovieInfoPanel adminMovieInfoPanel = new AdminMovieInfoPanel(frame);
		SeatPanel seatPanel = new SeatPanel(frame);
		PayPanel payPanel = new PayPanel(frame);
		CreditPanel creditPanel = new CreditPanel();
		AccountPanel accountPanel = new AccountPanel();
		PhonePanel phonePanel = new PhonePanel();
		BillPanel billPanel = new BillPanel();
		TicketInfoPanel ticketInfoPanel = new TicketInfoPanel(frame);
		// add view
		view.add(frame);
		view.add(mainPanel);
		view.add(ticketInfoPanel);
		view.add(adminMainPanel);
		view.add(loginPanel);
		view.add(signUpPanel);
		view.add(movieRegistrationPanel);
		view.add(cinemaRegistrationPanel);
		view.add(adminUserInfoPanel);
		view.add(adminMovieInfoPanel);
		view.add(seatPanel);
		view.add(payPanel);
		view.add(creditPanel);
		view.add(accountPanel);
		view.add(phonePanel);
		view.add(billPanel);

		UserController userController = new UserController(model, view);
		CinemaController cinemaController = new CinemaController(model, view);

		userController.setCinemaController(cinemaController);
		cinemaController.setUserController(userController);

		userController.loginPanel();

		// cinemaController.mainPanel();
		frame.setSize(980, 640);
		frame.setLocationRelativeTo(null);// 창을 가운데 띄움
		frame.setResizable(false); // 고정
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("./images/icon.jpg");
		frame.setIconImage(img);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
	}
}

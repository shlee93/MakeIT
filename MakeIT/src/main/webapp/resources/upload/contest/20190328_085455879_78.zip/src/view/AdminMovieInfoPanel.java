package view;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class AdminMovieInfoPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;
	
	// 영화정보 눌렀을시
	private JTextArea AdminMovieInfoArea;
	private JButton AdminMovieInfoBackBtn;
	private JScrollPane AdminMovieInfoScroll;
	
	public AdminMovieInfoPanel(JFrame frame) {
		this.frame = frame;
	}
	
	public void adminMovieInfoPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);
		
		setImagePanel(new ImagePanel(new ImageIcon("./images/adMovieInfoPage/adMovieInfoBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);
		
		setAdminMovieInfoArea(new JTextArea());
		getAdminMovieInfoArea().setFont(new Font("맑은 고딕", Font.PLAIN, 15));
		
		// 스크롤 추가
		setAdminMovieInfoScroll(new JScrollPane(getAdminMovieInfoArea(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		getAdminMovieInfoScroll().setBounds(69, 106, 841, 366);
			
		getImagePanel().add(getAdminMovieInfoScroll());
		
		setAdminMovieInfoBackBtn(new JButton());
		getAdminMovieInfoBackBtn().setIcon(new ImageIcon("./images/adMovieInfoPage/adMovieInfoBackBtn.jpg"));
		getAdminMovieInfoBackBtn().setBounds(409, 499, 161, 51);
		getImagePanel().add(getAdminMovieInfoBackBtn());

		getFrame().getContentPane().add(this);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public JTextArea getAdminMovieInfoArea() {
		return AdminMovieInfoArea;
	}

	public void setAdminMovieInfoArea(JTextArea adminMovieInfoArea) {
		AdminMovieInfoArea = adminMovieInfoArea;
	}

	public JButton getAdminMovieInfoBackBtn() {
		return AdminMovieInfoBackBtn;
	}

	public void setAdminMovieInfoBackBtn(JButton adminMovieInfoBackBtn) {
		AdminMovieInfoBackBtn = adminMovieInfoBackBtn;
	}

	public JScrollPane getAdminMovieInfoScroll() {
		return AdminMovieInfoScroll;
	}

	public void setAdminMovieInfoScroll(JScrollPane adminMovieInfoScroll) {
		AdminMovieInfoScroll = adminMovieInfoScroll;
	}
}

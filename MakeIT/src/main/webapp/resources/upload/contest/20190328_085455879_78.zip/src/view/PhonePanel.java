package view;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class PhonePanel {
	private PayPanel payPanel;
	private JPanel contentPane;
	private JTextField cardNum;
	private JTextField cvcNum;
	private JTextField mmyy;
	private JTextField accountNum;
	private JTextField password;
	private JTextField OTP;
	private JTextField inputNum;
	private static JTextField randomNum;
	private BillPanel billPanel;
	private int paySelReturn;
	private JPanel creditPage;
	private JPanel phonePage;
	private JPanel AccountPage;
	private int random;
	private static String numStr;
	private static String input;
	private JButton confirmBtn;
	private JButton sendingBtn;
	private JButton pressNumBtn;
	private JLabel confirm;
	private JFrame frame;

	public void phonePage() {
		setFrame(new JFrame());
		getFrame().setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setVisible(true);
		setPhonePage(new JPanel());
		getPhonePage().setBackground(Color.GRAY);
		getPhonePage().setBounds(14, 12, 404, 195);
		contentPane.add(getPhonePage());
		getPhonePage().setLayout(null);

		JLabel phonePayLabel = new JLabel("휴대폰 결제");
		phonePayLabel.setFont(new Font("굴림", Font.BOLD, 15));
		phonePayLabel.setBounds(170, 10, 100, 30);
		getPhonePage().add(phonePayLabel);

		JLabel passNumLabel = new JLabel("인증 번호");
		passNumLabel.setBounds(40, 90, 80, 20);
		getPhonePage().add(passNumLabel);

		JLabel inputNumLabel = new JLabel("인증 번호 입력");
		inputNumLabel.setBounds(40, 122, 100, 20);
		getPhonePage().add(inputNumLabel);

		setPressNumBtn(new JButton("인증번호발송"));
		getPressNumBtn().setBounds(150, 60, 120, 25);
		getPhonePage().add(getPressNumBtn());

		setInputNum(new JTextField());
		getInputNum().setBounds(150, 120, 120, 25);
		getPhonePage().add(getInputNum());
		getInputNum().setColumns(10);

		setSendingBtn(new JButton("전송"));
		getSendingBtn().setBounds(285, 120, 61, 27);
		getPhonePage().add(getSendingBtn());

		setConfirm(new JLabel("확인완료"));
		getConfirm().setBackground(Color.RED);
		getConfirm().setBounds(285, 91, 62, 18);
		getPhonePage().add(getConfirm());
		getConfirm().setVisible(false);

		setConfirmBtn(new JButton("승인"));
		getConfirmBtn().setBounds(170, 215, 80, 40);
		contentPane.add(getConfirmBtn());
		getConfirmBtn().setEnabled(false);

		getPhonePage().setVisible(true);

		getFrame().add(contentPane);
		
		getFrame().setLocationRelativeTo(null);//창을 가운데 띄움
		getFrame().setResizable(false); //고정
		getFrame().setVisible(true);
	}
	
	public void close() {
		getFrame().dispose();
	}

	public PhonePanel() {
	}

	public PayPanel getPayPanel() {
		return payPanel;
	}

	public void setPayPanel(PayPanel payPanel) {
		this.payPanel = payPanel;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JTextField getCardNum() {
		return cardNum;
	}

	public void setCardNum(JTextField cardNum) {
		this.cardNum = cardNum;
	}

	public JTextField getCvcNum() {
		return cvcNum;
	}

	public void setCvcNum(JTextField cvcNum) {
		this.cvcNum = cvcNum;
	}

	public JTextField getMmyy() {
		return mmyy;
	}

	public void setMmyy(JTextField mmyy) {
		this.mmyy = mmyy;
	}

	public JTextField getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(JTextField accountNum) {
		this.accountNum = accountNum;
	}

	public JTextField getPassword() {
		return password;
	}

	public void setPassword(JTextField password) {
		this.password = password;
	}

	public JTextField getOTP() {
		return OTP;
	}

	public void setOTP(JTextField oTP) {
		OTP = oTP;
	}

	public JTextField getInputNum() {
		return inputNum;
	}

	public void setInputNum(JTextField inputNum) {
		this.inputNum = inputNum;
	}

	public static JTextField getRandomNum() {
		return randomNum;
	}

	public static void setRandomNum(JTextField randomNum) {
		PhonePanel.randomNum = randomNum;
	}

	public BillPanel getBillPanel() {
		return billPanel;
	}

	public void setBillPanel(BillPanel billPanel) {
		this.billPanel = billPanel;
	}

	public int getPaySelReturn() {
		return paySelReturn;
	}

	public void setPaySelReturn(int paySelReturn) {
		this.paySelReturn = paySelReturn;
	}

	public JPanel getCreditPage() {
		return creditPage;
	}

	public void setCreditPage(JPanel creditPage) {
		this.creditPage = creditPage;
	}

	public JPanel getPhonePage() {
		return phonePage;
	}

	public void setPhonePage(JPanel phonePage) {
		this.phonePage = phonePage;
	}

	public JPanel getAccountPage() {
		return AccountPage;
	}

	public void setAccountPage(JPanel accountPage) {
		AccountPage = accountPage;
	}

	public int getRandom() {
		return random;
	}

	public void setRandom(int random) {
		this.random = random;
	}

	public static String getNumStr() {
		return numStr;
	}

	public static void setNumStr(String numStr) {
		PhonePanel.numStr = numStr;
	}

	public static String getInput() {
		return input;
	}

	public static void setInput(String input) {
		PhonePanel.input = input;
	}

	public JButton getConfirmBtn() {
		return confirmBtn;
	}

	public void setConfirmBtn(JButton confirmBtn) {
		this.confirmBtn = confirmBtn;
	}

	public JButton getSendingBtn() {
		return sendingBtn;
	}

	public void setSendingBtn(JButton sendingBtn) {
		this.sendingBtn = sendingBtn;
	}

	public JButton getPressNumBtn() {
		return pressNumBtn;
	}

	public void setPressNumBtn(JButton pressNumBtn) {
		this.pressNumBtn = pressNumBtn;
	}

	public JLabel getConfirm() {
		return confirm;
	}

	public void setConfirm(JLabel confirm) {
		this.confirm = confirm;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	
	
}
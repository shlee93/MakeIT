package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class AccountPanel {
	private PayPanel payPanel;
	private JPanel contentPane;
	private JTextField cardNum;
	private JTextField cvcNum;
	private JTextField mmyy;
	private JTextField accountNum;
	private JTextField password;
	private JTextField OTP;
	private JTextField inputNum;
	private BillPanel billPanel;
	private int paySelReturn;
	private JPanel creditPage;
	private JPanel phonePage;
	private JPanel AccountPage;
	private String accountNumSave;
	private String passwordSave;
	private String OTPSave;
	private String[] bank = { "신한은행", "국민은행", "농협은행" };
	private JButton inputBtn;
	private JButton confirmBtn;
	private JFrame frame;

	public void accountPage() {
		
		setFrame(new JFrame());

		getFrame().setBounds(100, 100, 450, 300);
		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setVisible(true);
		JPanel accountPage = new JPanel();
		accountPage.setBackground(Color.GRAY);
		accountPage.setBounds(14, 12, 404, 195);
		contentPane.add(accountPage);
		accountPage.setLayout(null);

		JLabel accountPayLabel = new JLabel("계좌 결제");
		accountPayLabel.setFont(new Font("굴림", Font.BOLD, 15));
		accountPayLabel.setBounds(170, 10, 80, 20);
		accountPage.add(accountPayLabel);

		JLabel bankName = new JLabel("은행");
		bankName.setBounds(40, 40, 80, 20);
		accountPage.add(bankName);

		JLabel accountNumLabel = new JLabel("계좌 번호 ");
		accountNumLabel.setBounds(40, 70, 80, 20);
		accountPage.add(accountNumLabel);

		JLabel passwordLabel = new JLabel("비밀 번호");
		passwordLabel.setBounds(40, 100, 80, 20);
		accountPage.add(passwordLabel);

		JLabel OTPLabel = new JLabel("OTP 번호");
		OTPLabel.setBounds(40, 130, 80, 20);
		accountPage.add(OTPLabel);

		JComboBox bankSel = new JComboBox(bank);
		bankSel.setBounds(140, 40, 120, 20);
		accountPage.add(bankSel);

		password = new JTextField();
		password.setBounds(140, 100, 120, 20);
		accountPage.add(password);
		password.setColumns(10);

		OTP = new JTextField();
		OTP.setBounds(140, 130, 120, 20);
		accountPage.add(OTP);
		OTP.setColumns(10);

		accountNum = new JTextField();
		accountNum.setBounds(140, 70, 210, 20);
		accountPage.add(accountNum);
		accountNum.setColumns(10);

		setInputBtn(new JButton("입력완료"));
		getInputBtn().setBounds(150, 160, 100, 27);
		accountPage.add(getInputBtn());

		setConfirmBtn(new JButton("승인"));
		getConfirmBtn().setBounds(170, 215, 80, 40);
		contentPane.add(getConfirmBtn());
		getConfirmBtn().setEnabled(false);

		

		accountPage.setVisible(true);
		getFrame().add(contentPane);
		getFrame().setLocationRelativeTo(null);//창을 가운데 띄움
		getFrame().setResizable(false); //고정
		getFrame().setVisible(true);
	}

	public AccountPanel() {
	}

	public void close() {
		getFrame().dispose();
	}
	
	public PayPanel getPayPanel() {
		return payPanel;
	}

	public void setPayPanel(PayPanel payPanel) {
		this.payPanel = payPanel;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JTextField getCardNum() {
		return cardNum;
	}

	public void setCardNum(JTextField cardNum) {
		this.cardNum = cardNum;
	}

	public JTextField getCvcNum() {
		return cvcNum;
	}

	public void setCvcNum(JTextField cvcNum) {
		this.cvcNum = cvcNum;
	}

	public JTextField getMmyy() {
		return mmyy;
	}

	public void setMmyy(JTextField mmyy) {
		this.mmyy = mmyy;
	}

	public JTextField getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(JTextField accountNum) {
		this.accountNum = accountNum;
	}

	public JTextField getPassword() {
		return password;
	}

	public void setPassword(JTextField password) {
		this.password = password;
	}

	public JTextField getOTP() {
		return OTP;
	}

	public void setOTP(JTextField oTP) {
		OTP = oTP;
	}

	public JTextField getInputNum() {
		return inputNum;
	}

	public void setInputNum(JTextField inputNum) {
		this.inputNum = inputNum;
	}

	public BillPanel getBillPanel() {
		return billPanel;
	}

	public void setBillPanel(BillPanel billPanel) {
		this.billPanel = billPanel;
	}

	public int getPaySelReturn() {
		return paySelReturn;
	}

	public void setPaySelReturn(int paySelReturn) {
		this.paySelReturn = paySelReturn;
	}

	public JPanel getCreditPage() {
		return creditPage;
	}

	public void setCreditPage(JPanel creditPage) {
		this.creditPage = creditPage;
	}

	public JPanel getPhonePage() {
		return phonePage;
	}

	public void setPhonePage(JPanel phonePage) {
		this.phonePage = phonePage;
	}

	public JPanel getAccountPage() {
		return AccountPage;
	}

	public void setAccountPage(JPanel accountPage) {
		AccountPage = accountPage;
	}

	public String getAccountNumSave() {
		return accountNumSave;
	}

	public void setAccountNumSave(String accountNumSave) {
		this.accountNumSave = accountNumSave;
	}

	public String getPasswordSave() {
		return passwordSave;
	}

	public void setPasswordSave(String passwordSave) {
		this.passwordSave = passwordSave;
	}

	public String getOTPSave() {
		return OTPSave;
	}

	public void setOTPSave(String oTPSave) {
		OTPSave = oTPSave;
	}

	public String[] getBank() {
		return bank;
	}

	public void setBank(String[] bank) {
		this.bank = bank;
	}

	public JButton getInputBtn() {
		return inputBtn;
	}

	public void setInputBtn(JButton inputBtn) {
		this.inputBtn = inputBtn;
	}

	public JButton getConfirmBtn() {
		return confirmBtn;
	}

	public void setConfirmBtn(JButton confirmBtn) {
		this.confirmBtn = confirmBtn;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	
}
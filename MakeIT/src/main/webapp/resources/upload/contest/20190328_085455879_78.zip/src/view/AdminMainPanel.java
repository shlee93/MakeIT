package view;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AdminMainPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;

	private JButton AdminUserInfoBtn;
	private JButton AdminMovieInfoBtn;
	private JButton AdminMovieRegBtn;
	private JButton AdminExitBtn;

	public AdminMainPanel(JFrame frame) {
		this.frame = frame;
	}

	public void adminMainPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);

		setImagePanel(new ImagePanel(new ImageIcon("./images/adminPage/adminBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);
		// ---패널하고 프레임정리
		
		setAdminUserInfoBtn(new JButton());
		getAdminUserInfoBtn().setIcon(new ImageIcon("./images/adminPage/adminUserInfoBtn.jpg"));
		getAdminUserInfoBtn().setBounds(588, 265, 260,68);
		getImagePanel().add(getAdminUserInfoBtn());

		setAdminMovieInfoBtn(new JButton());
		getAdminMovieInfoBtn().setIcon(new ImageIcon("./images/adminPage/adminMovieInfoBtn.jpg"));
		getAdminMovieInfoBtn().setBounds(588, 366, 260, 68);
		getImagePanel().add(getAdminMovieInfoBtn());

		setAdminMovieRegBtn(new JButton());
		getAdminMovieRegBtn().setIcon(new ImageIcon("./images/adminPage/adminMovieRegBtn.jpg"));
		getAdminMovieRegBtn().setBounds(588, 466, 260, 68);
		getImagePanel().add(getAdminMovieRegBtn());

		setAdminExitBtn(new JButton());
		getAdminExitBtn().setIcon(new ImageIcon("./images/adminPage/adminLogoutBtn.jpg"));
		getAdminExitBtn().setBounds(712, 189, 62,27);
		getImagePanel().add(getAdminExitBtn());

		getFrame().getContentPane().add(this);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public JButton getAdminUserInfoBtn() {
		return AdminUserInfoBtn;
	}

	public void setAdminUserInfoBtn(JButton adminUserInfoBtn) {
		AdminUserInfoBtn = adminUserInfoBtn;
	}

	public JButton getAdminMovieInfoBtn() {
		return AdminMovieInfoBtn;
	}

	public void setAdminMovieInfoBtn(JButton adminMovieInfoBtn) {
		AdminMovieInfoBtn = adminMovieInfoBtn;
	}

	public JButton getAdminMovieRegBtn() {
		return AdminMovieRegBtn;
	}

	public void setAdminMovieRegBtn(JButton adminMovieRegBtn) {
		AdminMovieRegBtn = adminMovieRegBtn;
	}

	public JButton getAdminExitBtn() {
		return AdminExitBtn;
	}

	public void setAdminExitBtn(JButton adminExitBtn) {
		AdminExitBtn = adminExitBtn;
	}
}

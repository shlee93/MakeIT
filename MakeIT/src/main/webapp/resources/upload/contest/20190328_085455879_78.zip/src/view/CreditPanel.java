package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class CreditPanel {
	private PayPanel payPanel;
	private JPanel contentPane;
	private JTextField cardNum;
	private JTextField cvcNum;
	private JTextField mmyy;
	private JTextField accountNum;
	private JTextField password;
	private JTextField OTP;
	private JTextField inputNum;
	private BillPanel billPanel;
	private int paySelReturn;
	private JPanel creditPage;
	private JPanel phonePage;
	private JPanel AccountPage;
	private String[] cardName = { "신한카드", "국민카드", "농협카드", "BC카드" };
	private static String cardNumSave;
	private static String cvcNumSave;
	private static String mmyySave;
	private JButton inputBtn;
	private JButton confirmBtn;
	private JFrame frame;
	
	
	public void creditPage() {
		setFrame(new JFrame());
		getFrame().setBounds(100, 100, 450, 300);
		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setVisible(true);

		JPanel creditPage = new JPanel();
		creditPage.setBackground(Color.GRAY);
		creditPage.setBounds(14, 12, 404, 195);
		contentPane.add(creditPage);
		creditPage.setLayout(null);

		JLabel cardPayLabel = new JLabel("카드 결제");
		cardPayLabel.setFont(new Font("굴림", Font.BOLD, 15));
		cardPayLabel.setBounds(170, 10, 80, 20);
		creditPage.add(cardPayLabel);

		JLabel creditName = new JLabel("카드사");
		creditName.setBounds(40, 40, 80, 20);
		creditPage.add(creditName);

		JLabel cardNumLabel = new JLabel("카드 번호");
		cardNumLabel.setBounds(40, 70, 80, 20);
		creditPage.add(cardNumLabel);

		JLabel cvcNumLabel = new JLabel("CVC 번호");
		cvcNumLabel.setBounds(40, 100, 80, 20);
		creditPage.add(cvcNumLabel);

		JLabel mmyyLabel = new JLabel("유효기간");
		mmyyLabel.setBounds(40, 130, 80, 20);
		creditPage.add(mmyyLabel);

		JComboBox creditSel = new JComboBox(cardName);
		creditSel.setBounds(140, 40, 120, 20);
		creditPage.add(creditSel);

		cvcNum = new JTextField();
		cvcNum.setBounds(140, 100, 120, 20);
		creditPage.add(cvcNum);
		cvcNum.setColumns(10);

		mmyy = new JTextField();
		mmyy.setBounds(140, 130, 120, 20);
		creditPage.add(mmyy);
		mmyy.setColumns(10);

		cardNum = new JTextField();
		cardNum.setBounds(140, 70, 210, 20);
		creditPage.add(cardNum);
		cardNum.setColumns(10);
		
		setConfirmBtn(new JButton("승인"));
		getConfirmBtn().setBounds(170, 215, 100, 27);
		contentPane.add(getConfirmBtn());
		getConfirmBtn().setEnabled(false);
		
		setInputBtn(new JButton("입력완료"));
		getInputBtn().setBounds(150, 160, 100, 27);
		creditPage.add(getInputBtn());
		

		creditPage.setVisible(true);
		// payDB.paySelReturn의 값을 가져오는 빌판넬

		/* System.out.println(paySelReturn); */
		getFrame().add(contentPane);
		getFrame().setLocationRelativeTo(null);//창을 가운데 띄움
		getFrame().setResizable(false); //고정
		getFrame().setVisible(true);
	}

	public CreditPanel() {
	
	}
	
	public void close() {
		getFrame().dispose();
	}

	public PayPanel getPayPanel() {
		return payPanel;
	}

	public void setPayPanel(PayPanel payPanel) {
		this.payPanel = payPanel;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JTextField getCardNum() {
		return cardNum;
	}

	public void setCardNum(JTextField cardNum) {
		this.cardNum = cardNum;
	}

	public JTextField getCvcNum() {
		return cvcNum;
	}

	public void setCvcNum(JTextField cvcNum) {
		this.cvcNum = cvcNum;
	}

	public JTextField getMmyy() {
		return mmyy;
	}

	public void setMmyy(JTextField mmyy) {
		this.mmyy = mmyy;
	}

	public JTextField getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(JTextField accountNum) {
		this.accountNum = accountNum;
	}

	public JTextField getPassword() {
		return password;
	}

	public void setPassword(JTextField password) {
		this.password = password;
	}

	public JTextField getOTP() {
		return OTP;
	}

	public void setOTP(JTextField oTP) {
		OTP = oTP;
	}

	public JTextField getInputNum() {
		return inputNum;
	}

	public void setInputNum(JTextField inputNum) {
		this.inputNum = inputNum;
	}

	public BillPanel getBillPanel() {
		return billPanel;
	}

	public void setBillPanel(BillPanel billPanel) {
		this.billPanel = billPanel;
	}

	public int getPaySelReturn() {
		return paySelReturn;
	}

	public void setPaySelReturn(int paySelReturn) {
		this.paySelReturn = paySelReturn;
	}

	public JPanel getCreditPage() {
		return creditPage;
	}

	public void setCreditPage(JPanel creditPage) {
		this.creditPage = creditPage;
	}

	public JPanel getPhonePage() {
		return phonePage;
	}

	public void setPhonePage(JPanel phonePage) {
		this.phonePage = phonePage;
	}

	public JPanel getAccountPage() {
		return AccountPage;
	}

	public void setAccountPage(JPanel accountPage) {
		AccountPage = accountPage;
	}

	public String[] getCardName() {
		return cardName;
	}

	public void setCardName(String[] cardName) {
		this.cardName = cardName;
	}

	public static String getCardNumSave() {
		return cardNumSave;
	}

	public static void setCardNumSave(String cardNumSave) {
		CreditPanel.cardNumSave = cardNumSave;
	}

	public static String getCvcNumSave() {
		return cvcNumSave;
	}

	public static void setCvcNumSave(String cvcNumSave) {
		CreditPanel.cvcNumSave = cvcNumSave;
	}

	public static String getMmyySave() {
		return mmyySave;
	}

	public static void setMmyySave(String mmyySave) {
		CreditPanel.mmyySave = mmyySave;
	}

	public JButton getInputBtn() {
		return inputBtn;
	}

	public void setInputBtn(JButton inputBtn) {
		this.inputBtn = inputBtn;
	}

	public JButton getConfirmBtn() {
		return confirmBtn;
	}

	public void setConfirmBtn(JButton confirmBtn) {
		this.confirmBtn = confirmBtn;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	
	
}
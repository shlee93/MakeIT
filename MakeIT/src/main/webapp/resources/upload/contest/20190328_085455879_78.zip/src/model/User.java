package model;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7351729135012380019L;
	//처음부터 필요한부분
	private String name; 
	private String age; 
	private String gender; 
	private String phoneNumber; 
	private String id; 
	private String password;
	private boolean isSignUp = false; 
	private boolean isLogin = false;
	//처음에 있을 필요가 없는 부분
	private ArrayList<Ticket> ticketList; //장바구니
	private Ticket ticket;
	private int pay = 100000;//다른사람이만듬
	
	public User() {
	}
	
	public User(String id, String password, String name, String age, String gender, String phoneNumber, 
			boolean isSignUp, boolean isLogin) {	
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.id = id;
		this.password = password;
		this.isSignUp = isSignUp;
		this.isLogin = isLogin;
		setTicketList(new ArrayList<Ticket>());
	}
	
	@Override
	public String toString() {
		return "User [name=" + name + ", age=" + age + ", gender=" + gender + ", phoneNumber=" + phoneNumber + ", id="
				+ id + ", password=" + password + ", isSignUp=" + isSignUp + ", isLogin=" + isLogin + ", ticketList="
				+ ticketList + ", ticket=" + ticket + ", pay=" + pay + "]";
	}

	//Getter/Setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isSignUp() {
		return isSignUp;
	}
	public void setSignUp(boolean isSignUp) {
		this.isSignUp = isSignUp;
	}
	public boolean isLogin() {
		return isLogin;
	}
	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}
	public ArrayList<Ticket> getTicketList() {
		return ticketList;
	}

	public void setTicketList(ArrayList<Ticket> ticketList) {
		this.ticketList = ticketList;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
		getTicketList().add(ticket);
	}

	public int getPay() {
		return pay;
	}

	public void setPay(int pay) {
		this.pay = pay;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}

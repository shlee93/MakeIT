package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PayPanel extends JPanel {
	private JFrame frame;
	private JPanel contentPane;
	private JTable firstTable;
	private JTable secondTable;
	private JTextField secondPhone;
	private JTextField thirdPhone;
	private JCheckBox firstCheckBox;
	private JCheckBox secondCheckBox;
	private JComboBox phoneCombo;
	private JComboBox payCombo;
	private JButton prevBtn;
	private JButton payBtn;
	private JLabel poster;
	private JLabel title;
	private JLabel date;
	private JLabel time;
	private JLabel member;
	private JLabel seat;
	private JLabel ticketPrice;
	private JLabel reservCommition;
	private JLabel discountPrice;
	private JLabel totalPrice;
	private String[] firstPhoneNum={"010","011","017","018","019"};
	private String[] howToPay= {"신용카드","계좌이체","핸드폰 결제"};
	private String FirstPhone;

	public PayPanel() {
	
	}

	public PayPanel(JFrame frame) {
		this.frame = frame;
	}

	public void PayPage() {
		setBounds(0, 0, 980, 640);
		setLayout(null);
		setBackground(Color.LIGHT_GRAY);
		setVisible(true);

		JPanel mainPanel = new JPanel();
		mainPanel.setBounds(10, 33, 945, 400);
		mainPanel.setBackground(Color.WHITE);
		this.add(mainPanel);
		mainPanel.setLayout(null);
		setVisible(false);

		JPanel checkPanel = new JPanel();
		checkPanel.setLayout(null);
		checkPanel.setBounds(0, 0, 945, 135);
		checkPanel.setBackground(Color.WHITE);
		mainPanel.add(checkPanel);

		JLabel firstLabel = new JLabel("개인정보 수집, 이용 동의");
		firstLabel.setBounds(25, 10, 150, 15);
		checkPanel.add(firstLabel);
		firstLabel.setVisible(true);

		firstTable = new JTable();
		firstTable.setBounds(25, 30, 400, 64);
		firstTable.setModel(new DefaultTableModel(new Object[][] { { "\uC218\uC9D1\uC8FC\uCCB4", "TMI" }, {
				"\uBAA9\uC801",
				"\uC0C1\uC601\uC2DC\uAC04 \uBCC0\uACBD \uB4F1 \uAE34\uAE09\uD55C \uACBD\uC6B0 \uC5F0\uB77D\uC744 \uC704\uD55C \uBAA9\uC801" },
				{ "\uD56D\uBAA9", "\uC774\uB984, \uD734\uB300\uD3F0\uBC88\uD638, \uC774\uBA54\uC77C \uC8FC\uC18C" },
				{ "\uBCF4\uC720\u318D\uC774\uC6A9\uAE30\uAC04",
						"\uADF9\uC7A5\uC815\uC0B0 \uBC0F \uD68C\uACC4\uCC98\uB9AC\uB97C \uC704\uD574 6\uAC1C\uC6D4 \uBCF4\uAD00" }, },
				new String[] { "", "" }));
		firstTable.getColumnModel().getColumn(0).setPreferredWidth(90);
		firstTable.getColumnModel().getColumn(1).setPreferredWidth(260);
		checkPanel.add(firstTable);

		JLabel secondLabel = new JLabel("제3자 제공 동의");
		secondLabel.setBounds(425, 10, 140, 15);
		checkPanel.add(secondLabel);

		secondTable = new JTable();
		secondTable.setBounds(425, 30, 485, 64);
		secondTable.setModel(new DefaultTableModel(new Object[][] {
				{ "\uC81C\uACF5\uBC1B\uB294 \uC5C5\uCCB4", "\uC608\uB9E4\uADF9\uC7A5 " },
				{ "\uBAA9\uC801\t",
						"\uD604\uC7A5\uD2F0\uCF13 \uBC1C\uAD8C \uC2DC \uBCF8\uC778 \uD655\uC778 \uC0C1\uC601\uC2DC\uAC04 \uBCC0\uACBD \uB4F1 \uAE34\uAE09\uD55C \uACBD\uC6B0 \uC5F0\uB77D\uC744 \uC704\uD55C \uBAA9\uC801" },
				{ "\uD56D\uBAA9", "\uC774\uB984,\uD734\uB300\uD3F0\uBC88\uD638" },
				{ "\uBCF4\uC720\u318D\uC774\uC6A9\uAE30\uAC04",
						"\uADF9\uC7A5\uC815\uC0B0 \uBC0F \uD68C\uACC4\uCC98\uB9AC\uB97C \uC704\uD574 6\uAC1C\uC6D4 \uBCF4\uAD00" }, },
				new String[] { "", "" }));
		secondTable.getColumnModel().getColumn(0).setPreferredWidth(90);
		secondTable.getColumnModel().getColumn(1).setPreferredWidth(420);
		checkPanel.add(secondTable);

		setFirstCheckBox(new JCheckBox("[필수] 개인정보 수집 및 이용에 동의합니다."));
		getFirstCheckBox().setBounds(25, 100, 280, 25);
		getFirstCheckBox().setBackground(Color.WHITE);
		checkPanel.add(getFirstCheckBox());

		setSecondCheckBox(new JCheckBox("[필수] 개인정보 제3자 제공에 동의합니다."));
		getSecondCheckBox().setBounds(425, 100, 270, 25);
		getSecondCheckBox().setBackground(Color.WHITE);
		checkPanel.add(getSecondCheckBox());

		///// 유저 인포 판넬
		JPanel userInfoPanel = new JPanel();
		userInfoPanel.setBounds(290, 180, 400, 100);
		mainPanel.add(userInfoPanel);
		userInfoPanel.setLayout(null);

		JLabel phoneLabel = new JLabel("휴대폰번호");
		phoneLabel.setBounds(10, 10, 65, 15);
		userInfoPanel.add(phoneLabel);

		setSecondPhone(new JTextField());
		getSecondPhone().setBounds(160, 7, 80, 20);
		userInfoPanel.add(getSecondPhone());
		getSecondPhone().setColumns(10);

		setPhoneCombo(new JComboBox(firstPhoneNum));
		getPhoneCombo().setBounds(80, 7, 50, 20);
		userInfoPanel.add(getPhoneCombo());

		setThirdPhone(new JTextField());
		getThirdPhone().setBounds(270, 7, 80, 20);
		userInfoPanel.add(getThirdPhone());
		getThirdPhone().setColumns(10);

		JLabel firstSlashLabel = new JLabel("-");
		firstSlashLabel.setBounds(140, 10, 10, 10);
		userInfoPanel.add(firstSlashLabel);

		JLabel secondSlashLabel = new JLabel("-");
		secondSlashLabel.setBounds(252, 10, 10, 10);
		userInfoPanel.add(secondSlashLabel);

		JLabel payLabel = new JLabel("결제 수단");
		payLabel.setBounds(10, 45, 65, 15);
		userInfoPanel.add(payLabel);

		setPayCombo(new JComboBox(howToPay));
		getPayCombo().setBounds(80, 45, 150, 20);
		userInfoPanel.add(getPayCombo());

		JLabel reservInfoLabel = new JLabel("선택하신 예매정보");
		reservInfoLabel.setBounds(10, 440, 120, 15);
		this/* getContentPane() */.add(reservInfoLabel);

		JPanel movieInfoPanel = new JPanel();
		movieInfoPanel.setBounds(10, 460, 400, 150);
		movieInfoPanel.setBackground(Color.WHITE);
		this/* getContentPane() */.add(movieInfoPanel);
		movieInfoPanel.setLayout(null);

		setPoster(new JLabel());
		getPoster().setBounds(5, 5, 100, 143);
		movieInfoPanel.add(getPoster());
		getPoster().setLayout(null);

		JLabel titleLabel = new JLabel("제     목");
		titleLabel.setBounds(110, 10, 57, 15);
		movieInfoPanel.add(titleLabel);

		JLabel dateLabel = new JLabel("관 람 일");
		dateLabel.setBounds(110, 35, 57, 15);
		movieInfoPanel.add(dateLabel);

		JLabel timeLabel = new JLabel("시     간");
		timeLabel.setBounds(110, 60, 57, 15);
		movieInfoPanel.add(timeLabel);

		JLabel memberLabel = new JLabel("인     원");
		memberLabel.setBounds(110, 85, 57, 15);
		movieInfoPanel.add(memberLabel);

		JLabel seatLabel = new JLabel("좌석정보");
		seatLabel.setBounds(110, 110, 57, 15);
		movieInfoPanel.add(seatLabel);

		setTitle(new JLabel("제목입력"));
		getTitle().setBounds(180, 10, 300, 15);
		movieInfoPanel.add(getTitle());

		setDate(new JLabel("날짜입력"));
		getDate().setBounds(180, 35, 80, 15);
		movieInfoPanel.add(getDate());

		setTime(new JLabel("시간입력"));
		getTime().setBounds(180, 60, 57, 15);
		movieInfoPanel.add(getTime());

		setMember(new JLabel());
		getMember().setBounds(180, 85, 57, 15);
		movieInfoPanel.add(getMember());

		setSeat(new JLabel());
		getSeat().setBounds(180, 110, 120, 15);
		movieInfoPanel.add(getSeat());

		JLabel lblNewLabel = new JLabel("관람요금 정보");
		lblNewLabel.setBounds(420, 440, 100, 15);
		this/* getContentPane() */.add(lblNewLabel);

		JPanel priceInfoPanel = new JPanel();
		priceInfoPanel.setBounds(420, 460, 380, 150);
		priceInfoPanel.setBackground(Color.WHITE);
		this/* getContentPane() */.add(priceInfoPanel);
		priceInfoPanel.setLayout(null);

		JLabel ticketPriceLabel = new JLabel("티켓 금액");
		ticketPriceLabel.setBounds(10, 10, 65, 15);
		priceInfoPanel.add(ticketPriceLabel);

		JLabel reservCommitionLabel = new JLabel("예매 수수료");
		reservCommitionLabel.setBounds(10, 30, 70, 15);
		priceInfoPanel.add(reservCommitionLabel);

		JLabel discountPriceLabel = new JLabel("===========================================================");
		discountPriceLabel.setBounds(10, 50, 380, 15);
		priceInfoPanel.add(discountPriceLabel);

		JLabel totalPriceLabel = new JLabel("총 금액");
		totalPriceLabel.setBounds(10, 85, 65, 15);
		priceInfoPanel.add(totalPriceLabel);

		setTicketPrice(new JLabel("Ticket Price"));
		getTicketPrice().setBounds(300, 10, 75, 15);
		priceInfoPanel.add(getTicketPrice());

		setReservCommition(new JLabel("ReservCommition"));
		getReservCommition().setBounds(300, 30, 75, 15);
		priceInfoPanel.add(getReservCommition());

		setTotalPrice(new JLabel("TotalPrice"));
		getTotalPrice().setBounds(300, 85, 57, 15);
		priceInfoPanel.add(getTotalPrice());

		setPrevBtn(new JButton());
	
		getPrevBtn().setIcon(new ImageIcon("./images/payPage/payBackBtn.jpg"));
		getPrevBtn().setBounds(810, 460, 145, 60);
		this/* getContentPane() */.add(getPrevBtn());

		setPayBtn(new JButton());

		getPayBtn().setIcon(new ImageIcon("./images/payPage/payCalBtn.jpg"));
		getPayBtn().setBounds(810, 530, 145, 60);
		getPayBtn().setEnabled(false);
		this/* getContentPane() */.add(getPayBtn());

		// 메인 프레임에 추가
		getFrame().getContentPane().add(this);
		setVisible(true);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public void setContentPane(JPanel contentPane) {
		this.contentPane = contentPane;
	}

	public JTable getFirstTable() {
		return firstTable;
	}

	public void setFirstTable(JTable firstTable) {
		this.firstTable = firstTable;
	}

	public JTable getSecondTable() {
		return secondTable;
	}

	public void setSecondTable(JTable secondTable) {
		this.secondTable = secondTable;
	}

	public JTextField getSecondPhone() {
		return secondPhone;
	}

	public void setSecondPhone(JTextField secondPhone) {
		this.secondPhone = secondPhone;
	}

	public JTextField getThirdPhone() {
		return thirdPhone;
	}

	public void setThirdPhone(JTextField thirdPhone) {
		this.thirdPhone = thirdPhone;
	}

	public JCheckBox getFirstCheckBox() {
		return firstCheckBox;
	}

	public void setFirstCheckBox(JCheckBox firstCheckBox) {
		this.firstCheckBox = firstCheckBox;
	}

	public JCheckBox getSecondCheckBox() {
		return secondCheckBox;
	}

	public void setSecondCheckBox(JCheckBox secondCheckBox) {
		this.secondCheckBox = secondCheckBox;
	}

	public JComboBox getPhoneCombo() {
		return phoneCombo;
	}

	public void setPhoneCombo(JComboBox phoneCombo) {
		this.phoneCombo = phoneCombo;
	}

	public JComboBox getPayCombo() {
		return payCombo;
	}

	public void setPayCombo(JComboBox payCombo) {
		this.payCombo = payCombo;
	}

	public JButton getPrevBtn() {
		return prevBtn;
	}

	public void setPrevBtn(JButton prevBtn) {
		this.prevBtn = prevBtn;
	}

	public JButton getPayBtn() {
		return payBtn;
	}

	public void setPayBtn(JButton payBtn) {
		this.payBtn = payBtn;
	}

	public JLabel getPoster() {
		return poster;
	}

	public void setPoster(JLabel poster) {
		this.poster = poster;
	}

	public JLabel getTitle() {
		return title;
	}

	public void setTitle(JLabel title) {
		this.title = title;
	}

	public JLabel getDate() {
		return date;
	}

	public void setDate(JLabel date) {
		this.date = date;
	}

	public JLabel getTime() {
		return time;
	}

	public void setTime(JLabel time) {
		this.time = time;
	}

	public JLabel getMember() {
		return member;
	}

	public void setMember(JLabel member) {
		this.member = member;
	}

	public JLabel getSeat() {
		return seat;
	}

	public void setSeat(JLabel seat) {
		this.seat = seat;
	}

	public JLabel getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(JLabel ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public JLabel getReservCommition() {
		return reservCommition;
	}

	public void setReservCommition(JLabel reservCommition) {
		this.reservCommition = reservCommition;
	}

	public JLabel getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(JLabel discountPrice) {
		this.discountPrice = discountPrice;
	}

	public JLabel getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(JLabel totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String[] getFirstPhoneNum() {
		return firstPhoneNum;
	}

	public void setFirstPhoneNum(String[] firstPhoneNum) {
		this.firstPhoneNum = firstPhoneNum;
	}

	public String[] getHowToPay() {
		return howToPay;
	}

	public void setHowToPay(String[] howToPay) {
		this.howToPay = howToPay;
	}

	public String getFirstPhone() {
		return FirstPhone;
	}

	public void setFirstPhone(String firstPhone) {
		FirstPhone = firstPhone;
	}
	

}
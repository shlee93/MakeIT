package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.Admin;
import model.Guest;
import model.Movie;
import model.Ticket;
import model.User;
import model.UserDB;
import view.LoginPanel;
import view.SignUpPanel;

public class UserController {
	private JFrame frame;
	private UserDB userDB;
	private ArrayList model;
	private ArrayList view;
	private CinemaController cinemaController;
	private Ticket ticket;
	private User user;
	private boolean flag = false;
	//패널
	private LoginPanel loginPanel;
	private SignUpPanel signUpPanel;
	//생성자
	public UserController() {
		
	}
	public UserController(ArrayList model, ArrayList view ) {
		this.model = model;
		this.view = view;
		for (Object obj : model) {
			if (obj instanceof UserDB) {
				this.userDB = (UserDB) obj;
			}
		}
		for (Object obj : view) {
			if(obj instanceof LoginPanel) {
				this.loginPanel = (LoginPanel) obj;
			}else if (obj instanceof SignUpPanel) {
				this.signUpPanel = (SignUpPanel) obj;
			}else if (obj instanceof JFrame) {
				this.frame = frame;
			}
		}
	}
	//유저DB 최신화
	public void updateUserDB() {
		ArrayList<User> temp = new ArrayList<User>();
		temp = getUserDB().loadUserDB();
		getUserDB().setArrayList(temp);
	}
	//패널
	public void loginPanel() {	
		getLoginPanel().loginPage();
		login();
	}

	public void login() {	
		
		//호출되면 userDB로드해서 유저컨트롤러의 db를 최신화
		//최신화 이후 DB에서 불러온 모든 user login을 false처리
		updateUserDB();
		//모든 유저의 loginFlag값을 false로 변경
		for (User user : getUserDB().getArrayList()) {
			if(user != null) {
				if(user instanceof Guest) {
					user.setLogin(false);
				}
			}
		}
		//db에 저장도 최신
		getUserDB().saveUserDB(getUserDB().getArrayList());
		setUser(new User());
		//텍스트필드
		getLoginPanel().getLoginTxtID().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getLoginPanel().getLoginTxtID().setText("");				
			}
		});
		getLoginPanel().getLoginTxtPW().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getLoginPanel().getLoginTxtPW().setText("");				
			}
		});
		//로그인버튼	
		getLoginPanel().getLoginBtn().addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				//1.빈칸확인
				//2.로그인
				//3.관리자 비교
				for (User user : getUserDB().getArrayList()) {
					if(user != null) {
						if(user.getId().equals(getLoginPanel().getLoginTxtID().getText()) && user.getPassword().equals(getLoginPanel().getLoginTxtPW().getText())) {
							if(user instanceof Admin) {
								//관리자
								JOptionPane.showMessageDialog(null, "관리자님 환영합니다.");
								setUser(user);//유저컨트롤러의 멤버변수 user를 admin변환
								user.setLogin(true);
								getUserDB().saveUserDB(getUserDB().getArrayList());
								//화면전환
								getLoginPanel().setVisible(false);
								getLoginPanel().removeAll();
								getCinemaController().getAdminMainPanel().setVisible(true);
								getCinemaController().adminMainPanel();
								System.out.println(getUser().getName()+"님께서 접속하였습니다.");
								break;
								
							}else if (user instanceof Guest){
								//일반게스트
								JOptionPane.showMessageDialog(null,"환영합니다! " + user.getName() +"님");
								setUser(user);//유저컨트롤러의 멤버변수 user를 guest변환
								user.setLogin(true);
								getUserDB().saveUserDB(getUserDB().getArrayList());									
								//화면전환
								getLoginPanel().setVisible(false);
								getLoginPanel().removeAll();
								//메인창 이동
								getCinemaController().getMainPanel().setVisible(true); 
								getCinemaController().mainPanel();
								System.out.println(getUser().getName()+"님께서 접속하였습니다.");
								break;
							}							
						}
					}						
				}	
				if(getUser().isLogin() == false) {
					JOptionPane.showMessageDialog(null,"로그인에 실패했습니다. 다시 입력해주세요.");
					getLoginPanel().getLoginTxtID().setText("아이디 입력");
					getLoginPanel().getLoginTxtPW().setText("패스워드 입력");
					getLoginPanel().removeAll();
					loginPanel();
				}
			}
		});		
		//회원가입버튼
		getLoginPanel().getLoginSignUpBtn().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//이 이벤트가 동작하면 login패널에 있는 회원가입 버튼을 누른것이고 login패널이 꺼지고 singup패널이 켜진다
				getLoginPanel().setVisible(false);
				getSignUpPanel().setVisible(true);	
				getLoginPanel().removeAll();	
				signUpPanel();				
			}
		});
	}
	public void signUpPanel() {
		getSignUpPanel().SignUpPage();
		signUp();
	}
	public void signUp() {
		//회원가입창 DB최신화
		updateUserDB();
		
		//텍스트필드들 빈칸검사기
		getSignUpPanel().getSignUpTxtID().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getSignUpPanel().getSignUpTxtID().setText("");				
			}
		});		
		getSignUpPanel().getSignUpTxtPW().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getSignUpPanel().getSignUpTxtPW().setText("");				
			}
		});	
		getSignUpPanel().getSignUpTxtName().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getSignUpPanel().getSignUpTxtName().setText("");				
			}
		});	
		getSignUpPanel().getSignUpTxtAge().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getSignUpPanel().getSignUpTxtAge().setText("");				
			}
		});	
		getSignUpPanel().getSignUpTxtPhone().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				getSignUpPanel().getSignUpTxtPhone().setText("");				
			}
		});			
		//돌아가기		
		getSignUpPanel().getSignUpBackBtn().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				getSignUpPanel().setVisible(false);				
				//회원가입창 초기화
				getSignUpPanel().removeAll();
				//로그인 이동
				getLoginPanel().setVisible(true);
				loginPanel();
			}
		});
		//ID중복검사 - 빈칸		
		getSignUpPanel().getSignUpIDBtn().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//이미호출 될때 최신화가 되었다 getUserDB().getArrayList() = temp(디비에서 로드해온)
				System.out.println(getSignUpPanel().getSignUpTxtID().getText());
				if (getSignUpPanel().getSignUpTxtID().getText().equals("") || getSignUpPanel().getSignUpTxtID().getText().equals("아이디 입력")) {
					JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else {
					if(isDuplicateSignUp(getUserDB().getArrayList(), getSignUpPanel().getSignUpTxtID().getText())) {
						JOptionPane.showMessageDialog(null, "이미 사용중인 아이디 입니다.");
						getSignUpPanel().removeAll();
						signUpPanel();
					}else {
						JOptionPane.showMessageDialog(null, "사용 가능한 아이디 입니다.");		
						setFlag(true);
					}
				}			
			}
		});
		//회원가입 - 빈칸
		getSignUpPanel().getSignUpNextBtn().addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//이미호출 될때 최신화가 되었다 getUserDB().getArrayList() = temp(디비에서 로드해온)
				if(getSignUpPanel().getSignUpTxtID().getText().equals("") || getSignUpPanel().getSignUpTxtPW().getText().equals("")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else if (getSignUpPanel().getSignUpTxtAge().getText().equals("") || getSignUpPanel().getSignUpTxtName().getText().equals("")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else if (getSignUpPanel().getSignUpTxtPhone().getText().equals("")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");		
					getSignUpPanel().removeAll();
					signUpPanel();
				}else if (getSignUpPanel().getSignUpTxtAge().getText().equals("나이 입력") || getSignUpPanel().getSignUpTxtName().getText().equals("이름 입력")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else if (getSignUpPanel().getSignUpTxtPhone().getText().equals("핸드폰 번호 입력")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else if (getSignUpPanel().getSignUpTxtID().getText().equals("아이디 입력") || getSignUpPanel().getSignUpTxtPW().getText().equals("패스워드 입력")) {
					JOptionPane.showMessageDialog(null, "회원가입이 실패했습니다.");
					getSignUpPanel().removeAll();
					signUpPanel();
				}else {
					String id = getSignUpPanel().getSignUpTxtID().getText();
					String pw = getSignUpPanel().getSignUpTxtPW().getText();
					String name = getSignUpPanel().getSignUpTxtName().getText();
					String age = getSignUpPanel().getSignUpTxtAge().getText();
					String phone = getSignUpPanel().getSignUpTxtPhone().getText();
					String gender = getSignUpPanel().getSignUpTxtGender().getSelectedItem().toString();
					
					if(isFlag()) {
						Guest guest = new Guest(id, pw, name, age, gender, phone, true, true, true);
						//getUserDB().getArrayList()가 회원가입창 넘어올때 로드한 DB의 arrayList이다
						getUserDB().getArrayList().add(guest);
						//바로 메인창으로 이동하기 때문에 로그인작업
						//유저컨트롤러의 user에 guest를 세팅
						setUser(guest);
						getUser().setLogin(true);
						//고객을 생성해서 userDB에 Save	
						getUserDB().saveUserDB(getUserDB().getArrayList());
						JOptionPane.showMessageDialog(null, "회원 가입에 성공하였습니다.");	
						getSignUpPanel().setVisible(false);	
						//회원가입창 초기화
						getSignUpPanel().removeAll();	
						//유저메인으로 이동
						System.out.println(getUser().getName()+"님께서 회원가입에 성공하였습니다.");
						System.out.println(getUser().getName()+"님께서 접속하였습니다.");
						getCinemaController().getMainPanel().setVisible(true);
						getCinemaController().mainPanel();		
					}else {
						JOptionPane.showMessageDialog(null, "회원 가입에 실패하였습니다. 중복검사를 꼭 진행해 주세요");							
						getSignUpPanel().removeAll();
						signUpPanel();
					}
				}		
			}
		});
	}
	//중복검사 회원가입
	public boolean isDuplicateSignUp(ArrayList<User> temp, String id) {
		for (User user : temp) {
			if(user != null) {
				if(user instanceof Guest) {
					if(id.equals(user.getId())) {
						System.out.println(user);
						return true;
					}
				}
			}
		}		
		return false;
	}
	//증복검사 로그인
	public boolean isDuplicateLogin(ArrayList<User> temp, String id, String password) {
		for (User user : temp) {
			if(user != null) {
				if(user instanceof Guest) {
					if(id.equals(user.getId()) && password.equals(user.getPassword())) {
						System.out.println(user);
						return true;
					}
				}
			}
		}
		return false;
	}
	//gett sett
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	public UserDB getUserDB() {
		return userDB;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public void setUserDB(UserDB userDB) {
		this.userDB = userDB;
	}
	public ArrayList getModel() {
		return model;
	}
	public void setModel(ArrayList model) {
		this.model = model;
	}
	public ArrayList getView() {
		return view;
	}
	public void setView(ArrayList view) {
		this.view = view;
	}
	public CinemaController getCinemaController() {
		return cinemaController;
	}
	public void setCinemaController(CinemaController cinemaController) {
		this.cinemaController = cinemaController;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public LoginPanel getLoginPanel() {
		return loginPanel;
	}
	public void setLoginPanel(LoginPanel loginPanel) {
		this.loginPanel = loginPanel;
	}
	public SignUpPanel getSignUpPanel() {
		return signUpPanel;
	}
	public void setSignUpPanel(SignUpPanel signUpPanel) {
		this.signUpPanel = signUpPanel;
	}
	
	
}

package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SignUpPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;
	//txt
	private JTextField signUpTxtID;
	private JPasswordField signUpTxtPW;
	private JTextField signUpTxtName;
	private JTextField signUpTxtAge;
	private JTextField signUpTxtPhone;
	private	JComboBox signUpTxtGender;
	//btn
	private JButton signUpIDBtn;
	private JButton signUpBackBtn;
	private JButton signUpNextBtn;

	public SignUpPanel(JFrame frame) {
		this.frame = frame;
	}
	public void SignUpPage() {		
		
		setBounds(0, 0, 980, 640);		
		setLayout(null);
		
		setImagePanel(new ImagePanel(new ImageIcon("./images/signUpPage/signUpBackPn.jpg").getImage()));		
		getImagePanel().setBounds(0, 0, 980, 640);				
		add(getImagePanel());				
		getImagePanel().setLayout(null);
		
		setSignUpTxtID(new JTextField());
		getSignUpTxtID().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getSignUpTxtID().setForeground(Color.DARK_GRAY);
		getSignUpTxtID().setText("아이디 입력");
		getSignUpTxtID().setBounds(613, 151, 236, 31);
		getImagePanel().add(getSignUpTxtID());
		getSignUpTxtID().setColumns(10);

		setSignUpIDBtn(new JButton());
		getSignUpIDBtn().setIcon(new ImageIcon("./images/signUpPage/signUpIDBtn.jpg"));
		getSignUpIDBtn().setBounds(862, 151, 70, 31);
		getImagePanel().add(getSignUpIDBtn());
		
		setSignUpTxtName(new JTextField());
		getSignUpTxtName().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getSignUpTxtName().setForeground(Color.DARK_GRAY);
		getSignUpTxtName().setText("이름 입력");
		getSignUpTxtName().setColumns(10);
		getSignUpTxtName().setBounds(613, 276, 236, 31);
		getImagePanel().add(getSignUpTxtName());
		
		setSignUpTxtPW(new JPasswordField());
		getSignUpTxtPW().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getSignUpTxtPW().setForeground(Color.DARK_GRAY);
		getSignUpTxtPW().setText("패스워드 입력");
		getSignUpTxtPW().setBounds(613, 214, 236, 31);
		getImagePanel().add(getSignUpTxtPW());
		
		setSignUpTxtAge(new JTextField());
		getSignUpTxtAge().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getSignUpTxtAge().setForeground(Color.DARK_GRAY);
		getSignUpTxtAge().setText("나이 입력");
		getSignUpTxtAge().setColumns(10);
		getSignUpTxtAge().setBounds(613, 339, 236, 31);
		getImagePanel().add(getSignUpTxtAge());

		setSignUpTxtGender(new JComboBox());
		getSignUpTxtGender().setModel(new DefaultComboBoxModel(new String[] {"남성", "여성"}));
		getSignUpTxtGender().setFont(new Font("맑은 고딕", Font.PLAIN, 21));
		getSignUpTxtGender().setBounds(613, 402, 236, 31);
		getImagePanel().add(getSignUpTxtGender());
		
		setSignUpTxtPhone( new JTextField());
		getSignUpTxtPhone().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getSignUpTxtPhone().setForeground(Color.DARK_GRAY);
		getSignUpTxtPhone().setText("핸드폰 번호 입력");
		getSignUpTxtPhone().setColumns(10);
		getSignUpTxtPhone().setBounds(613, 464, 236, 31);
		getImagePanel().add(getSignUpTxtPhone());
		
		setSignUpBackBtn(new JButton());
		getSignUpBackBtn().setIcon(new ImageIcon("./images/signUpPage/signUpBackBtn.jpg"));
		getSignUpBackBtn().setBounds(610, 523, 90, 40);
		getImagePanel().add(getSignUpBackBtn());
		
		setSignUpNextBtn(new JButton());
		getSignUpNextBtn().setIcon(new ImageIcon("./images/signUpPage/signUpSignUpBtn.jpg"));
		getSignUpNextBtn().setBounds(759, 523, 90, 40);
		getImagePanel().add(getSignUpNextBtn());
		
		//프레임에 add
		getFrame().getContentPane().add(this);
	}
	//Getter/setter
	
	public ImagePanel getImagePanel() {
		return imagePanel;
	}
	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}
	public JTextField getSignUpTxtID() {
		return signUpTxtID;
	}
	public void setSignUpTxtID(JTextField signUpTxtID) {
		this.signUpTxtID = signUpTxtID;
	}
	public JPasswordField getSignUpTxtPW() {
		return signUpTxtPW;
	}
	public void setSignUpTxtPW(JPasswordField signUpTxtPW) {
		this.signUpTxtPW = signUpTxtPW;
	}
	public JTextField getSignUpTxtName() {
		return signUpTxtName;
	}
	public void setSignUpTxtName(JTextField signUpTxtName) {
		this.signUpTxtName = signUpTxtName;
	}
	public JTextField getSignUpTxtAge() {
		return signUpTxtAge;
	}
	public void setSignUpTxtAge(JTextField signUpTxtAge) {
		this.signUpTxtAge = signUpTxtAge;
	}
	public JTextField getSignUpTxtPhone() {
		return signUpTxtPhone;
	}
	public void setSignUpTxtPhone(JTextField signUpTxtPhone) {
		this.signUpTxtPhone = signUpTxtPhone;
	}
	public JComboBox getSignUpTxtGender() {
		return signUpTxtGender;
	}
	public void setSignUpTxtGender(JComboBox signUpTxtGender) {
		this.signUpTxtGender = signUpTxtGender;
	}
	//getSignUpIDBtn() getSignUpBackBtn() getSignUpNextBtn()
	public JButton getSignUpIDBtn() {
		return signUpIDBtn;
	}
	public void setSignUpIDBtn(JButton signUpIDBtn) {
		this.signUpIDBtn = signUpIDBtn;
	}
	public JButton getSignUpBackBtn() {
		return signUpBackBtn;
	}
	public void setSignUpBackBtn(JButton signUpBackBtn) {
		this.signUpBackBtn = signUpBackBtn;
	}
	public JButton getSignUpNextBtn() {
		return signUpNextBtn;
	}
	public void setSignUpNextBtn(JButton signUpNextBtn) {
		this.signUpNextBtn = signUpNextBtn;
	}
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	
}

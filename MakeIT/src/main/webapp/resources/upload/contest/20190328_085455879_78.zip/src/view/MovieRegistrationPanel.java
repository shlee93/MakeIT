package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MovieRegistrationPanel extends JPanel{
   private JFrame frame;
   private ImagePanel imagePanel;
   // txt
   private JTextField movieRegTxtName;
   private JComboBox movieRegTxtGenre;
   private JComboBox movieRegTxtGrade;
   private JTextField movieRegTxtPro;
   private JTextField movieRegTxtDir;
   // 여긴 area로 작업해야할듯
   private JTextArea movieRegTxtLeadAc;
   private JTextArea movieRegTxtSupAc;
   // 버튼
   private JButton movieRegBackBtn;
   private JButton movieRegRegBtn;
   // 스크롤
   private JScrollPane movieRegScroll;
   
   public MovieRegistrationPanel(JFrame frame) {
      this.frame = frame;
   }
   
   public void movieRegistrationPage() {
      setBounds(0, 0, 980, 640);      
      setLayout(null);
      
      setImagePanel(new ImagePanel(new ImageIcon("./images/movieRegPage/movieRegBackPn.jpg").getImage()));      
      getImagePanel().setBounds(0, 0, 980, 640);            
      add(getImagePanel());            
      getImagePanel().setLayout(null);      
      
      setMovieRegTxtName(new JTextField());
      getMovieRegTxtName().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
      getMovieRegTxtName().setForeground(Color.DARK_GRAY);
      getMovieRegTxtName().setText("작품명 입력");
      getMovieRegTxtName().setBounds(178, 96, 191, 31);
      getImagePanel().add(getMovieRegTxtName());
      getMovieRegTxtName().setColumns(10);
      
      setMovieRegTxtGenre(new JComboBox());
      getMovieRegTxtGenre().setModel(new DefaultComboBoxModel(new String[] {"액션","SF 판타지","범죄","코미디","스릴러","전쟁","스포츠","로맨스&멜로","미스터리","모험","다큐멘터리","드라마"}));
      getMovieRegTxtGenre().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
      getMovieRegTxtGenre().setForeground(Color.DARK_GRAY);
      getMovieRegTxtGenre().setBounds(178, 147, 191, 31);
      getImagePanel().add(getMovieRegTxtGenre());
      
      setMovieRegTxtGrade(new JComboBox());
      getMovieRegTxtGrade().setModel(new DefaultComboBoxModel(new String[] {"전체 이용가","12세","15세","19세"}));
      getMovieRegTxtGrade().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
      getMovieRegTxtGrade().setForeground(Color.DARK_GRAY);
      getMovieRegTxtGrade().setBounds(178, 198, 191, 31);
      getImagePanel().add(getMovieRegTxtGrade());
      
      setMovieRegTxtPro(new JTextField());
      getMovieRegTxtPro().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
      getMovieRegTxtPro().setForeground(Color.DARK_GRAY);
      getMovieRegTxtPro().setText("제작사 입력");
      getMovieRegTxtPro().setColumns(10);
      getMovieRegTxtPro().setBounds(178, 251, 191, 31);
      getImagePanel().add(getMovieRegTxtPro());
      
      setMovieRegTxtDir(new JTextField());
      getMovieRegTxtDir().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
      getMovieRegTxtDir().setForeground(Color.DARK_GRAY);
      getMovieRegTxtDir().setText("감독 입력");
      getMovieRegTxtDir().setColumns(10);
      getMovieRegTxtDir().setBounds(178, 302, 191, 31);
      getImagePanel().add(getMovieRegTxtDir());
      
      setMovieRegTxtLeadAc(new JTextArea());
      getMovieRegTxtLeadAc().setFont(new Font("맑은 고딕", Font.PLAIN, 15));
      setMovieRegScroll(new JScrollPane(getMovieRegTxtLeadAc(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
      getMovieRegScroll().setBounds(178, 354, 191, 79);
      getImagePanel().add(getMovieRegScroll());
      
      setMovieRegTxtSupAc(new JTextArea());
      getMovieRegTxtSupAc().setFont(new Font("맑은 고딕", Font.PLAIN, 15));
      setMovieRegScroll(new JScrollPane(getMovieRegTxtSupAc(), JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
      getMovieRegScroll().setBounds(178, 449, 191, 79);
      getImagePanel().add(getMovieRegScroll());
      
      setMovieRegBackBtn(new JButton(""));
      getMovieRegBackBtn().setIcon(new ImageIcon("./images/movieRegPage/movieRegBackBtn.jpg"));
      getMovieRegBackBtn().setBounds(178, 548, 91, 39);
      getImagePanel().add(getMovieRegBackBtn());
      
      setMovieRegRegBtn(new JButton(""));
      getMovieRegRegBtn().setIcon(new ImageIcon("./images/movieRegPage/movieRegRegBtn.jpg"));
      getMovieRegRegBtn().setBounds(278, 548, 91, 39);
      getImagePanel().add(getMovieRegRegBtn());
      
      
      getFrame().getContentPane().add(this);
   }

   public JTextField getMovieRegTxtName() {
      return movieRegTxtName;
   }
   public void setMovieRegTxtName(JTextField movieRegTxtName) {
      this.movieRegTxtName = movieRegTxtName;
   }

   public JComboBox getMovieRegTxtGenre() {
      return movieRegTxtGenre;
   }
   public void setMovieRegTxtGenre(JComboBox movieRegTxtGenre) {
      this.movieRegTxtGenre = movieRegTxtGenre;
   }
   public JComboBox getMovieRegTxtGrade() {
      return movieRegTxtGrade;
   }
   public void setMovieRegTxtGrade(JComboBox movieRegTxtGrade) {
      this.movieRegTxtGrade = movieRegTxtGrade;
   }
   public JTextField getMovieRegTxtPro() {
      return movieRegTxtPro;
   }
   public void setMovieRegTxtPro(JTextField movieRegTxtPro) {
      this.movieRegTxtPro = movieRegTxtPro;
   }
   public JTextField getMovieRegTxtDir() {
      return movieRegTxtDir;
   }
   public void setMovieRegTxtDir(JTextField movieRegTxtDir) {
      this.movieRegTxtDir = movieRegTxtDir;
   }
   public JTextArea getMovieRegTxtLeadAc() {
      return movieRegTxtLeadAc;
   }
   public void setMovieRegTxtLeadAc(JTextArea movieRegTxtLeadAc) {
      this.movieRegTxtLeadAc = movieRegTxtLeadAc;
   }
   public JTextArea getMovieRegTxtSupAc() {
      return movieRegTxtSupAc;
   }
   public void setMovieRegTxtSupAc(JTextArea movieRegTxtSupAc) {
      this.movieRegTxtSupAc = movieRegTxtSupAc;
   }

   public JButton getMovieRegBackBtn() {
      return movieRegBackBtn;
   }
   public void setMovieRegBackBtn(JButton movieRegBackBtn) {
      this.movieRegBackBtn = movieRegBackBtn;
   }
   public JButton getMovieRegRegBtn() {
      return movieRegRegBtn;
   }
   public void setMovieRegRegBtn(JButton movieRegRegBtn) {
      this.movieRegRegBtn = movieRegRegBtn;
   }
   public JFrame getFrame() {
      return frame;
   }
   public void setFrame(JFrame frame) {
      this.frame = frame;
   }
   public ImagePanel getImagePanel() {
      return imagePanel;
   }
   public void setImagePanel(ImagePanel imagePanel) {
      this.imagePanel = imagePanel;
   }
   public JScrollPane getMovieRegScroll() {
      return movieRegScroll;
   }
   public void setMovieRegScroll(JScrollPane movieRegScroll) {
      this.movieRegScroll = movieRegScroll;
   }   
}
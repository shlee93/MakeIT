package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class ImagePanel extends JPanel{
	private Image img;
	public ImagePanel(Image img) {
		this.img = img;
		setSize(new Dimension(img.getWidth(null),img.getHeight(null))); //패널의 사이즈가 이미지에 맞게 자동으로 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null))); //패널의 사이즈가 이미지에 맞게 자동으로 조절됨 크기에 맞게 제대로
		setLayout(null); //앱솔루트 레이아웃임			
		
	}
	
	public Image getImg() {
		return img;
	}

	public void setImg(Image img) {
		this.img = img;
		setSize(new Dimension(img.getWidth(null),img.getHeight(null))); //패널의 사이즈가 이미지에 맞게 자동으로 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null))); //패널의 사이즈가 이미지에 맞게 자동으로 조절됨 크기에 맞게 제대로
		setLayout(null); //앱솔루트 레이아웃임	
	}

	public int getWidth() {
		return img.getWidth(null);
	}
	public int getHeight() {
		return img.getHeight(null);
	}
	public void paintComponent(Graphics g) {
		g.drawImage(img,0,0,null); //img,x시작,y시작
	}	
}

public class LoginPanel extends JPanel{
	private JFrame frame;
	private ImagePanel imagePanel;
	private JTextField loginTxtID;
	private JPasswordField loginTxtPW;
	private JButton loginBtn;
	private JButton loginSignUpBtn;	

	public LoginPanel(JFrame frame) {
		this.frame = frame;
	}
	public void loginPage() {
		//패널 고정

		setBounds(0, 0, 980, 640);		
		setLayout(null);
		//패널에 달려있는 애들
		//이미지패널
		setImagePanel(new ImagePanel(new ImageIcon("./images/loginPage/loginBackPn.jpg").getImage()));		
		getImagePanel().setBounds(0, 0, 980, 640);				
		add(getImagePanel());				
		getImagePanel().setLayout(null);

		setLoginTxtID(new JTextField());
		getLoginTxtID().setBounds(79, 295, 370, 33);
		getLoginTxtID().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getLoginTxtID().setForeground(Color.DARK_GRAY);
		getLoginTxtID().setText("아이디 입력");
		getImagePanel().add(getLoginTxtID());
		getLoginTxtID().setColumns(10);
		
		setLoginTxtPW(new JPasswordField());
		getLoginTxtPW().setFont(new Font("맑은 고딕", Font.PLAIN, 22));
		getLoginTxtPW().setForeground(Color.DARK_GRAY);
		getLoginTxtPW().setText("패스워드 입력");
		getLoginTxtPW().setColumns(10);
		getLoginTxtPW().setBounds(79, 341, 370, 33);
		getImagePanel().add(getLoginTxtPW());

		setLoginSignUpBtn(new JButton());
		getLoginSignUpBtn().setIcon(new ImageIcon("./images/loginPage/loginSignUpBtn.jpg"));
		getLoginSignUpBtn().setBounds(231, 382, 65,30);
		getImagePanel().add(getLoginSignUpBtn());
		
		setLoginBtn(new JButton());
		getLoginBtn().setIcon(new ImageIcon("./images/loginPage/loginLoginBtn.jpg"));
		getLoginBtn().setBounds(339, 497,110,50);
		getImagePanel().add(getLoginBtn());		
		
		//frame에 loginPanel을 add
		getFrame().getContentPane().add(this);
	}
	
	//gett/sett
	public ImagePanel getImagePanel() {
		return imagePanel;
	}
	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	public JTextField getLoginTxtID() {
		return loginTxtID;
	}
	public void setLoginTxtID(JTextField loginTxtID) {
		this.loginTxtID = loginTxtID;
	}
	public JPasswordField getLoginTxtPW() {
		return loginTxtPW;
	}
	public void setLoginTxtPW(JPasswordField loginTxtPW) {
		this.loginTxtPW = loginTxtPW;
	}
	public JButton getLoginBtn() {
		return loginBtn;
	}
	public void setLoginBtn(JButton loginBtn) {
		this.loginBtn = loginBtn;
	}
	public JButton getLoginSignUpBtn() {
		return loginSignUpBtn;
	}
	public void setLoginSignUpBtn(JButton loginSignUpBtn) {
		this.loginSignUpBtn = loginSignUpBtn;
	}
	
	
}

package model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class UserDB {
	private ArrayList<User> arrayList;
	private String dbName;
	
	public UserDB() {		
	}	
	public UserDB(ArrayList<User> arrayList, String dbName) {
		this.arrayList = arrayList;
		this.dbName = dbName;
		//saveUserDB(arrayList);
	}
	public void createUserDB() {
		try {
			File f = new File(getDbName());
			f.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	//Guest ArrayList를 받아서 DB에 저장
	public void saveUserDB(ArrayList<User> arrayList) {	
		setArrayList(arrayList);
		OutputStream out = null;
		BufferedOutputStream bout = null;
		ObjectOutputStream oout = null;
		try {
			out = new FileOutputStream(getDbName());
			bout = new BufferedOutputStream(out);
			oout = new ObjectOutputStream(bout);			
			oout.writeObject(getArrayList());				
		}catch(Exception e) {
			e.printStackTrace();			
		}finally {
			try {
				oout.close();
			}catch(IOException e) {
				e.printStackTrace();
			}
		}	
	}
	public ArrayList<User> loadUserDB() {		
		createUserDB();
		InputStream in = null;
		BufferedInputStream bin = null;
		ObjectInputStream oin = null;		
		try {
			in = new FileInputStream(getDbName());
			bin = new BufferedInputStream(in);
			oin = new ObjectInputStream(bin);
			ArrayList<User> list = (ArrayList<User>) oin.readObject();	

			setArrayList(list);
			
		}catch(Exception e) {			
			System.out.println("UserDB에 회원이 없습니다.");
			setArrayList(new ArrayList<User>());
			
		}finally {
			try {
				oin.close();
			}catch(NullPointerException e) {			
			}catch(IOException e) {				
				e.printStackTrace();
			}
		}
		return getArrayList();
	}
	//getter setter
	public ArrayList<User> getArrayList() {
		return arrayList;
	}
	public void setArrayList(ArrayList<User> arrayList) {
		this.arrayList = arrayList;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	
	
}

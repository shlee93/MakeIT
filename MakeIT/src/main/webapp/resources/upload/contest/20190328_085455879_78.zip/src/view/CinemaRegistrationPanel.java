package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Calendar;
import java.util.HashMap;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class CinemaRegistrationPanel extends JPanel {
	private JFrame frame;
	private ImagePanel imagePanel;
	private JComboBox cinemaRegTxtCinema;
	private JComboBox cinemaRegTxtCity;
	private JComboBox cinemaRegTxtBorough;
	private JComboBox cinemaRegTxtArea;
	private JComboBox cinemaRegTxtCinemaCount;
	private JComboBox cinemaRegTxtTime;
	private JComboBox cinemaRegTxtTicketPrice;
	//캘린더
	private JTable dayViewTable;
	private JLabel label;	
	private JPanel cinemaRegDate;//캘린더들가는패널
	private JButton prevbtn;
	private JButton nextbtn;
	private JTable table;
	private boolean focus = false;
	Calendar calendar = Calendar.getInstance();
	DefaultTableModel weekTable = new DefaultTableModel(0, 7);
	DefaultTableModel dayTable = new DefaultTableModel(6, 7);
	int todayD;
	
	// HashMap
	// city는 서울/ 경기/ 인천
	private HashMap<String, String[]> borough; // 지역 강남구, 수원, 용인
	private HashMap<String, String[]> area; // 동 강남, 압구정, 서현,판교
	// 임시 시간열람그림자리임
	private JPanel cinemaDatePn;
	private JButton cinemaRegBackBtn;
	private JButton cinemaRegRegBtn;
	private JButton cinemaRegAddBtn;
	private JButton[] cinemaRegTimeBtnList;
	private JButton[] cinemaRegCinemaBtnList;
	private JButton cinemaRegInsertBtn;
	private JButton cinemaRegStartBtn;
	private JButton cinemaRegEndBtn;
	private JLabel cinemaRegStartLabel;
	private JLabel cinemaRegEndLabel;
	private String date;
	
	public CinemaRegistrationPanel(JFrame frame) {
		this.frame = frame;

	}

	public void CinemaRegistrationPage() {

		// City를 기준으로 동이 변경됨
		setBorough(new HashMap<String, String[]>());
		setArea(new HashMap<String, String[]>());
		String[] borough_0 = { "강남구", "강동/송파구", "영등포구" };
		String[] borough_1 = { "성남", "수원", "인천" };
		String[] borough_2 = { "부산", "울산", "창원" };
		String[] borough_3 = { "대구", "안동", "포항" };
		String[] borough_4 = { "대전", "천안", "강릉" };
		String[] borough_5 = { "광주", "여수", "제주" };
		// 서울
		String[] area_00 = { "강남점", "압구정점" };
		String[] area_01 = { "송파점", "천호점" };
		String[] area_02 = { "여의도점", "영등포점" };
		// 경기
		String[] area_10 = { "판교점", "서현점" };
		String[] area_11 = { "수원점", "동수원점" };
		String[] area_12 = { "인천점", "인천공항점" };
		// 부산
		String[] area_20 = { "서면점", "남포점" };
		String[] area_21 = { "울산삼산점" };
		String[] area_22 = { "마산점", "창원점" };
		// 대구
		String[] area_30 = { "대구점", "대구월성점" };
		String[] area_31 = { "안동점" };
		String[] area_32 = { "포항점", "북포항점" };
		// 대전
		String[] area_40 = { "대전점", "대전터미널점" };
		String[] area_41 = { "천안점", "천안펜타포트점" };
		String[] area_42 = { "강릉점" };
		// 광주
		String[] area_50 = { "광주상무점", "광주터미널점" };
		String[] area_51 = { "여수웅천점" };
		String[] area_52 = { "제주점", "제주노형점" };
		// City를 키로 지역을 붙임
		getBorough().put("서울", borough_0);
		getBorough().put("경기/인천", borough_1);
		getBorough().put("부산/울산/경남", borough_2);
		getBorough().put("대구/경북", borough_3);
		getBorough().put("대전/충청/강원", borough_4);
		getBorough().put("광주/전라/제주", borough_5);
		// borough를 키로 동을 붙임
		// 서울
		getArea().put("강남구", area_00);
		getArea().put("강동/송파구", area_01);
		getArea().put("영등포구", area_02);
		// 경기
		getArea().put("성남", area_10);
		getArea().put("수원", area_11);
		getArea().put("인천", area_12);
		// 부산
		getArea().put("부산", area_20);
		getArea().put("울산", area_21);
		getArea().put("창원", area_22);
		// 대구
		getArea().put("대구", area_30);
		getArea().put("안동", area_31);
		getArea().put("포항", area_32);
		// 대전
		getArea().put("대전", area_40);
		getArea().put("천안", area_41);
		getArea().put("강릉", area_42);
		// 광주
		getArea().put("광주", area_50);
		getArea().put("여수", area_51);
		getArea().put("제주", area_52);

		setBounds(0, 0, 980, 640);
		setLayout(null);

		setImagePanel(new ImagePanel(new ImageIcon("./images/cinemaRegPage/cinemaRegBackPn.jpg").getImage()));
		getImagePanel().setBounds(0, 0, 980, 640);
		add(getImagePanel());
		getImagePanel().setLayout(null);

		setCinemaRegStartBtn(new JButton());
		getCinemaRegStartBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegDateStartBtn.jpg"));
		getCinemaRegStartBtn().setBounds(408, 375, 79, 29);
		getImagePanel().add(getCinemaRegStartBtn());
		
		setCinemaRegEndBtn(new JButton());
		getCinemaRegEndBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegDateEndBtn.jpg"));
		getCinemaRegEndBtn().setBounds(408, 428, 79, 29);
		getImagePanel().add(getCinemaRegEndBtn());
		
		setCinemaRegStartLabel(new JLabel());
		getCinemaRegStartLabel().setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		getCinemaRegStartLabel().setBounds(415, 404, 69, 19);
		getImagePanel().add(getCinemaRegStartLabel());

		setCinemaRegEndLabel(new JLabel());
		getCinemaRegEndLabel().setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		getCinemaRegEndLabel().setBounds(415, 457, 69, 19);
		getImagePanel().add(getCinemaRegEndLabel());
		
		setCinemaRegTxtCinema(new JComboBox());
		getCinemaRegTxtCinema().setForeground(Color.DARK_GRAY);
		getCinemaRegTxtCinema().setModel(new DefaultComboBoxModel(new String[] { "CGV", "메가박스", "롯데시네마" }));
		getCinemaRegTxtCinema().setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getCinemaRegTxtCinema().setBounds(158, 113, 270, 30);
		getImagePanel().add(getCinemaRegTxtCinema());

		setCinemaRegTxtCity(new JComboBox());
		getCinemaRegTxtCity().setForeground(Color.DARK_GRAY);
		getCinemaRegTxtCity().setModel(new DefaultComboBoxModel(new String[] { "서울", "경기/인천", "부산/울산/경남", "대구/경북", "대전/충청/강원", "광주/전라/제주" }));
		getCinemaRegTxtCity().setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		getCinemaRegTxtCity().setBounds(158, 157, 91, 30);
		getImagePanel().add(getCinemaRegTxtCity());

		setCinemaRegTxtBorough(new JComboBox());
		getCinemaRegTxtBorough().setForeground(Color.DARK_GRAY);
		getCinemaRegTxtBorough().setModel(new DefaultComboBoxModel(new String[] { "도시 선택" }));
		getCinemaRegTxtBorough().setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		getCinemaRegTxtBorough().setBounds(255, 157, 82, 30);
		getImagePanel().add(getCinemaRegTxtBorough());

		setCinemaRegTxtArea(new JComboBox());
		getCinemaRegTxtArea().setForeground(Color.DARK_GRAY);
		getCinemaRegTxtArea().setModel(new DefaultComboBoxModel(new String[] { "지역 선택" }));
		getCinemaRegTxtArea().setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		getCinemaRegTxtArea().setBounds(343, 158, 85, 30);
		getImagePanel().add(getCinemaRegTxtArea());

		setCinemaRegTxtTicketPrice(new JComboBox());
		getCinemaRegTxtTicketPrice().setForeground(Color.DARK_GRAY);
		getCinemaRegTxtTicketPrice().setModel(new DefaultComboBoxModel(new String[] { "6000원", "7000원", "8000원", "9000원", "10000원" }));
		getCinemaRegTxtTicketPrice().setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getCinemaRegTxtTicketPrice().setBounds(158, 287, 270, 30);
		getImagePanel().add(getCinemaRegTxtTicketPrice());

		setCinemaRegAddBtn(new JButton());
		getCinemaRegAddBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegAddBtn.jpg"));
		getCinemaRegAddBtn().setBounds(408, 494, 82, 44);
		getImagePanel().add(getCinemaRegAddBtn());

		setCinemaRegBackBtn(new JButton());
		getImagePanel().add(getCinemaRegBackBtn());
		getCinemaRegBackBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegBackBtn.jpg"));
		getCinemaRegBackBtn().setBounds(60, 548, 82,44);

		setCinemaRegRegBtn(new JButton());
		getImagePanel().add(getCinemaRegRegBtn());
		getCinemaRegRegBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegRegBtn.jpg"));
		getCinemaRegRegBtn().setBounds(410, 548, 82, 44);

		// 시간
		setCinemaRegTimeBtnList(new JButton[4]);

		getCinemaRegTimeBtnList()[0] = new JButton("09:20");
		getCinemaRegTimeBtnList()[0].setBackground(Color.WHITE);
		getCinemaRegTimeBtnList()[0].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegTimeBtnList()[0].setBounds(157, 247, 71, 23);
		getImagePanel().add(getCinemaRegTimeBtnList()[0]);

		getCinemaRegTimeBtnList()[1] = new JButton("12:30");
		getCinemaRegTimeBtnList()[1].setBackground(Color.WHITE);
		getCinemaRegTimeBtnList()[1].setFont(new Font("돋움", Font.PLAIN, 12));
		getCinemaRegTimeBtnList()[1].setBounds(229, 247, 71, 23);
		getImagePanel().add(getCinemaRegTimeBtnList()[1]);

		getCinemaRegTimeBtnList()[2] = new JButton("16:40");
		getCinemaRegTimeBtnList()[2].setBackground(Color.WHITE);
		getCinemaRegTimeBtnList()[2].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegTimeBtnList()[2].setBounds(301, 247, 71, 23);
		getImagePanel().add(getCinemaRegTimeBtnList()[2]);

		getCinemaRegTimeBtnList()[3] = new JButton("21:10");
		getCinemaRegTimeBtnList()[3].setBackground(Color.WHITE);
		getCinemaRegTimeBtnList()[3].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegTimeBtnList()[3].setBounds(373, 247, 71, 23);
		getImagePanel().add(getCinemaRegTimeBtnList()[3]);

		// 상영관
		setCinemaRegCinemaBtnList(new JButton[4]);
		getCinemaRegCinemaBtnList()[0] = new JButton("A관");
		getCinemaRegCinemaBtnList()[0].setBackground(Color.WHITE);
		getCinemaRegCinemaBtnList()[0].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegCinemaBtnList()[0].setBounds(157, 202, 71, 23);
		getImagePanel().add(getCinemaRegCinemaBtnList()[0]);

		getCinemaRegCinemaBtnList()[1] = new JButton("B관");
		getCinemaRegCinemaBtnList()[1].setBackground(Color.WHITE);
		getCinemaRegCinemaBtnList()[1].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegCinemaBtnList()[1].setBounds(229, 202, 71, 23);
		getImagePanel().add(getCinemaRegCinemaBtnList()[1]);

		getCinemaRegCinemaBtnList()[2] = new JButton("C관");
		getCinemaRegCinemaBtnList()[2].setBackground(Color.WHITE);
		getCinemaRegCinemaBtnList()[2].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegCinemaBtnList()[2].setBounds(301, 202, 71, 23);
		getImagePanel().add(getCinemaRegCinemaBtnList()[2]);

		getCinemaRegCinemaBtnList()[3] = new JButton("D관");
		getCinemaRegCinemaBtnList()[3].setBackground(Color.WHITE);
		getCinemaRegCinemaBtnList()[3].setFont(new Font("돋움", Font.PLAIN, 13));
		getCinemaRegCinemaBtnList()[3].setBounds(373, 202, 71, 23);
		getImagePanel().add(getCinemaRegCinemaBtnList()[3]);

		// 시간저장
		setCinemaRegInsertBtn(new JButton());
		getCinemaRegInsertBtn().setIcon(new ImageIcon("./images/cinemaRegPage/cinemaRegTimeBtn.jpg"));
		getCinemaRegInsertBtn().setBounds(451, 247, 58, 23);
		getImagePanel().add(getCinemaRegInsertBtn());

		// 캘린더
		Calendar calendar = Calendar.getInstance();
		// 요일 표시
		String[] weekColumns = { "일", "월", "화", "수", "목", "금", "토" };
		weekTable.addRow(weekColumns);
		// 가운데 정렬
		DefaultTableCellRenderer center = new DefaultTableCellRenderer();
		center.setHorizontalAlignment(JLabel.CENTER);
		DefaultTableCellRenderer top = new DefaultTableCellRenderer();
		top.setVerticalAlignment(SwingConstants.TOP);
		
		setCinemaRegDate(new JPanel());
		getCinemaRegDate().setBounds(158, 330, 230, 270);
		getCinemaRegDate().setBorder(new EmptyBorder(5, 5, 5, 5));
		getCinemaRegDate().setBackground(Color.WHITE);
		getCinemaRegDate().setLayout(null);
		//이미지패널에 date넣는다
		getImagePanel().add(getCinemaRegDate());
		// 이전버튼
		setPrevbtn(new JButton("<"));
		//이전버튼 이벤트처리 이동해야함
		getPrevbtn().setBounds(6, 0, 46, 46);
		getPrevbtn().setOpaque(false);
		getPrevbtn().setFont(new Font("굴림", Font.PLAIN, 16));
		getPrevbtn().setFocusable(false);
		getPrevbtn().setContentAreaFilled(false);
		getPrevbtn().setBorderPainted(false);

		// 버튼 투명하게
		getPrevbtn().setOpaque(false);
		getPrevbtn().setContentAreaFilled(false);
		getPrevbtn().setBorderPainted(false);
		getPrevbtn().setFocusable(false);
		getCinemaRegDate().add(getPrevbtn());
		// YYMM라벨
		label = new JLabel("");
		label.setBounds(35, 6, 150, 27);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		getCinemaRegDate().add(label);

		// next버튼
		setNextbtn(new JButton(">"));
		getNextbtn().setBorderPainted(false);
		getNextbtn().setFont(new Font("굴림", Font.PLAIN, 16));
		getNextbtn().setBounds(175, 0, 46, 46);
		getNextbtn().setOpaque(false);
		getNextbtn().setContentAreaFilled(false);
		getNextbtn().setBorderPainted(false);
		getNextbtn().setFocusable(false);
		getCinemaRegDate().add(getNextbtn());

		// 주 테이블(월-일)
		setTable(new JTable(weekTable) {
			private static final long serialVersionUID = 1L;
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		});
		getTable().setBounds(8, 43, 213, 23);
		getTable().setRowSelectionAllowed(false);
		getTable().setRowHeight(25);
		getTable().setFont(new Font("맑은 고딕", Font.BOLD, 12));
		getTable().setFillsViewportHeight(true);
		getTable().setEnabled(false);
		getTable().setBorder(new LineBorder(new Color(0, 0, 0)));
		getTable().setBackground(Color.LIGHT_GRAY);
		getTable().getColumnModel().getColumn(1).setCellRenderer(center);
		getTable().getColumnModel().getColumn(2).setCellRenderer(center);
		getTable().getColumnModel().getColumn(3).setCellRenderer(center);
		getTable().getColumnModel().getColumn(4).setCellRenderer(center);
		getTable().getColumnModel().getColumn(5).setCellRenderer(center);
		getTable().getColumnModel().getColumn(0).setCellRenderer(center);
		getTable().getColumnModel().getColumn(6).setCellRenderer(center);
		getCinemaRegDate().add(getTable());

		// 1-31테이블
		setDayViewTable(new JTable(dayTable) {
			private static final long serialVersionUID = 1L;
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		});
		getDayViewTable().setBackground(Color.WHITE);
		getDayViewTable().setCellSelectionEnabled(true);
		getDayViewTable().setColumnSelectionAllowed(true);
		getDayViewTable().setRowHeight(34);
		getDayViewTable().setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		getDayViewTable().setFillsViewportHeight(true);
		getDayViewTable().setColumnSelectionAllowed(true);
		getDayViewTable().setCellSelectionEnabled(true);
		getDayViewTable().setBorder(new LineBorder(new Color(0, 0, 0)));
		getDayViewTable().setBounds(8, 65, 213, 212);
		getDayViewTable().getColumnModel().getColumn(0).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(1).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(2).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(3).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(4).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(5).setCellRenderer(center);
		getDayViewTable().getColumnModel().getColumn(6).setCellRenderer(center);
		getCinemaRegDate().add(getDayViewTable());
		
		setTodayD(calendar.get(Calendar.DATE));
		refresh();
		//todayFocus();
		getFrame().getContentPane().add(this);
	}
	// 캘린더 받아오기
	public void refresh() {

		getLabel().setText((calendar.get(Calendar.YEAR) + ".") + (calendar.get(Calendar.MONTH) + 1));
		setDate(getLabel().getText());
		calendar.set(Calendar.DAY_OF_MONTH, 1);		
		int dayWeek = calendar.get(Calendar.DAY_OF_WEEK);
		int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				getDayViewTable().setValueAt("", i, j);
			}
		}
		for (int day = 1, row = 0, col = dayWeek - 1; day < endDay + 1; day++, col++) {
			if (col % 7 == 0) {
				col = 0;
				row += 1;
			}
			getDayViewTable().setValueAt(" " + day, row, col);
		}
	}
/*
	// 오늘날짜에 focus
	public void todayFocus() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (getDayViewTable().getValueAt(i, j).equals(" " + todayD)) {
					//getDayViewTable().changeSelection(i, j, false, false);
					//getDayViewTable().requestFocus();
				}
			}
		}
	}*/
	public JButton getCinemaRegAddBtn() {
		return cinemaRegAddBtn;
	}

	public void setCinemaRegAddBtn(JButton cinemaRegAddBtn) {
		this.cinemaRegAddBtn = cinemaRegAddBtn;
	}

	public HashMap<String, String[]> getBorough() {
		return borough;
	}

	public void setBorough(HashMap<String, String[]> borough) {
		this.borough = borough;
	}

	public HashMap<String, String[]> getArea() {
		return area;
	}

	public void setArea(HashMap<String, String[]> area) {
		this.area = area;
	}

	public JComboBox getCinemaRegTxtCinema() {
		return cinemaRegTxtCinema;
	}

	public void setCinemaRegTxtCinema(JComboBox cinemaRegTxtCinema) {
		this.cinemaRegTxtCinema = cinemaRegTxtCinema;
	}

	public JComboBox getCinemaRegTxtCity() {
		return cinemaRegTxtCity;
	}

	public void setCinemaRegTxtCity(JComboBox cinemaRegTxtCity) {
		this.cinemaRegTxtCity = cinemaRegTxtCity;
	}

	public JComboBox getCinemaRegTxtBorough() {
		return cinemaRegTxtBorough;
	}

	public void setCinemaRegTxtBorough(JComboBox cinemaRegTxtBorough) {
		this.cinemaRegTxtBorough = cinemaRegTxtBorough;
	}

	public JComboBox getCinemaRegTxtArea() {
		return cinemaRegTxtArea;
	}

	public void setCinemaRegTxtArea(JComboBox cinemaRegTxtArea) {
		this.cinemaRegTxtArea = cinemaRegTxtArea;
	}

	public JComboBox getCinemaRegTxtCinemaCount() {
		return cinemaRegTxtCinemaCount;
	}

	public void setCinemaRegTxtCinemaCount(JComboBox cinemaRegTxtCinemaCount) {
		this.cinemaRegTxtCinemaCount = cinemaRegTxtCinemaCount;
	}

	public JComboBox getCinemaRegTxtTime() {
		return cinemaRegTxtTime;
	}

	public void setCinemaRegTxtTime(JComboBox cinemaRegTxtTime) {
		this.cinemaRegTxtTime = cinemaRegTxtTime;
	}

	public JComboBox getCinemaRegTxtTicketPrice() {
		return cinemaRegTxtTicketPrice;
	}

	public void setCinemaRegTxtTicketPrice(JComboBox cinemaRegTxtTicketPrice) {
		this.cinemaRegTxtTicketPrice = cinemaRegTxtTicketPrice;
	}

	public JButton getCinemaRegBackBtn() {
		return cinemaRegBackBtn;
	}

	public void setCinemaRegBackBtn(JButton cinemaRegBackBtn) {
		this.cinemaRegBackBtn = cinemaRegBackBtn;
	}

	public JButton getCinemaRegRegBtn() {
		return cinemaRegRegBtn;
	}

	public void setCinemaRegRegBtn(JButton cinemaRegRegBtn) {
		this.cinemaRegRegBtn = cinemaRegRegBtn;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public JButton[] getCinemaRegTimeBtnList() {
		return cinemaRegTimeBtnList;
	}

	public void setCinemaRegTimeBtnList(JButton[] cinemaRegTimeBtnList) {
		this.cinemaRegTimeBtnList = cinemaRegTimeBtnList;
	}

	public JButton[] getCinemaRegCinemaBtnList() {
		return cinemaRegCinemaBtnList;
	}

	public void setCinemaRegCinemaBtnList(JButton[] cinemaRegCinemaBtnList) {
		this.cinemaRegCinemaBtnList = cinemaRegCinemaBtnList;
	}

	public JButton getCinemaRegInsertBtn() {
		return cinemaRegInsertBtn;
	}

	public void setCinemaRegInsertBtn(JButton cinemaRegInsertBtn) {
		this.cinemaRegInsertBtn = cinemaRegInsertBtn;
	}

	public JTable getDayViewTable() {
		return dayViewTable;
	}

	public void setDayViewTable(JTable dayViewTable) {
		this.dayViewTable = dayViewTable;
	}

	public JLabel getLabel() {
		return label;
	}

	public void setLabel(JLabel label) {
		this.label = label;
	}

	public JPanel getCinemaRegDate() {
		return cinemaRegDate;
	}

	public void setCinemaRegDate(JPanel cinemaRegDate) {
		this.cinemaRegDate = cinemaRegDate;
	}

	public JButton getPrevbtn() {
		return prevbtn;
	}

	public void setPrevbtn(JButton prevbtn) {
		this.prevbtn = prevbtn;
	}

	public JButton getNextbtn() {
		return nextbtn;
	}

	public void setNextbtn(JButton nextbtn) {
		this.nextbtn = nextbtn;
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}

	public boolean isFocus() {
		return focus;
	}

	public void setFocus(boolean focus) {
		this.focus = focus;
	}

	public Calendar getCalendar() {
		return calendar;
	}

	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}

	public DefaultTableModel getWeekTable() {
		return weekTable;
	}

	public void setWeekTable(DefaultTableModel weekTable) {
		this.weekTable = weekTable;
	}

	public DefaultTableModel getDayTable() {
		return dayTable;
	}

	public void setDayTable(DefaultTableModel dayTable) {
		this.dayTable = dayTable;
	}

	public int getTodayD() {
		return todayD;
	}

	public void setTodayD(int todayD) {
		this.todayD = todayD;
	}

	public JPanel getCinemaDatePn() {
		return cinemaDatePn;
	}

	public void setCinemaDatePn(JPanel cinemaDatePn) {
		this.cinemaDatePn = cinemaDatePn;
	}


	public JButton getCinemaRegStartBtn() {
		return cinemaRegStartBtn;
	}

	public void setCinemaRegStartBtn(JButton cinemaRegStartBtn) {
		this.cinemaRegStartBtn = cinemaRegStartBtn;
	}

	// 이전버튼 이벤트
	public void do_prevbtn_actionPerformed(ActionEvent e) {
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) - 1, calendar.get(Calendar.DATE));
		refresh();
	}

	// 다음버튼이벤트
	public void do_nextbtn_actionPerformed(ActionEvent e) {
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DATE));
		refresh();
	}

	public JButton getCinemaRegEndBtn() {
		return cinemaRegEndBtn;
	}

	public void setCinemaRegEndBtn(JButton cinemaRegEndBtn) {
		this.cinemaRegEndBtn = cinemaRegEndBtn;
	}

	public JLabel getCinemaRegStartLabel() {
		return cinemaRegStartLabel;
	}

	public void setCinemaRegStartLabel(JLabel cinemaRegStartLabel) {
		this.cinemaRegStartLabel = cinemaRegStartLabel;
	}

	public JLabel getCinemaRegEndLabel() {
		return cinemaRegEndLabel;
	}

	public void setCinemaRegEndLabel(JLabel cinemaRegEndLabel) {
		this.cinemaRegEndLabel = cinemaRegEndLabel;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}

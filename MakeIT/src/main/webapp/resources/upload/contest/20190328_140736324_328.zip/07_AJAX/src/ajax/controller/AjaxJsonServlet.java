package ajax.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import com.google.gson.Gson;

import ajax.model.vo.User;

/**
 * Servlet implementation class AjaxJsonServlet
 */
@WebServlet("/js/json.do")
public class AjaxJsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxJsonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//일반객체(vo)
		//json객체를 이용하여 데이터 넘기기
		JSONObject jobj=new JSONObject();
		jobj.put("name", "유병승");
		jobj.put("age",19);
		jobj.put("height",180.5);
		jobj.put("phone","010-3644-6259");
		User u=new User(1,"yoobeng",URLEncoder.encode("유병승","utf-8"),"경기도 시흥시");
		response.setCharacterEncoding("UTF-8");
		//gson을 이용하여 객체 전달하기
		//new Gson().toJson(u,response.getWriter());
		
//		response.setContentType("application/json;charset=UTF-8");
//		response.getWriter().println(jobj);
		
		List<User> list=new ArrayList();
		list.add(new User(1,"user01","홍길동","계룡산"));
		list.add(new User(2,"user02","김길동","서울시 강남구"));
		list.add(new User(3,"user03","장길동","장길산"));
		list.add(new User(4,"user04","공길동","공원"));
		
		//Gson으로 리스트 넘기기
		response.setContentType("application/json;charset=UTF-8");
		new Gson().toJson(list,response.getWriter());
		
		
		
		
/*		JSONArray jobjArr=new JSONArray();
		
		for(User u : list) {
			JSONObject obj=new JSONObject();
			obj.put("userNo", u.getUserNo());
			obj.put("userId", u.getUserId());
			obj.put("userName", u.getUserName());
			obj.put("userAddr", u.getUserAddr());
			jobjArr.add(obj);	
		}*/
		
/*		response.setContentType("application/json;charset=UTF-8");
		response.getWriter().println(jobjArr);*/
		
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package ajax.model.service;

import static common.JDBCTemplate.close;
import static common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.List;

import com.kh.notice.model.vo.Notice;

import ajax.model.dao.NoticeDao;
public class NoticeService {

	public int selectCount()
	{
		Connection conn=getConnection();
		int result=new NoticeDao().selectCount(conn);
		close(conn);
		return result;
	}
	
	
	public List<Notice> selectList(int cPage,int numPerPage)
	{
		Connection conn=getConnection();
		List<Notice> list=new NoticeDao().selectAll(conn,cPage,numPerPage);
		close(conn);
		return list;
		
	}
	
	
	
}

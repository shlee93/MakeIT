package ajax.model.dao;

import static common.JDBCTemplate.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.kh.notice.model.vo.Notice;

public class NoticeDao {
	
	public int selectCount(Connection conn)
	{
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String sql="select count(*) as cnt from notice";
		try {
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			if(rs.next())
				result=rs.getInt("cnt");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally {
			close(rs);
			close(pstmt);
		}
		return result;
	}
	
	public List<Notice> selectAll(Connection conn, int cPage, int numPerPage)
	{
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		List<Notice> list=new ArrayList();
		String sql= "select * from (select rownum as rnum, A.* from (select * from notice order by notice_date desc)A ) where rnum between ? and ?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, (cPage-1)*numPerPage+1);
			pstmt.setInt(2, cPage*numPerPage);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				Notice n=new Notice();
				n.setNoticeNo(rs.getInt("notice_no"));
				n.setNoticeTitle(rs.getString("notice_title"));
				n.setNoticeWriter(rs.getString("notice_writer"));
				n.setNotcieContent(rs.getString("notice_content"));
				n.setNoticeDate(rs.getDate("notice_date"));
				n.setFilePath(rs.getString("filepath"));
				list.add(n);
			}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally {
			close(rs);
			close(pstmt);
		}
		
		return list;
	}
			
			
			

}

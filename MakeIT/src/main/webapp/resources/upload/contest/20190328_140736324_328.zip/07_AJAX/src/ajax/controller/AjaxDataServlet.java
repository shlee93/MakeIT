package ajax.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ajax.dao.AjaxDao;

/**
 * Servlet implementation class AjaxDataServlet
 */
@WebServlet("/js/data.do")
public class AjaxDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxDataServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String search=request.getParameter("search");
		System.out.println(search);
		List<String> idList;
		String csv="";
		if(!search.trim().isEmpty())
		{
			idList=new AjaxDao().selectId(search);
			if(!idList.isEmpty())
			{
				for(int i=0;i<idList.size();i++)
				{
					if(i!=0) csv+=",";
					csv+=idList.get(i);
				}
			}
		}
		System.out.println("csv : "+csv);
		response.setContentType("text/csv;charset=UTF-8");
		response.getWriter().append(csv);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
